#include "zmytest/test.hpp"

#include "zlasdtest/test.hpp"

/* ************************************************************************** */

#include <iostream>

#include "container/container.hpp"
#include "container/testable.hpp"
#include "container/dictionary.hpp"
#include "container/foldable.hpp"
#include "container/mappable.hpp"
#include "container/linear.hpp"

#include "vector/vector.hpp"
#include "list/list.hpp"

#include "queue/queue.hpp"
#include "queue/lst/queuelst.hpp"

#include "stack/stack.hpp"
#include "stack/lst/stacklst.hpp"

#include "hashtable/hashtable.hpp"
#include "hashtable/clsadr/htclsadr.hpp"
#include "hashtable/opnadr/htopnadr.hpp"

using namespace std;

/* **************************************************************** */

int main(){

  std::cout << "Lasd Libraries 2023\nBenvenuto!" << std::endl;
  
  bool continua = true;
  int scelta;
  while (continua==true){
    std::cout << "Cosa vuoi eseguire?\n1)lasdtest\n2)myTest\n0)uscire(default)" << endl;
    std::cin>>scelta;
    switch(scelta){
      case 1:
        lasdtest();
        break;
      case 2:
        myTest();
        break;
      default:
        continua=false;
    }
  }


  return 0;
}
