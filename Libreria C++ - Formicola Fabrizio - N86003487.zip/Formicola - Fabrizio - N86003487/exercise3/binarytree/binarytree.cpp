
#include "binarytree.hpp"

namespace lasd {

/* ************************************************************************** */

template <typename Data>
inline bool BinaryTree<Data>::operator==(const BinaryTree& other) const noexcept {
    if(this->size!=other.size)
        return false;
    BTPreOrderIterator i(*this);
    BTPreOrderIterator j(other);
    while(!(i.Terminated() || j.Terminated())){
        if(*i!=*j)
            return false;
        ++i;
        ++j;
    }
    return true;
}

template <typename Data>
void BinaryTree<Data>::Fold(const FoldFunctor func, void *acc) const {
    if(!this->Empty()) {
        PreOrderMap( 
                [&func, &acc](const Data& dat) {
                    func(dat, acc);
                }
            );
    }
}

template <typename Data>
void BinaryTree<Data>::PreOrderMap(const MapFunctor func) const {
  if(!(this->Empty()))
    AuxPreOrderMap(&this->Root(), func);
}

template <typename Data>
void BinaryTree<Data>::PostOrderMap(const MapFunctor func) const {
    if(!this->Empty())
        AuxPostOrderMap(&this->Root(), func);
}

template <typename Data>
void BinaryTree<Data>::InOrderMap(const MapFunctor func) const {
    if(!this->Empty())
        AuxInOrderMap(&this->Root(), func);
}

template <typename Data>
void BinaryTree<Data>::BreadthMap(const MapFunctor func) const {
    if(!this->Empty())
        AuxBreadthMap(&this->Root(), func);
}

template <typename Data>
void BinaryTree<Data>::AuxPreOrderMap(const Node* node, const MapFunctor func) const {
    func(node->Element()); 

    if(node->HasLeftChild())
        AuxPreOrderMap(&node->LeftChild(), func);
    if(node->HasRightChild())
        AuxPreOrderMap(&node->RightChild(), func);    
}

template <typename Data>
void BinaryTree<Data>::AuxPostOrderMap(const Node* node, const MapFunctor func) const {
    if(node->HasLeftChild())
        AuxPostOrderMap(&node->LeftChild(), func);
    if(node->HasRightChild())
        AuxPostOrderMap(&node->RightChild(), func);

    func(node->Element());
}

template <typename Data>
void BinaryTree<Data>::AuxInOrderMap(const Node* node, const MapFunctor func) const {
    if(node->HasLeftChild()) 
        AuxInOrderMap(&node->LeftChild(), func);

    func(node->Element());

    if(node->HasRightChild())
        AuxInOrderMap(&node->RightChild(), func);
}

template <typename Data>
void BinaryTree<Data>::AuxBreadthMap(const Node* node, const MapFunctor func) const {
    lasd::QueueLst<const BinaryTree<Data>::Node *> queue;
    if(node!=nullptr)
        queue.Enqueue(node);

    while (!queue.Empty()) {
        const BinaryTree<Data>::Node *currentNode = queue.HeadNDequeue();
        func(currentNode->Element());

        if(currentNode->HasLeftChild())
            queue.Enqueue(&currentNode->LeftChild());
        if(currentNode->HasRightChild())
            queue.Enqueue(&currentNode->RightChild());
    }
}

/* *********************************** MutableBinaryTree *************************************** */

template <typename Data>
void MutableBinaryTree<Data>::PreOrderMap(MutableMapFunctor func){
    if(!(this->Empty()))
        AuxPreOrderMap(&this->Root(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::PostOrderMap(MutableMapFunctor func){
    if(!(this->Empty()))
        AuxPostOrderMap(&this->Root(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::InOrderMap(MutableMapFunctor func){
    if(!(this->Empty()))
       AuxInOrderMap(&this->Root(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::BreadthMap(MutableMapFunctor func){
    if(!(this->Empty()))
        AuxBreadthMap(&this->Root(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::AuxPreOrderMap(MutableNode* node, MutableMapFunctor func) {
    func(node->Element());

    if(node->HasLeftChild())
        AuxPreOrderMap(&node->LeftChild(), func);
    if(node->HasRightChild())
        AuxPreOrderMap(&node->RightChild(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::AuxPostOrderMap(MutableNode* node, MutableMapFunctor func){
    if(node->HasLeftChild())
        AuxPostOrderMap(&node->LeftChild(), func);
    if(node->HasRightChild())
        AuxPostOrderMap(&node->RightChild(), func);

    func(node->Element());
}

template <typename Data>
void MutableBinaryTree<Data>::AuxInOrderMap(MutableNode* node, MutableMapFunctor func){
    if(node->HasLeftChild())
        AuxInOrderMap(&node->LeftChild(), func);

    func(node->Element());

    if(node->HasRightChild())
        AuxInOrderMap(&node->RightChild(), func);
}

template <typename Data>
void MutableBinaryTree<Data>::AuxBreadthMap(MutableNode* node, MutableMapFunctor func){
    lasd::QueueLst<MutableBinaryTree<Data>::MutableNode *> queue;
    if(node!=nullptr)
        queue.Enqueue(node);

    while (!queue.Empty()) {
        MutableBinaryTree<Data>::MutableNode *currentNode = queue.HeadNDequeue();
        func(currentNode->Element());

        if(currentNode->HasLeftChild())
            queue.Enqueue(&currentNode->LeftChild());
        if(currentNode->HasRightChild())
            queue.Enqueue(&currentNode->RightChild());
    }
}

/* ************************************************************************** */

/* *********************************** BTPreOrderIterator *************************************** */

template <typename Data>
BTPreOrderIterator<Data>::BTPreOrderIterator(const BinaryTree<Data>& other) {
    if(!other.Empty()) 
        root = current = &other.Root();
}

template <typename Data>
BTPreOrderIterator<Data>::BTPreOrderIterator(const BTPreOrderIterator &other) : stack(other.stack) {
    root = other.root;
    current = other.current;
}

template <typename Data>
BTPreOrderIterator<Data>::BTPreOrderIterator(BTPreOrderIterator&& other) noexcept : stack(std::move(other.stack)) {
    std::swap(root, other.root);
    std::swap(current, other.current); 
}

template <typename Data>
BTPreOrderIterator<Data>& BTPreOrderIterator<Data>::operator=(const BTPreOrderIterator& other) {
    current=other.current;
    root=other.root;
    stack=other.stack;
    return *this;
}

template <typename Data>
BTPreOrderIterator<Data>& BTPreOrderIterator<Data>::operator=(BTPreOrderIterator&& other) noexcept {
    std::swap(current, other.current);
    std::swap(root, other.root);
    std::swap(stack, other.stack);
    return *this;
}

template <typename Data>
bool BTPreOrderIterator<Data>::operator==(const BTPreOrderIterator &other) const noexcept {
    return (current==other.current && stack==other.stack);
}

template <typename Data>
const Data& BTPreOrderIterator<Data>::operator*() const {
    if(Terminated())
        throw std::out_of_range("BTPreOrderIterator is terminated in operator*()");
    else
        return current->Element();
}

template <typename Data>
BTPreOrderIterator<Data>& BTPreOrderIterator<Data>::operator++() {
    if(!Terminated()){
        if(current->HasLeftChild()){
            if(current->HasRightChild())
                stack.Push(&current->RightChild());
            current=&(current->LeftChild());
        }
        else if(current->HasRightChild())
            current=&(current->RightChild());
        else if (!stack.Empty())
            current=stack.TopNPop();
        else
            current=nullptr;
    }
    else
        throw std::out_of_range("BTPreOrderIterator is out of range in operator++");
    return *this;
}


/* BTPreOrderMutableIterator */

template <typename Data>
BTPreOrderMutableIterator<Data>& BTPreOrderMutableIterator<Data>::operator=(const BTPreOrderMutableIterator& other) {
    this->current=other.current;
    this->root=other.root;
    this->stack=other.stack;
    return *this;
}

template <typename Data>
BTPreOrderMutableIterator<Data>& BTPreOrderMutableIterator<Data>::operator=(BTPreOrderMutableIterator&& other) noexcept {
    std::swap(this->current, other.current);
    std::swap(this->root, other.root);
    std::swap(this->stack, other.stack);
    return *this;
}

template <typename Data>
Data& BTPreOrderMutableIterator<Data>::operator*() {
    if(this->current!=nullptr) 
        return const_cast<Data&>((this->current)->Element());
    else
        throw std::out_of_range("BTPreOrderMutableIterator is out of range in operator*()"); 
};

/* *********************************** BTPostOrderIterator *************************************** */

template <typename Data>
BTPostOrderIterator<Data>::BTPostOrderIterator(const BinaryTree<Data>& other){
    if(other.Empty())
        root=nullptr;
    else
        root=&other.Root();
    current = DeepestLeftLeaf(root);
}

template <typename Data>
BTPostOrderIterator<Data>::BTPostOrderIterator(const BTPostOrderIterator& other) {
    stack=other.stack;
    root=other.root;
    current=other.current;
}

template <typename Data>
BTPostOrderIterator<Data>::BTPostOrderIterator(BTPostOrderIterator&& other) noexcept : stack(std::move(other.stack)) {
    std::swap(current, other.current);
    std::swap(root, other.root); 
}

template <typename Data>
const typename BinaryTree<Data>::Node* BTPostOrderIterator<Data>::DeepestLeftLeaf(const typename BinaryTree<Data>::Node* actual){
    if(actual!=nullptr){
        while(actual->HasLeftChild()){
            stack.Push(actual);
            actual = &(actual->LeftChild());
        }
        if(actual->HasRightChild()){
            stack.Push(actual);
            actual = &(actual->RightChild());
            actual = DeepestLeftLeaf(actual);
        }
    }
    return actual;
}

template <typename Data>
BTPostOrderIterator<Data>& BTPostOrderIterator<Data>::operator=(const BTPostOrderIterator& other) {
    current=other.current;
    root=other.root;
    stack=other.stack;
    return *this;
}

template <typename Data>
BTPostOrderIterator<Data>& BTPostOrderIterator<Data>::operator=(BTPostOrderIterator&& other) noexcept {
    std::swap(current, other.current);
    std::swap(root, other.root);
    std::swap(stack, other.stack);
    return *this;
}

template <typename Data>
bool BTPostOrderIterator<Data>::operator==(const BTPostOrderIterator &other) const noexcept {
    return (current==other.current && stack==other.stack);
}

template <typename Data>
const Data& BTPostOrderIterator<Data>::operator*() const {
    if(Terminated())
        throw std::out_of_range("BTPostOrderIterator is terminated in operator*()");
    else
        return current->Element();
}

template <typename Data>
BTPostOrderIterator<Data>& BTPostOrderIterator<Data>::operator++(){
    if(!(Terminated())){
        if(!(stack.Empty())){
            if (stack.Top()->HasRightChild() && !(&(stack.Top()->RightChild()) == current)) {
                current = &(stack.Top()->RightChild());
                current = DeepestLeftLeaf(current);
            }
            else
                current = stack.TopNPop();
        }
        else
            current = nullptr;
    }
    else
        throw std::out_of_range("BTPostOrderIterator is out of range in operator++");
    return *this;
}


/* BTPostOrderMutableIterator */

template <typename Data>
BTPostOrderMutableIterator<Data>& BTPostOrderMutableIterator<Data>::operator=(const BTPostOrderMutableIterator& other) {
    this->current=other.current;
    this->root=other.root;
    this->stack=other.stack;
    return *this;
}

template <typename Data>
BTPostOrderMutableIterator<Data>& BTPostOrderMutableIterator<Data>::operator=(BTPostOrderMutableIterator&& other) noexcept {
    std::swap(this->current, other.current);
    std::swap(this->root, other.root);
    std::swap(this->stack, other.stack);
    return *this;
}

template <typename Data>
Data& BTPostOrderMutableIterator<Data>::operator*() {
    if(this->current!=nullptr)
        return const_cast<Data&>((this->current)->Element());
    else
        throw std::out_of_range("BTPostOrderMutableIterator is out of range in operator*()"); 
};

/* *********************************** BTInOrderIterator *************************************** */

template <typename Data>
const typename BinaryTree<Data>::Node *BTInOrderIterator<Data>::FindDeepestLeftLeaf(const typename BinaryTree<Data>::Node* actual) {
   while (actual != nullptr && (actual->HasLeftChild())) {
        stack.Push(actual);
        actual = &actual->LeftChild();
    }
    return actual;
}

template <typename Data>
BTInOrderIterator<Data>::BTInOrderIterator(const BinaryTree<Data> &other) {
    if(other.Empty())
        root=nullptr;
    else
        root=&other.Root();
    current=FindDeepestLeftLeaf(root);
}

template <typename Data>
BTInOrderIterator<Data>::BTInOrderIterator(const BTInOrderIterator& other) {
    stack=other.stack;
    root=other.root;
    current=other.current;
}

template <typename Data>
BTInOrderIterator<Data>::BTInOrderIterator(BTInOrderIterator&& other) noexcept : stack(std::move(other.stack)) {
    std::swap(current, other.current);
    std::swap(root, other.root); 
}

template <typename Data>
BTInOrderIterator<Data>& BTInOrderIterator<Data>::operator=(const BTInOrderIterator& other) {
    current=other.current;
    root=other.root;
    stack=other.stack;
    return *this;
}

template <typename Data>
BTInOrderIterator<Data>& BTInOrderIterator<Data>::operator=(BTInOrderIterator&& other) noexcept {
    std::swap(current, other.current);
    std::swap(root, other.root);
    std::swap(stack, other.stack);
    return *this;
}

template <typename Data>
bool BTInOrderIterator<Data>::operator==(const BTInOrderIterator &other) const noexcept {
    return (current==other.current && stack==other.stack);
}

template <typename Data>
const Data& BTInOrderIterator<Data>::operator*() const {
    if(Terminated())
        throw std::out_of_range("BTInOrderIterator is terminated in operator*()");
    else
        return current->Element();
}


template <typename Data>
BTInOrderIterator<Data> &BTInOrderIterator<Data>::operator++() {
    if(!(Terminated())){
        if((stack.Empty()) && !(current->HasRightChild()))
            current=nullptr;
        else { 
            if(current->HasRightChild()){
                current = FindDeepestLeftLeaf(&current->RightChild());
            }
            else
                current = stack.TopNPop();
        }
    }
    else
        throw std::out_of_range("BTInOrderIterator is out of range in operator++");

    return *this;
}


/* BTInOrderMutableIterator */

template <typename Data>
BTInOrderMutableIterator<Data>& BTInOrderMutableIterator<Data>::operator=(const BTInOrderMutableIterator& other) {
    this->current=other.current;
    this->root=other.root;
    this->stack=other.stack;
    return *this;
}

template <typename Data>
BTInOrderMutableIterator<Data>& BTInOrderMutableIterator<Data>::operator=(BTInOrderMutableIterator&& other) noexcept {
    std::swap(this->current, other.current);
    std::swap(this->root, other.root);
    std::swap(this->stack, other.stack);
    return *this;
}

template <typename Data>
Data& BTInOrderMutableIterator<Data>::operator*() {
    if(this->current!=nullptr)
        return const_cast<Data&>((this->current)->Element());
    else
        throw std::out_of_range("BTInOrderMutableIterator is out of range in operator*()"); 
};

/* *********************************** BTBreadthIterator *************************************** */

template <typename Data>
BTBreadthIterator<Data>::BTBreadthIterator(const BinaryTree<Data>& other) {
    if(other.Empty())
        root = current = nullptr;
    else
        root = current = &other.Root();
}

template <typename Data>
BTBreadthIterator<Data>::BTBreadthIterator(const BTBreadthIterator &other) {
    queue=other.queue;
    root = current = other.current;
}

template <typename Data>
BTBreadthIterator<Data>::BTBreadthIterator(BTBreadthIterator&& other) noexcept : queue(std::move(other.queue)) {
    std::swap(root, other.root);
    std::swap(current, other.current); 
}

template <typename Data>
BTBreadthIterator<Data>& BTBreadthIterator<Data>::operator=(const BTBreadthIterator& other) {
    current=other.current;
    root=other.root;
    queue=other.queue;
    return *this;
}

template <typename Data>
BTBreadthIterator<Data>& BTBreadthIterator<Data>::operator=(BTBreadthIterator&& other) noexcept {
    std::swap(current, other.current);
    std::swap(root, other.root);
    std::swap(queue, other.queue);
    return *this;
}

template <typename Data>
bool BTBreadthIterator<Data>::operator==(const BTBreadthIterator &other) const noexcept {
    return (current==other.current && queue==other.queue);
}

template <typename Data>
const Data& BTBreadthIterator<Data>::operator*() const {
    if(Terminated())
        throw std::out_of_range("BTBreadthIterator is terminated in operator*()");
    else
        return current->Element();
}

template <typename Data>
BTBreadthIterator<Data>& BTBreadthIterator<Data>::operator++() {
    if (!(Terminated())) {
        if (current->HasLeftChild())
            queue.Enqueue(&(current->LeftChild())); 
        if (current->HasRightChild())
            queue.Enqueue(&(current->RightChild()));
        if (!queue.Empty())
            current = queue.HeadNDequeue();
        else
            current = nullptr;
    }
    else
        throw std::out_of_range("BTBreadthIterator is out of range in operator++");

    return *this;
}


/* BTBreadthMutableIterator */

template <typename Data>
BTBreadthMutableIterator<Data>& BTBreadthMutableIterator<Data>::operator=(const BTBreadthMutableIterator& other) {
    this->current=other.current;
    this->root=other.root;
    this->queue=other.queue;
    return *this;
}

template <typename Data>
BTBreadthMutableIterator<Data>& BTBreadthMutableIterator<Data>::operator=(BTBreadthMutableIterator&& other) noexcept {
    std::swap(this->current, other.current);
    std::swap(this->root, other.root);
    std::swap(this->queue, other.queue);
    return *this;
}

template <typename Data>
Data& BTBreadthMutableIterator<Data>::operator*() {
    if(this->current!=nullptr)
        return const_cast<Data&>((this->current)->Element());
    else
        throw std::out_of_range("BTBreadthMutableIterator is out of range in operator*()"); 
};

/* ************************************************************************** */

}