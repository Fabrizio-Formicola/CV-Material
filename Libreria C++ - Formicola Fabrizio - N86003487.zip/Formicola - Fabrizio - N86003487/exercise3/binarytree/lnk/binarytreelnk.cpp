#include "binarytreelnk.hpp"

namespace lasd {

/* ************************************************************************** */

// NodeLnk
template <typename Data>
BinaryTreeLnk<Data>::NodeLnk::NodeLnk(const NodeLnk& other){
    elem = other.elem;

    if(other.l_child != nullptr)
        l_child = new NodeLnk(*other.l_child);
    else
        l_child = nullptr;

    if(other.r_child != nullptr)
        r_child = new NodeLnk(*other.r_child);
    else
        r_child = nullptr;
}

template <typename Data>
BinaryTreeLnk<Data>::NodeLnk::NodeLnk(NodeLnk&& other) noexcept {
    std::swap(elem, other.elem);
    std::swap(l_child, other.l_child);
    std::swap(r_child, other.r_child);
}


template <typename Data>
BinaryTreeLnk<Data>::NodeLnk &BinaryTreeLnk<Data>::NodeLnk::operator=(const NodeLnk &other) {
    elem(other->elem);
    return *this;
}

template <typename Data>
BinaryTreeLnk<Data>::NodeLnk &BinaryTreeLnk<Data>::NodeLnk::operator=(NodeLnk &&other) noexcept {
    std::swap(elem, other->elem);
    return *this;
}


template <typename Data>
typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::NodeLnk::RightChild(){
    if(HasRightChild())
        return *r_child;
    else
        throw std::out_of_range("NodeLnk non ha figlio destro in RightChild()");
}

template <typename Data>
const typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::NodeLnk::RightChild() const {
    if(HasRightChild())
        return *r_child;
    else
        throw std::out_of_range("NodeLnk non ha figlio destro in RightChild()");
}

template <typename Data>
typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::NodeLnk::LeftChild(){
    if(HasLeftChild())
        return *l_child;
    else
        throw std::out_of_range("NodeLnk non ha figlio sinistro in LeftChild()");
}

template <typename Data>
const typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::NodeLnk::LeftChild() const {
    if(HasLeftChild())
        return *l_child;
    else
        throw std::out_of_range("NodeLnk non ha figlio sinistro in LeftChild()");
}


// BinaryTreeLnk
template <typename Data>
BinaryTreeLnk<Data>::BinaryTreeLnk(const MappableContainer<Data> &other) {
    size = other.Size();
    QueueLst<NodeLnk**> queue;
    queue.Enqueue(&root);
    other.Map(
        [&queue](const Data& dat){
            NodeLnk *& curr = *queue.HeadNDequeue();
            curr = new NodeLnk(dat);
            queue.Enqueue(&curr->l_child);
            queue.Enqueue(&curr->r_child);
        }
    );
}

template <typename Data>
BinaryTreeLnk<Data>::BinaryTreeLnk(MutableMappableContainer<Data> &&other) noexcept {
    size = other.Size();
    QueueLst<NodeLnk**> queue;
    queue.Enqueue(&root);
    other.Map(
        [&queue](Data& dat){
            NodeLnk *& curr = *queue.HeadNDequeue();
            curr = new NodeLnk(std::move(dat));
            queue.Enqueue(&curr->l_child);
            queue.Enqueue(&curr->r_child);
        }
    );
}

template <typename Data>
BinaryTreeLnk<Data>::BinaryTreeLnk(const BinaryTreeLnk &other){
    if(other.root!=nullptr) {
        root = new NodeLnk(*other.root);
        size = other.Size();
    }   
}

template <typename Data>
BinaryTreeLnk<Data>::BinaryTreeLnk(BinaryTreeLnk<Data>&& other) noexcept {
    std::swap(root, other.root);
    std::swap(size, other.size);
}

template <typename Data>
BinaryTreeLnk<Data>& BinaryTreeLnk<Data>::operator=(const BinaryTreeLnk& other) {
    Clear();
    if (other.root!=nullptr){
        root = new NodeLnk(*other.root);
        size = other.Size();
    }
    return *this;
}


template <typename Data>
BinaryTreeLnk<Data>& BinaryTreeLnk<Data>::operator=(BinaryTreeLnk&& other) noexcept {
    std::swap(root, other.root);
    std::swap(size, other.size);
    return *this;
}


template <typename Data>
const typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::Root() const {
    if(!(this->Empty()))
      return *root;
    else
      throw std::length_error("The tree is empty in Root()");
  };

template <typename Data>
typename BinaryTreeLnk<Data>::NodeLnk& BinaryTreeLnk<Data>::Root() {
    if(!(this->Empty()))
      return *root;
    else
      throw std::length_error("The tree is empty in Root()");
  };


template <typename Data>
void BinaryTreeLnk<Data>::Clear() noexcept {
    if (root != nullptr){
        delete root;
        root=nullptr;
    }
    size=0;
}

/* ************************************************************************** */

}
