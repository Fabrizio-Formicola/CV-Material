
#ifndef BINARYTREELNK_HPP
#define BINARYTREELNK_HPP

/* ************************************************************************** */

#include "../binarytree.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class BinaryTreeLnk : virtual public MutableBinaryTree<Data> {

private:

protected:

  using Container::size;

  // using BinaryTree<Data>::???;


  struct NodeLnk : virtual public MutableBinaryTree<Data>::MutableNode { 

    friend class BinaryTreeLnk<Data>;

  private:

  protected:

  public:

    Data elem {};
    NodeLnk* l_child = nullptr;
    NodeLnk* r_child = nullptr;

    // Specific constructors
    NodeLnk(const Data& newElem) : elem(newElem) {};
    NodeLnk(Data&& newElem) noexcept { std::swap(elem , newElem); };

    // Copy constructor
    NodeLnk(const NodeLnk& other);

    // Move constructor
    NodeLnk(NodeLnk&& other) noexcept;

    // Destructor
    inline virtual ~NodeLnk() { delete l_child; delete r_child; };

    // Copy Assignament
    NodeLnk& operator=(const NodeLnk& other);

    // Move Assignament
    NodeLnk& operator=(NodeLnk&& other) noexcept;
    

    // Specific member functions
    inline virtual Data& Element() noexcept override { return elem; }
    inline virtual const Data& Element() const noexcept override { return elem; }

    inline virtual bool IsLeaf() const noexcept override { return (!(HasLeftChild() || HasRightChild())); }; 
    
    inline virtual bool HasLeftChild() const noexcept override { return l_child!=nullptr; }
    inline virtual bool HasRightChild() const noexcept override { return r_child!=nullptr; }

    virtual NodeLnk& RightChild() override; // Must throw std::length_error when empty
    virtual const NodeLnk& RightChild() const override; // Must throw std::length_error when empty
    virtual NodeLnk& LeftChild() override; // Must throw std::length_error when empty
    virtual const NodeLnk& LeftChild() const override; // Must throw std::length_error when empty

  };

  NodeLnk* root = nullptr;

public:

  // Default constructor
  BinaryTreeLnk() = default;

  /* ************************************************************************ */

  // Specific constructors
  BinaryTreeLnk(const MappableContainer<Data>& other); // A binary tree obtained from a MappableContainer
  BinaryTreeLnk(MutableMappableContainer<Data>&& other) noexcept; // A binary tree obtained from a MutableMappableContainer

  /* ************************************************************************ */

  // Copy constructor
  BinaryTreeLnk(const BinaryTreeLnk<Data>& other);

  // Move constructor
  BinaryTreeLnk(BinaryTreeLnk<Data>&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  virtual ~BinaryTreeLnk() { delete root; };

  /* ************************************************************************ */

  // Copy assignment
  BinaryTreeLnk& operator=(const BinaryTreeLnk& other);

  // Move assignment
  BinaryTreeLnk& operator=(BinaryTreeLnk&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BinaryTreeLnk& other) const noexcept { return BinaryTree<Data>::operator==(other); };
  inline bool operator!=(const BinaryTreeLnk& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from BinaryTree)
  inline virtual const NodeLnk& Root() const override; // Override BinaryTree member (throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from MutableBinaryTree)
  inline virtual NodeLnk& Root() override; // Override MutableBinaryTree member (throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from ClearableContainer)
  virtual void Clear() noexcept override; // Override ClearableContainer member


protected:

};

/* ************************************************************************** */

}

#include "binarytreelnk.cpp"

#endif
