
#ifndef BINARYTREE_HPP
#define BINARYTREE_HPP

/* ************************************************************************** */

#include "../container/container.hpp"
#include "../container/mappable.hpp"

#include "../iterator/iterator.hpp"

#include "../stack/lst/stacklst.hpp"
#include "../queue/lst/queuelst.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class BinaryTree : virtual public PreOrderMappableContainer<Data>,
                   virtual public PostOrderMappableContainer<Data>,
                   virtual public InOrderMappableContainer<Data>,
                   virtual public BreadthMappableContainer<Data> {  

private:

protected:

public:

  struct Node {

  protected:

    // Comparison operators
    inline bool operator==(const Node& other) const noexcept { return (Element() == other.Element()); }; // Comparison of abstract types is possible, but should not be visible.
    inline bool operator!=(const Node& other) const noexcept { return !(operator==(other)); }; // Comparison of abstract types is possible, but should not be visible.

  public:

    friend class BinaryTree<Data>;

    /* ********************************************************************** */

    // Destructor
    virtual ~Node() = default;

    /* ********************************************************************** */

    // Copy assignment
    Node& operator=(const Node& other) = delete; // Copy assignment of abstract types should not be possible.

    // Move assignment
    Node& operator=(Node&& other) noexcept = delete; // Move assignment of abstract types should not be possible.

    /* ********************************************************************** */

    // Specific member functions
    virtual const Data& Element() const noexcept = 0; // Immutable access to the element (concrete function should not throw exceptions)

    inline virtual bool IsLeaf() const noexcept{ return ((!HasLeftChild()) && (!HasRightChild())); }; // (concrete function should not throw exceptions)

    virtual bool HasLeftChild() const noexcept = 0; // (concrete function should not throw exceptions)
    virtual bool HasRightChild() const noexcept = 0; // (concrete function should not throw exceptions)

    virtual const Node& LeftChild() const = 0; // (concrete function must throw std::out_of_range when not existent)
    virtual const Node& RightChild() const = 0; // (concrete function must throw std::out_of_range when not existent)

  };

  /* ************************************************************************ */

  // Destructor
  virtual ~BinaryTree() = default;

  /* ************************************************************************ */

  // Copy assignment
  BinaryTree<Data>& operator=(const BinaryTree& other) = delete; // Copy assignment of abstract types should not be possible.

  // Move assignment
  BinaryTree<Data>& operator=(BinaryTree&& other) noexcept = delete; // Move assignment of abstract types should not be possible.

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const BinaryTree& other) const noexcept; // Comparison of abstract binary tree is possible.
  inline bool operator!=(const BinaryTree& other) const noexcept { return !(operator==(other)); };  // Comparison of abstract binary tree is possible.

  /* ************************************************************************ */

  // Specific member functions
  virtual const Node& Root() const = 0; // (concrete function must throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from FoldableContainer)
  using typename FoldableContainer<Data>::FoldFunctor;

  virtual void Fold(FoldFunctor func, void* acc) const override; // Override FoldableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from MappableContainer)
  using typename MappableContainer<Data>::MapFunctor;

  inline virtual void Map(MapFunctor func) const override { PreOrderMap(func); }; // Override MappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from PreOrderMappableContainer)
  virtual void PreOrderMap(const MapFunctor func) const override; // Override PreOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from PostOrderMappableContainer)
  virtual void PostOrderMap(const MapFunctor func) const override; // Override PostOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from InOrderMappableContainer)
  virtual void InOrderMap(const MapFunctor func) const override; // Override InOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from BreadthMappableContainer)
  virtual void BreadthMap(const MapFunctor func) const override; // Override BreadthMappableContainer member

protected:

  // Auxiliary member function (for PreOrderMappableContainer)
  void AuxPreOrderMap(const Node *node, MapFunctor func) const; // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for PostOrderMappableContainer)
  void AuxPostOrderMap(const Node *node, MapFunctor func) const; // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for InOrderMappableContainer)
  void AuxInOrderMap(const Node *node, MapFunctor func) const; // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for BreadthMappableContainer)
  void AuxBreadthMap(const Node *node, MapFunctor func) const; // Accessory function executing from one node of the tree

};

/* ************************************************************************** */

template <typename Data>
class MutableBinaryTree : virtual public ClearableContainer,
                          virtual public BinaryTree<Data>,
                          virtual public MutablePreOrderMappableContainer<Data>,
                          virtual public MutablePostOrderMappableContainer<Data>,
                          virtual public MutableInOrderMappableContainer<Data>,
                          virtual public MutableBreadthMappableContainer<Data> {

private:

protected:

public:

  struct MutableNode : public virtual BinaryTree<Data>::Node {

    friend class MutableBinaryTree<Data>;

    /* ********************************************************************** */

    // Destructor
    virtual ~MutableNode() = default;

    /* ********************************************************************** */

    // Copy assignment
    MutableNode& operator=(const MutableNode& other) = delete; // Copy assignment of abstract types should not be possible.

    // Move assignment
    MutableNode& operator=(MutableNode&& other) noexcept = delete; // Move assignment of abstract types should not be possible.

    /* ********************************************************************** */

    // Specific member functions
    virtual Data& Element() noexcept = 0; // Mutable access to the element (concrete function should not throw exceptions)

    virtual MutableNode& LeftChild() = 0; // (concrete function must throw std::out_of_range when not existent)
    virtual MutableNode& RightChild() = 0; // (concrete function must throw std::out_of_range when not existent)

  };

  /* ************************************************************************ */

  // Destructor
  virtual ~MutableBinaryTree() = default;

  /* ************************************************************************ */

  // Copy assignment
  MutableBinaryTree<Data>& operator=(const MutableBinaryTree& other) = delete; // Copy assignment of abstract types should not be possible.

  // Move assignment
  MutableBinaryTree<Data>& operator=(MutableBinaryTree&& other) = delete; // Move assignment of abstract types should not be possible.

  /* ************************************************************************ */

  // Specific member functions
  virtual MutableNode& Root() = 0; // (concrete function must throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from MutableMappableContainer)
  using typename MutableMappableContainer<Data>::MutableMapFunctor;

  inline virtual void Map(MutableMapFunctor func) override { PreOrderMap(func); }; // Override MutableMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from MutablePreOrderMappableContainer)
  virtual void PreOrderMap(MutableMapFunctor func) override; // Override MutablePreOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from MutablePostOrderMappableContainer)
  virtual void PostOrderMap(MutableMapFunctor func) override; // Override MutablePostOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from MutableInOrderMappableContainer)
  virtual void InOrderMap(MutableMapFunctor func) override; // Override MutableInOrderMappableContainer member

  /* ************************************************************************ */

  // Specific member function (inherited from MutableBreadthMappableContainer)
  virtual void BreadthMap(MutableMapFunctor func) override; // Override MutableBreadthMappableContainer member

protected:

  // Auxiliary member function (for MutablePreOrderMappableContainer)
  void AuxPreOrderMap(MutableNode* node, MutableMapFunctor func); // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for MutablePostOrderMappableContainer)
  void AuxPostOrderMap(MutableNode* node, MutableMapFunctor func); // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for MutableInOrderMappableContainer)
  void AuxInOrderMap(MutableNode* node, MutableMapFunctor func); // Accessory function executing from one node of the tree

  /* ************************************************************************ */

  // Auxiliary member function (for MutableBreadthMappableContainer)
  void AuxBreadthMap(MutableNode* node, MutableMapFunctor func); // Accessory function executing from one node of the tree

};

/* ************************************************************************** */

template <typename Data>
class BTPreOrderIterator : public virtual ForwardIterator<Data>,
                           public virtual ResettableIterator<Data>{

private:

protected:

  const typename BinaryTree<Data>::Node* root=nullptr;
  const typename BinaryTree<Data>::Node* current=nullptr;
  StackLst<const typename BinaryTree<Data>::Node*> stack;

public:

  // Specific constructors
  BTPreOrderIterator(const BinaryTree<Data>& other); // An iterator over a given binary tree

  /* ************************************************************************ */

  // Copy constructor
  BTPreOrderIterator(const BTPreOrderIterator& other);

  // Move constructor
  BTPreOrderIterator(BTPreOrderIterator&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  virtual ~BTPreOrderIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  BTPreOrderIterator& operator=(const BTPreOrderIterator& other);

  // Move assignment
  BTPreOrderIterator& operator=(BTPreOrderIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const BTPreOrderIterator& other) const noexcept;
  inline bool operator!=(const BTPreOrderIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)
  const Data& operator*() const override; // (throw std::out_of_range when terminated)
  inline bool Terminated() const noexcept override { return (current==nullptr); }; // (should not throw exceptions)

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)
  BTPreOrderIterator<Data>& operator++() override; // (throw std::out_of_range when terminated)

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)
  inline void Reset() noexcept override { stack.Clear(); current=root; }; // (should not throw exceptions)

};

/* ************************************************************************** */

template <typename Data>
class BTPreOrderMutableIterator : virtual public MutableIterator<Data>,
                                  virtual public BTPreOrderIterator<Data> {

private:

protected:

public:

  // Specific constructors
  inline BTPreOrderMutableIterator(MutableBinaryTree<Data>& other) : BTPreOrderIterator<Data>(other) {;}; // An iterator over a given mutable binary tree

  /* ************************************************************************ */

  // Copy constructor
  inline BTPreOrderMutableIterator(const BTPreOrderMutableIterator<Data>& other) : BTPreOrderIterator<Data>(other) {;};

  // Move constructor
  inline BTPreOrderMutableIterator(BTPreOrderMutableIterator<Data>&& other) noexcept : BTPreOrderIterator<Data>(std::move(other)) {;};

  /* ************************************************************************ */

  // Destructor
  virtual ~BTPreOrderMutableIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  inline BTPreOrderMutableIterator& operator=(const BTPreOrderMutableIterator& other);

  // Move assignment
  inline BTPreOrderMutableIterator& operator=(BTPreOrderMutableIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BTPreOrderMutableIterator& other) const noexcept { return BTPreOrderIterator<Data>::operator==(other); };
  inline bool operator!=(const BTPreOrderMutableIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)
  Data& operator*() override; // (throw std::out_of_range when terminated)

};

/* ************************************************************************** */

template <typename Data>
class BTPostOrderIterator : public virtual ForwardIterator<Data>, 
                            public virtual ResettableIterator<Data>{

private:

protected:

  const typename BinaryTree<Data>::Node* root=nullptr;
  const typename BinaryTree<Data>::Node* current=nullptr;
  StackLst<const typename BinaryTree<Data>::Node*> stack;

  const typename BinaryTree<Data>::Node* DeepestLeftLeaf(const typename BinaryTree<Data>::Node* actual);

public:

  // Specific constructors
  BTPostOrderIterator(const BinaryTree<Data>& other); // An iterator over a given binary tree

  /* ************************************************************************ */

  // Copy constructor
  BTPostOrderIterator(const BTPostOrderIterator& other);

  // Move constructor
  BTPostOrderIterator(BTPostOrderIterator&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  ~BTPostOrderIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  BTPostOrderIterator& operator=(const BTPostOrderIterator<Data>& other);

  // Move assignment
  BTPostOrderIterator& operator=(BTPostOrderIterator<Data>&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const BTPostOrderIterator& other) const noexcept;
  inline bool operator!=(const BTPostOrderIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)
  const Data& operator*() const; // (throw std::out_of_range when terminated)
  inline bool Terminated() const noexcept override { return (current==nullptr); }; // (should not throw exceptions)

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)
  BTPostOrderIterator<Data>& operator++() override; // (throw std::out_of_range when terminated)

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)
  inline void Reset() noexcept override { stack.Clear(); current=DeepestLeftLeaf(root); }; // (should not throw exceptions)

};

/* ************************************************************************** */

template <typename Data>
class BTPostOrderMutableIterator : virtual public MutableIterator<Data>,
                                   virtual public BTPostOrderIterator<Data> {

private:

protected:

public:

  // Specific constructors
  inline BTPostOrderMutableIterator(MutableBinaryTree<Data>& other) : BTPostOrderIterator<Data>(other) {;}; // An iterator over a given mutable binary tree

  /* ************************************************************************ */

  // Copy constructor
  inline BTPostOrderMutableIterator(const BTPostOrderMutableIterator& other) : BTPostOrderIterator<Data>(other) {;};

  // Move constructor
  inline BTPostOrderMutableIterator(BTPostOrderMutableIterator&& other) noexcept : BTPostOrderIterator<Data>(std::move(other)) {;};

  /* ************************************************************************ */

  // Destructor
  ~BTPostOrderMutableIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  inline BTPostOrderMutableIterator& operator=(const BTPostOrderMutableIterator& other);

  // Move assignment
  inline BTPostOrderMutableIterator& operator=(BTPostOrderMutableIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BTPostOrderMutableIterator& other) const noexcept { return BTPostOrderIterator<Data>::operator==(other); };
  inline bool operator!=(const BTPostOrderMutableIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)
  Data& operator*() override; // (throw std::out_of_range when terminated)

};

/* ************************************************************************** */

template <typename Data>
class BTInOrderIterator : virtual public ForwardIterator<Data>,
                          virtual public ResettableIterator<Data> {

private:

protected:

  const typename BinaryTree<Data>::Node* current=nullptr;
  const typename BinaryTree<Data>::Node* root=nullptr;
  StackLst<const typename BinaryTree<Data>::Node*> stack;

  const typename BinaryTree<Data>::Node* FindDeepestLeftLeaf(const typename BinaryTree<Data>::Node*);

public:

  // Specific constructors
  BTInOrderIterator(const BinaryTree<Data>& other); // An iterator over a given binary tree

  /* ************************************************************************ */

  // Copy constructor
  BTInOrderIterator(const BTInOrderIterator& other);

  // Move constructor
  BTInOrderIterator(BTInOrderIterator&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  virtual ~BTInOrderIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  BTInOrderIterator& operator=(const BTInOrderIterator& other);

  // Move assignment
  BTInOrderIterator& operator=(BTInOrderIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const BTInOrderIterator& other) const noexcept;
  inline bool operator!=(const BTInOrderIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)
  const Data& operator*() const override; // (throw std::out_of_range when terminated)
  inline bool Terminated() const noexcept override { return (current==nullptr); }; // (should not throw exceptions)

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)
  BTInOrderIterator<Data>& operator++() override; // (throw std::out_of_range when terminated)

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)
  inline void Reset() noexcept override { stack.Clear(); current=FindDeepestLeftLeaf(root); }; // (should not throw exceptions)

};

/* ************************************************************************** */

template <typename Data>
class BTInOrderMutableIterator : virtual public MutableIterator<Data>,
                                 virtual public BTInOrderIterator<Data> {

private:

protected:

public:

  // Specific constructors
  inline BTInOrderMutableIterator(MutableBinaryTree<Data>& other) : BTInOrderIterator<Data>(other) {;}; // An iterator over a given mutable binary tree

  /* ************************************************************************ */

  // Copy constructor
  inline BTInOrderMutableIterator(const BTInOrderMutableIterator& other) : BTInOrderIterator<Data>(other) {;};

  // Move constructor
  inline BTInOrderMutableIterator(BTInOrderMutableIterator&& other) noexcept : BTInOrderIterator<Data>(std::move(other)) {;};

  /* ************************************************************************ */

  // Destructor
  virtual ~BTInOrderMutableIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  inline BTInOrderMutableIterator& operator=(const BTInOrderMutableIterator& other);

  // Move assignment
  inline BTInOrderMutableIterator& operator=(BTInOrderMutableIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BTInOrderMutableIterator& other) const noexcept { return BTInOrderIterator<Data>::operator==(other); };
  inline bool operator!=(const BTInOrderMutableIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)
  Data& operator*() override; // (throw std::out_of_range when terminated)

};

/* ************************************************************************** */

template <typename Data>
class BTBreadthIterator : virtual public ForwardIterator<Data>, 
                          virtual public ResettableIterator<Data> {

private:

protected:

  const typename BinaryTree<Data>::Node* current=nullptr;
  const typename BinaryTree<Data>::Node* root=nullptr;
  QueueLst<const typename BinaryTree<Data>::Node*> queue;

public:

  // Specific constructors
  BTBreadthIterator(const BinaryTree<Data>& other); // An iterator over a given binary tree

  /* ************************************************************************ */

  // Copy constructor
  BTBreadthIterator(const BTBreadthIterator& other);

  // Move constructor
  BTBreadthIterator(BTBreadthIterator&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  virtual ~BTBreadthIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  BTBreadthIterator& operator=(const BTBreadthIterator& other);

  // Move assignment
  BTBreadthIterator& operator=(BTBreadthIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const BTBreadthIterator& other) const noexcept;
  inline bool operator!=(const BTBreadthIterator& other) const noexcept { return !(operator==(other)); }

  /* ************************************************************************ */

  // Specific member functions (inherited from Iterator)
  const Data& operator*() const; // (throw std::out_of_range when terminated)
  inline bool Terminated() const noexcept override { return (current==nullptr); }; // (should not throw exceptions)

  /* ************************************************************************ */

  // Specific member functions (inherited from ForwardIterator)
  BTBreadthIterator& operator++() override; // (throw std::out_of_range when terminated)

  /* ************************************************************************ */

  // Specific member functions (inherited from ResettableIterator)
  inline void Reset() noexcept override { queue.Clear(); current=root; }; // (should not throw exceptions)

};

/* ************************************************************************** */

template <typename Data>
class BTBreadthMutableIterator : virtual public MutableIterator<Data>,
                                 virtual public BTBreadthIterator<Data> {

private:

protected:

public:

  // Specific constructors
  inline BTBreadthMutableIterator(MutableBinaryTree<Data>& other) : BTBreadthIterator<Data>(other) {;}; // An iterator over a given mutable binary tree

  /* ************************************************************************ */

  // Copy constructor
  inline BTBreadthMutableIterator(const BTBreadthMutableIterator& other) : BTBreadthIterator<Data>(other) {;};

  // Move constructor
  inline BTBreadthMutableIterator(BTBreadthMutableIterator&& other) noexcept : BTBreadthIterator<Data>(std::move(other)) {;};

  /* ************************************************************************ */

  // Destructor
  ~BTBreadthMutableIterator() = default;

  /* ************************************************************************ */

  // Copy assignment
  inline BTBreadthMutableIterator& operator=(const BTBreadthMutableIterator& other);

  // Move assignment
  inline BTBreadthMutableIterator& operator=(BTBreadthMutableIterator&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BTBreadthMutableIterator& other) const noexcept { return BTBreadthIterator<Data>::operator==(other); };
  inline bool operator!=(const BTBreadthMutableIterator& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableIterator)
  Data& operator*() override; 

};

/* ************************************************************************** */

}

#include "binarytree.cpp"

#endif