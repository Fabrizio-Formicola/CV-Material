#include "binarytreevec.hpp"

namespace lasd {

/* ************************************************************************** */

// NodeVec

template <typename Data>
BinaryTreeVec<Data>::NodeVec::NodeVec(const Data &dat, int i, BinaryTreeVec<Data>* BT) {
    this->BT = BT;
    BT->Elements[i]=dat;  
    this->i=i;
}

template <typename Data>
BinaryTreeVec<Data>::NodeVec::NodeVec(Data&& dat, int i, BinaryTreeVec<Data>* BT) noexcept {
    this->BT = BT;
    std::swap(BT->Elements[i], dat);
    this->i=i;
}


template <typename Data>
bool BinaryTreeVec<Data>::NodeVec::HasLeftChild() const noexcept {
    return (i*2+1<(BT->NodeArray).Size()) && ((BT->NodeArray)[i*2+1] != nullptr);
}

template <typename Data>
bool BinaryTreeVec<Data>::NodeVec::HasRightChild() const noexcept {
    return i*2+2<(BT->NodeArray).Size() && (BT->NodeArray)[i*2+2] != nullptr;
}


template <typename Data>
const typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::NodeVec::LeftChild() const {
    if(HasLeftChild())
        return *(BT->NodeArray[i*2+1]);
    else
        throw std::out_of_range("Non esiste figlio sinistro in NodeVec::LeftChild()");
}

template <typename Data>
typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::NodeVec::LeftChild() {
    if(HasLeftChild())
        return *(BT->NodeArray[i*2+1]);
    else
        throw std::out_of_range("Non esiste figlio sinistro in NodeVec::LeftChild()");
}

template <typename Data>
const typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::NodeVec::RightChild() const {
    if(HasRightChild())
        return *(BT->NodeArray[i*2+2]);
    else
        throw std::out_of_range("Non esiste figlio destro in NodeVec::RightChild()");
}

template <typename Data>
typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::NodeVec::RightChild() {
    if(HasRightChild())
        return *(BT->NodeArray[i*2+2]);
    else
        throw std::out_of_range("Non esiste figlio destro in NodeVec::RightChild()");
}

/* ************************************************************************** */

// BinaryTreeVec

template <typename Data>
BinaryTreeVec<Data>::BinaryTreeVec(const MappableContainer<Data>& other) {
    this->Resize(other.Size());
    NodeArray.Resize(other.Size());
    int i = 0;
    this->size = other.Size();
    other.Map(
        [this, &i](const Data& dat){
            this->NodeArray[i] = new NodeVec(dat, i, this);
            i++;
        }
    );

}

template <typename Data>
BinaryTreeVec<Data>::BinaryTreeVec(MutableMappableContainer<Data>&& other) noexcept {
    this->Resize(other.Size());
    NodeArray.Resize(other.Size());
    int i = 0;
    other.Map(
        [this, &i](Data& dat){
            this->NodeArray[i] = new NodeVec(std::move(dat), i, this);
            i++;
        }
    );
}


template <typename Data>
BinaryTreeVec<Data>::BinaryTreeVec(const BinaryTreeVec<Data>& other) {
    this->Clear();
    this->Resize(other.Size());
    NodeArray.Resize(other.Size());
    for(int i=0; i<this->Size(); i++)
        NodeArray[i] = new NodeVec(other.Elements[i], i, this);
}

template <typename Data>
BinaryTreeVec<Data>::BinaryTreeVec(BinaryTreeVec<Data>&& other) noexcept {
    std::swap(this->size, other.size);
    std::swap(Elements, other.Elements);
    std::swap(NodeArray, other.NodeArray);
    for(int i=0; i<size; i++) {
        NodeArray[i]->BT = this;
    }
}


template <typename Data>
BinaryTreeVec<Data>::~BinaryTreeVec(){
    for(int i=0; i<NodeArray.Size(); i++){
        if(NodeArray[i]!=nullptr)
            delete NodeArray[i];
    }
}


template <typename Data>
BinaryTreeVec<Data>& BinaryTreeVec<Data>::operator=(const BinaryTreeVec& other) {
    this->Resize(other.Size());
    NodeArray.Resize(other.Size());
    for(int i=0; i<this->Size(); i++)
        NodeArray[i] = new NodeVec(other.Elements[i], i, this);
    return *this;
}

template <typename Data>
BinaryTreeVec<Data>& BinaryTreeVec<Data>::operator=(BinaryTreeVec &&other) noexcept {
    std::swap(Elements, other.Elements);
    std::swap(NodeArray, other.NodeArray);
    std::swap(size, other.size);
    for(int i=0; i<size; i++) {
        NodeArray[i]->BT = this;
    }
    for(int i=0; i<other.size; i++) {
        other.NodeArray[i]->BT = &other;
    }
    return *this;
}


template <typename Data>
const typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::Root() const {
    if(!this->Empty())
        return *NodeArray[0];
    else
        throw std::length_error("L'albero è vuoto in BinaryTreeVec<Data>::Root()");
}

template <typename Data>
typename BinaryTreeVec<Data>::NodeVec& BinaryTreeVec<Data>::Root() {
    if(!this->Empty())
        return *NodeArray[0];
    else
        throw std::length_error("L'albero è vuoto in BinaryTreeVec<Data>::Root()");
}


template <typename Data>
inline void BinaryTreeVec<Data>::Clear(){
    for(int i=0; i<this->Size(); i++){
        if(NodeArray[i]!=nullptr){
            delete NodeArray[i];
            NodeArray[i]=nullptr;
        }
    }
    Vector<Data>::Clear();
}
/* ************************************************************************** */

}
