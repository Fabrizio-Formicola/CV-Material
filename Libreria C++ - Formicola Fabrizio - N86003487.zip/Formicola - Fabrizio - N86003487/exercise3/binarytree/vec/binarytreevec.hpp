
#ifndef BINARYTREEVEC_HPP
#define BINARYTREEVEC_HPP

/* ************************************************************************** */

#include "../binarytree.hpp"
#include "../../container/container.hpp"
#include "../../container/foldable.hpp"
#include "../../container/mappable.hpp"
#include "../../container/linear.hpp"
#include "../../vector/vector.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class BinaryTreeVec : virtual public MutableBinaryTree<Data>,
                      virtual protected Vector<Data> {

private:

protected:

  struct NodeVec : virtual MutableBinaryTree<Data>::MutableNode{ // Must extend MutableNode

  friend class BinaryTreeVec<Data>;

  private:

    BinaryTreeVec<Data>* BT = nullptr;
    int i;

  protected:

  public:

    // Specific constructor
    NodeVec(const Data &dat, int i, BinaryTreeVec<Data>* BT);
    NodeVec(Data&& dat, int i, BinaryTreeVec<Data>* BT) noexcept;

    // Destructor
    inline virtual ~NodeVec() = default;

    // Copy assignment
    inline NodeVec& operator=(const NodeVec& other) {
      BT->Elements[i]=other.Elements[i];
      i = other.i;
      BT = other.BT;
      return *this;
    };

    // Move assignment
    inline NodeVec& operator=(NodeVec&& other) noexcept {
      std::swap(BT->Elements[i], other.Elements[i]);
      std::swap(i, other.i);
      std::swap(BT, other.BT);
      return *this;
    };

    // Specific member functions
    inline virtual Data& Element() noexcept override { return BT->Elements[i]; }
    inline virtual const Data& Element() const noexcept override { return BT->Elements[i]; }

    virtual bool HasLeftChild() const noexcept override;
    virtual bool HasRightChild() const noexcept override;

    virtual NodeVec& LeftChild() override;
    virtual const NodeVec& LeftChild() const override;

    virtual NodeVec& RightChild() override;
    virtual const NodeVec& RightChild() const override;

  };

  using Container::size;
  using Vector<Data>::Elements;
  Vector<NodeVec*> NodeArray = Vector<NodeVec*>(0);

public:

  // Default constructor
  BinaryTreeVec() = default;

  /* ************************************************************************ */

  // Specific constructors
  BinaryTreeVec(const MappableContainer<Data>& other); // A binary tree obtained from a MappableContainer
  BinaryTreeVec(MutableMappableContainer<Data>&& other) noexcept; // A binary tree obtained from a MutableMappableContainer

  /* ************************************************************************ */

  // Copy constructor
  BinaryTreeVec(const BinaryTreeVec<Data>& other);

  // Move constructor
  BinaryTreeVec(BinaryTreeVec<Data>&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  virtual ~BinaryTreeVec();

  /* ************************************************************************ */

  // Copy assignment
  BinaryTreeVec& operator=(const BinaryTreeVec& other);

  // Move assignment
  BinaryTreeVec& operator=(BinaryTreeVec&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  inline bool operator==(const BinaryTreeVec& other) const noexcept { return Vector<Data>::operator==(other); };
  inline bool operator!=(const BinaryTreeVec& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from BinaryTree)
  virtual const NodeVec& Root() const override; // Override BinaryTree member (throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from MutableBinaryTree)
  virtual NodeVec& Root() override; // Override MutableBinaryTree member (throw std::length_error when empty)

  /* ************************************************************************ */

  // Specific member function (inherited from ClearableContainer)
  virtual void Clear() override; // Override ClearableContainer member

  /* ************************************************************************ */

  using typename MappableContainer<Data>::MapFunctor;
  using typename MutableMappableContainer<Data>::MutableMapFunctor;
  using typename FoldableContainer<Data>::FoldFunctor;

  // Specific member functions (inherited from BreadthFoldableContainer)
  inline void BreadthFold(const FoldFunctor func, void* acc) const override { BinaryTree<Data>::BreadthFold(func, acc); }; // Override BreadthFoldableContainer member

  /* ************************************************************************ */

  // Specific member functions (inherited from BreadthMappableContainer)
  inline void BreadthMap(const MapFunctor func) const override { BinaryTree<Data>::BreadthMap(func); }; // Override BreadthMappableContainer member

  /* ************************************************************************ */

  // Specific member functions (inherited from MutableBreadthMappableContainer)
  inline void BreadthMap(MutableMapFunctor func) override { MutableBinaryTree<Data>::BreadthMap(func); }; // Override MutableBreadthMappableContainer member

  //Override per la scelta delle Fold e delle Map a seguito del Diamond Problem
  inline void Fold(const FoldFunctor func, void* acc) const override { BinaryTree<Data>::Fold(func, acc); };

  inline void PreOrderFold(FoldFunctor func, void* acc) const override { BinaryTree<Data>::PreOrderFold(func, acc); };
  inline void PostOrderFold(FoldFunctor func, void* acc) const override { BinaryTree<Data>::PostOrderFold(func, acc); };
  inline void InOrderFold(FoldFunctor func, void* acc) const override { BinaryTree<Data>::InOrderFold(func, acc); };

  inline void PreOrderMap(const MapFunctor func) const override { BinaryTree<Data>::PreOrderMap(func); };
  inline void PreOrderMap(MutableMapFunctor func) override { MutableBinaryTree<Data>::PreOrderMap(func); };  

  inline void PostOrderMap(const MapFunctor func) const override { BinaryTree<Data>::PostOrderMap(func); };
  inline void PostOrderMap(MutableMapFunctor func) override { MutableBinaryTree<Data>::PostOrderMap(func); };

  inline void Map(const MapFunctor func) const override { BinaryTree<Data>::Map(func); };
  inline void Map(MutableMapFunctor func) override { MutableBinaryTree<Data>::Map(func); };
  
};

/* ************************************************************************** */

}

#include "binarytreevec.cpp"

#endif
