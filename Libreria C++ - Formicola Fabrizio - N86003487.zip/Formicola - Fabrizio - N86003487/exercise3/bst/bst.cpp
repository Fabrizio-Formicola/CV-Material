#include "bst.hpp"

namespace lasd {

/* ************************************************************************** */

template <typename Data>
BST<Data>::BST(const MappableContainer<Data>& other){
  other.Map(
    [this](const Data& dat){
        Insert(dat);
    }
  );
}

template <typename Data>
BST<Data>::BST(MutableMappableContainer<Data>&& other) noexcept {
  other.Map(
    [this](Data& dat){
        Insert(std::move(dat));
    }
  );
}


template<typename Data>
BST<Data>::BST(const BST<Data>& other) : BinaryTreeLnk<Data>::BinaryTreeLnk(other) {}

template<typename Data>
BST<Data>::BST(BST<Data>&& other) noexcept : BinaryTreeLnk<Data>::BinaryTreeLnk(std::move(other)) {}


template <typename Data>
BST<Data>& BST<Data>::operator=(const BST<Data>& other){
  BinaryTreeLnk<Data>::operator=(other);
  return *this;
}

template <typename Data>
BST<Data>& BST<Data>::operator=(BST<Data>&& other) noexcept {
  BinaryTreeLnk<Data>::operator=(std::move(other));
  return *this;
}


template <typename Data>
bool BST<Data>::operator==(const BST& other) const noexcept {
  if (size == other.Size()) {
    BTInOrderIterator<Data> IterThis(*this);
    BTInOrderIterator<Data> IterOther(other);
    for (; !IterThis.Terminated(); ++IterThis, ++IterOther) {
      if((*IterThis)!=(*IterOther))
        return false;
    }
    return true;
  }
  return false;
}

/* ********************************* Specific member functions *************************************** */

template<typename Data>
const Data& BST<Data>::Min() const {
  if (root != nullptr)
    return FindPointerToMin(root)->elem;
  else
    throw std::length_error("L'albero è vuoto in Min()");
}

template <typename Data>
Data BST<Data>::MinNRemove(){
  if (root != nullptr)
    return DataNDelete(DetachMin(root));
  else
    throw std::length_error("L'albero è vuoto in MinNRemove()");
}

template<typename Data>
void BST<Data>::RemoveMin(){
  if (root != nullptr)
    delete DetachMin(root);
  else
    throw std::length_error("L'albero è vuoto in RemoveMin()");
}

template <typename Data>
const Data& BST<Data>::Max()const{
  if (root != nullptr)
    return FindPointerToMax(root)->elem;
  else
    throw std::length_error("L'albero è vuoto in Max()");
}

template <typename Data>
Data BST<Data>::MaxNRemove(){
  if (root != nullptr)
    return DataNDelete(DetachMax(root));
  else
    throw std::length_error("L'albero è vuoto in MaxNRemove()");
}

template<typename Data>
void BST<Data>::RemoveMax(){
  if (root != nullptr)
    delete DetachMax(root);
  else
    throw std::length_error("L'albero è vuoto in RemoveMax()");
}


template <typename Data>
const Data& BST<Data>::Predecessor(const Data& val) const {
  NodeLnk* const* ptr=&FindPointerToPredecessor(root,val);
  if (ptr != nullptr)
    return (*ptr)->elem;
  else
    throw std::length_error("Predecessore non trovato in Predecessor()");
}

template <typename Data>
Data BST<Data>::PredecessorNRemove(const Data& val){
  NodeLnk** ptr=&FindPointerToPredecessor(root,val);
  if (ptr != nullptr)
    return DataNDelete(Detach(*ptr));
  else
    throw std::length_error("Predecessore non trovato in PredecessorNRemove()");
}

template <typename Data>
void BST<Data>::RemovePredecessor(const Data& val){
  NodeLnk** ptr=&FindPointerToPredecessor(root,val);
  if (ptr != nullptr)
    delete Detach(*ptr);
  else
    throw std::length_error("Predecessore non trovato in RemovePredecessor()");
}

template <typename Data>
const Data& BST<Data>::Successor(const Data& val) const {
  NodeLnk* const* ptr=&FindPointerToSuccessor(root,val);
  if(ptr !=nullptr)
    return (*ptr)->elem;
  else
    throw std::length_error("Successore non trovato in Successor()");
}

template <typename Data>
Data BST<Data>::SuccessorNRemove(const Data& val){
  NodeLnk** ptr=&FindPointerToSuccessor(root,val);
  if (ptr != nullptr)
    return DataNDelete(Detach(*ptr));
  else
    throw std::length_error("Successore non trovato in SuccessorNRemove()");
}

template <typename Data>
void BST<Data>::RemoveSuccessor(const Data& val){
  NodeLnk **ptr = &FindPointerToSuccessor(root, val);
  if (ptr != nullptr)
    delete Detach(*ptr);
  else
    throw std::length_error("Successore non trovato in RemoveSuccessor()");
}

/* ********************************* DictionaryContainer functions *************************************** */

template <typename Data>
bool BST<Data>::Insert(const Data& dat){
  NodeLnk*& ptr=FindPointerTo(root, dat);
  if(ptr==nullptr){
    ptr=new NodeLnk(dat);
    size++;
    return true;
  }
  return false;
}

template <typename Data>
bool BST<Data>::Insert(Data&& dat){
  NodeLnk*& ptr=FindPointerTo(root, dat);
  if(ptr==nullptr){
    ptr=new NodeLnk(std::move(dat));
    size++;
    return true;
  }
  return false;
}

template <typename Data>
bool BST<Data>::Remove(const Data& dat) {
  NodeLnk*& ptr=FindPointerTo(root, dat);
  if(ptr!=nullptr){
    delete Detach(ptr);
    return true;
  }
  return false;
}

/* ********************************* Exists *************************************** */

template <typename Data>
bool BST<Data>::Exists(const Data& val) const noexcept {
  return (FindPointerTo(root, val) !=nullptr);
}

/* ********************************* Auxiliary member functions *************************************** */

template <typename Data>
Data BST<Data>::DataNDelete(NodeLnk* ptr){
  Data val {};
  std::swap(val, ptr->elem);
  delete ptr;
  return val;
}


template<typename Data>
typename BST<Data>::NodeLnk* BST<Data>::Detach(NodeLnk*& node) noexcept {
  if (node != nullptr) {
    if (node->l_child == nullptr)
      return Skip2Right(node);
    else if (node->r_child == nullptr)
      return Skip2Left(node);
    else {
      NodeLnk *max = DetachMax(node->l_child);
      std::swap(node->elem, max->elem);
      return max;
    }
  }
  return nullptr;
}

template<typename Data>
typename BST<Data>::NodeLnk* BST<Data>::DetachMin(NodeLnk*& node) noexcept {
  return Skip2Right(FindPointerToMin(node));
}

template<typename Data>
typename BST<Data>::NodeLnk* BST<Data>::DetachMax(NodeLnk*& node) noexcept {
  return Skip2Left(FindPointerToMax(node));
}


template <typename Data>
typename BST<Data>::NodeLnk* BST<Data>::Skip2Left(NodeLnk*& node) noexcept {
  NodeLnk* new_l_child = nullptr;
  if (node != nullptr) {
    std::swap(new_l_child, node->l_child);
    std::swap(new_l_child, node);
    size--;
  }
  return new_l_child;
}

template <typename Data>
typename BST<Data>::NodeLnk* BST<Data>::Skip2Right(NodeLnk*& node) noexcept {
  NodeLnk *new_r_child = nullptr;
  if (node != nullptr) {
    std::swap(new_r_child, node->r_child);
    std::swap(new_r_child, node);
    size--;
  }
  return new_r_child;
}


template<typename Data>
typename BST<Data>::NodeLnk* const& BST<Data>::FindPointerToMin(NodeLnk* const& node) const noexcept {
  NodeLnk* const* punt=&node;
  NodeLnk* current=node;
  if(current!=nullptr)
    while(current->l_child!=nullptr){
      punt=&current->l_child;
      current=current->l_child;
    }
  return *punt;
}

template<typename Data>
typename BST<Data>::NodeLnk* const& BST<Data>::FindPointerToMax(NodeLnk* const& node) const noexcept {
  NodeLnk* const* ptr=&node;
  NodeLnk* current=node;
  if(current!=nullptr)
    while(current->r_child!=nullptr){
      ptr=&current->r_child;
      current=current->r_child;
    }
  return *ptr;
}

template<typename Data>
typename BST<Data>::NodeLnk*& BST<Data>::FindPointerToMin(NodeLnk*& node) noexcept {
  return const_cast<NodeLnk*&>(static_cast<const BST<Data>*>(this)->FindPointerToMin(node));
}

template<typename Data>
typename BST<Data>::NodeLnk*& BST<Data>::FindPointerToMax(NodeLnk*& node) noexcept {
  return const_cast<NodeLnk*&>(static_cast<const BST<Data> *>(this)->FindPointerToMax(node));
}


template<typename Data>
typename BST<Data>::NodeLnk* const& BST<Data>::FindPointerTo(NodeLnk* const& node, Data val) const noexcept {
  NodeLnk *const *ptr = &node;
  NodeLnk *current = node;

  while (current != nullptr) {
    if (val > current->elem) {
      ptr = &current->r_child;
      current = current->r_child;
    }
    else if (val < current->elem) {
      ptr = &current->l_child;
      current = current->l_child;
    }
    else
      break;
  }
  return *ptr;
}

template<typename Data>
typename BST<Data>::NodeLnk*& BST<Data>::FindPointerTo(NodeLnk*& node, Data val) noexcept {
  return const_cast<NodeLnk*&>(static_cast<const BST<Data>*>(this)->FindPointerTo(node,val));
}


template<typename Data>
typename BST<Data>::NodeLnk* const& BST<Data>::FindPointerToPredecessor(NodeLnk* const& node, Data val) const noexcept {
  NodeLnk *const *predecessore = nullptr;
  NodeLnk *const *current = &node;
  while ((*current) != nullptr && (*current)->elem != val) {
    if ((*current)->elem > val) {
      current = &(*current)->l_child;
    }
    else if ((*current)->elem < val) {
      predecessore = current;
      current = &(*current)->r_child;
    }
  }
  if ((*current) != nullptr && (*current)->l_child != nullptr)
    predecessore = &FindPointerToMax((*current)->l_child);
  return *predecessore;
}

template<typename Data>
typename BST<Data>::NodeLnk* const& BST<Data>::FindPointerToSuccessor(NodeLnk* const& node, Data val) const noexcept {
  typename BST<Data>::NodeLnk *const *successor = nullptr;
  typename BST<Data>::NodeLnk *const *current = &node;
  while ((*current) != nullptr && (*current)->elem != val) {
    if ((*current)->elem < val)
      current = &(*current)->r_child;
    else if ((*current)->elem > val) {
      successor = current;
      current = &(*current)->l_child;
    }
  }
  if ((*current) != nullptr && (*current)->r_child != nullptr)
    successor = &FindPointerToMin((*current)->r_child);
  return *successor;
}

template<typename Data>
typename BST<Data>::NodeLnk*& BST<Data>::FindPointerToPredecessor(NodeLnk*& node, Data val) noexcept {
  return const_cast<NodeLnk*&>(static_cast<const BST<Data>*>(this)->FindPointerToPredecessor(node,val));
}

template<typename Data>
typename BST<Data>::NodeLnk*& BST<Data>::FindPointerToSuccessor(NodeLnk*& node, Data val) noexcept {
  return const_cast<NodeLnk*&>(static_cast<const BST<Data>*>(this)->FindPointerToSuccessor(node,val));
}


};
