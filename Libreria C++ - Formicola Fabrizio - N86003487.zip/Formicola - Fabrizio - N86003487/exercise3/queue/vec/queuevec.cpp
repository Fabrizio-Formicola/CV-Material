
namespace lasd {

/* ************************************************************************** */

template <typename Data>
QueueVec<Data>::QueueVec() {
    Vector<Data>::Resize(queue_starting_size);
}


template <typename Data>
QueueVec<Data>::QueueVec(const MappableContainer<Data>& cont)  {
    size = cont.Size()+1;
    Elements = new Data[size];
    ulong index = 0;
    cont.Map(
        [this, &index](const Data& dat) {
            Elements[index++] = dat;
        }
    );
    tail = cont.Size();
    head = 0;
}

template <typename Data>
QueueVec<Data>::QueueVec(MutableMappableContainer<Data>&& cont) noexcept {
    size = cont.Size()+1;
    Elements = new Data[size] {};
    ulong index = 0;
    cont.Map(
        [this, &index](Data& dat) {
            std::swap(Elements[index++] , dat);
        }
    );
    tail = cont.Size();
    head = 0;
}

/* ************************************************************************** */

template <typename Data>
QueueVec<Data>::QueueVec(const QueueVec<Data>& other) : Vector<Data>::Vector<Data>(other) {
    head=other.head;
    tail=other.tail;
}

template <typename Data>
QueueVec<Data>::QueueVec(QueueVec<Data>&& other) noexcept : Vector<Data>::Vector<Data>(std::move(other)) {
    std::swap(head, other.head);
    std::swap(tail, other.tail);
    other.Clear();
}

/* ************************************************************************** */

template <typename Data>
QueueVec<Data>& QueueVec<Data>::operator=(const QueueVec& other) {
    Clear();
    Vector<Data>::Resize(other.size);
    for(ulong i=0; i<other.Size(); i++){
        Elements[i] = other.operator[]((i+other.head)%other.size);
    }
    head=0;
    tail=other.Size();
    return *this;
}

template <typename Data>
QueueVec<Data>& QueueVec<Data>::operator=(QueueVec&& other) noexcept {
    Vector<Data>::operator=(std::move(other));
    std::swap(other.head, head);
    std::swap(other.tail, tail);
    return *this;
}

/* ************************************************************************** */

template <typename Data>
bool QueueVec<Data>::operator==(const QueueVec& other) const noexcept {
    bool result=true;
    if(Size()!=other.Size())
        return false;
    for(ulong i=0; i<Size(); i++) {
        if(Elements[(i+head)%size] != other[(i+other.head)%other.size])
            return false;
    }
    return true;
}

/* ************************************************************************** */

template <typename Data>
const Data& QueueVec<Data>::Head() const {
    if(Empty())
        throw std::length_error("QueueVec: the stack is empty in Head()");
    return Elements[head];
}

template <typename Data>
Data& QueueVec<Data>::Head() {
    if(Empty())
        throw std::length_error("QueueVec: the stack is empty in Head()");
    return Elements[head];
}

template <typename Data>
void QueueVec<Data>::Dequeue() {
    if(Empty())
        throw std::length_error("QueueVec: the stack is empty in Dequeue()");
    CheckNReduce();
    head=(head+1)%size;
}

template <typename Data>
Data QueueVec<Data>::HeadNDequeue() {
    if(Empty())
        throw std::length_error("QueueVec: the stack is empty in HeadNDequeue()");
    CheckNReduce();
    head=(head+1)%size;
    return Elements[((head-1+size)%size)];
}

template <typename Data>
void QueueVec<Data>::Enqueue(const Data& elem) {
    Elements[tail] = elem;
    CheckNExpand();
    tail=(tail+1)%size;
}

template <typename Data>
void QueueVec<Data>::Enqueue(Data&& elem) {
    std::swap(Elements[tail] , elem);
    CheckNExpand();
    tail=(tail+1)%size;
}

/* ************************************************************************** */

template <typename Data>
void QueueVec<Data>::Clear() {
    head=tail=0;
    CheckNReduce();
}

/* ************************************************************************** */

template <typename Data>
void QueueVec<Data>::CheckNExpand() {
    if((tail + 1) % size == head) {
        ulong new_size = (size * 2);
        Data* nuovo = new Data[new_size] {};
        for(ulong i = 0; i < size; ++i) {
            nuovo[i] = Elements[(i + head) % size];
        }
        std::swap(Elements, nuovo);
        delete[] nuovo;
        tail = Size();
        head = 0;
        size = new_size;
    }
}

template <typename Data>
void QueueVec<Data>::CheckNReduce() { 
    if(Size()<queue_starting_size)
        return;
    else if(Size() <= size * 0.4 ) {
        ulong new_size = (size * 0.6);
        Data* nuovo = new Data[new_size] {};
        for(ulong i = 0; i < Size(); ++i) {
            nuovo[i] = Elements[(i+head)%size];
        }
        delete[] Elements;
        Elements=nuovo;
        tail = Size();
        head=0;
        size = new_size;
    }
}


}
