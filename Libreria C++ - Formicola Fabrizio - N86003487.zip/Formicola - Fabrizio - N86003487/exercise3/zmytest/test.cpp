#ifndef MYTEST_CPP
#define MYTEST_CPP

#include <iostream>
#include <random>

using namespace std;

#define MAX_SIZE 200
#define SMALL_MAX_SIZE 20
#define SMALL_MAX_NUM 50
#define MIN_SIZE_0 0
#define MIN_SIZE_1 1

#define NUMERO_TEST_QV 1
#define NUMERO_TEST_SV 1
#define NUMERO_TEST_QL 1
#define NUMERO_TEST_SL 1
#define NUMERO_TEST_ITERATIVI 2
#define NUMERO_TEST_ITERATIVI_HT 10

static int static_test_index = 0;

default_random_engine gen(random_device{}());
uniform_int_distribution<int> genSize(MIN_SIZE_0,MAX_SIZE);
uniform_int_distribution<int> genSmallSize(MIN_SIZE_1,SMALL_MAX_SIZE);
uniform_int_distribution<int> genNum(INT32_MIN,INT32_MAX);
uniform_int_distribution<int> genSmallNum(0,SMALL_MAX_NUM);

#include "test.hpp"

/* ************************************************************************** */
/* ************************** FUNZIONI  ACCESSORIE ************************** */
/* ************************************************************************** */

template <typename Data>
void FoldAdd(const Data& dat, void* acc) {
  *((Data*) acc) += dat;
}

template <typename Data>
void FoldSumAndMultyplyPerPosition(const Data& dat, void* acc) {
  *((Data*) acc) += (dat*static_test_index++);
}

/* ************************************************************************** */
/* ************************** FUNZIONI ESERCIZIO 1 ************************** */
/* ************************************************************************** */

bool TestQueueVec(lasd::QueueVec<int> s2){
    bool test_result_qv = true;
    int numtest_qv = NUMERO_TEST_QV;
    ulong init_size = s2.Size();
    while(numtest_qv>0){
      lasd::QueueVec<int> s1(s2);
      int temp_size = genSize(gen);
      cout<<"\n\n****************************** INIZIO RIEMPIMENTO ******************************\n\n";  
      for(ulong i=0; i<temp_size; i++){
          int temp_num = genNum(gen);
          s1.Enqueue(temp_num);
          cout<<temp_num<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
      }
      cout<<"\n\n****************************** INIZIO SVUOTAMENTO ******************************\n\n";
      while(s1.Size()>0) {
          cout<<s1.HeadNDequeue()<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
          temp_size--;
      }
      if(temp_size+init_size!=0) {
          cout<<"\ntemp: "<<temp_size<<"\tinit: "<<init_size;
          test_result_qv = false;
          cout<<"\nVettore svuotato NON correttamente\n\n";
      } else
          cout<<"\nVettore svuotato correttamente\n\n";
      numtest_qv--;
    }
    return test_result_qv && !numtest_qv;
}

bool TestStackVec(lasd::StackVec<int> s2){
  bool test_result_sv = true;
  int numtest_sv = NUMERO_TEST_SV;
  ulong init_size = s2.Size();
  while(numtest_sv>0){
    lasd::StackVec<int> s1(s2);
    int temp_size = genSize(gen);
    cout<<"\n\n****************************** INIZIO RIEMPIMENTO ******************************\n\n";  
    for(ulong i=0; i<temp_size; i++){
      int temp_num = genNum(gen);
      s1.Push(temp_num);
      cout<<temp_num<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
    }
    cout<<"\n\n****************************** INIZIO SVUOTAMENTO ******************************\n\n";
    while(s1.Size()>0) {
      cout<<s1.TopNPop()<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
      temp_size--;
    }
    if(temp_size+init_size!=0) {
      cout<<"\ntemp: "<<temp_size<<"\tinit: "<<init_size;
      test_result_sv = false;
      cout<<"\nVettore svuotato NON correttamente\n\n";
    } else
        cout<<"\nVettore svuotato correttamente\n\n";
    numtest_sv--;
  }
  return test_result_sv && !numtest_sv;
}

bool TestQueueLst(lasd::QueueLst<int> s2){
  bool test_result_ql = true;
  int numtest_ql = NUMERO_TEST_QL;
  ulong init_size = s2.Size();
  while(numtest_ql>0){
    lasd::QueueLst<int> s1(s2);
    int temp_size = genSize(gen);
    cout<<"\n\n****************************** INIZIO RIEMPIMENTO ******************************\n\n";  
    for(ulong i=0; i<temp_size; i++){
      int temp_num = genNum(gen);
      s1.Enqueue(temp_num);
      cout<<temp_num<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
    }
    cout<<"\n\n****************************** INIZIO SVUOTAMENTO ******************************\n\n";
    while(s1.Size()>0) {
      cout<<s1.HeadNDequeue()<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<endls1.size<<endl;
      temp_size--;
    }
    if(temp_size+init_size!=0) {
      cout<<"\ntemp: "<<temp_size<<"\tinit: "<<init_size;
      test_result_ql = false;
      cout<<"\nVettore svuotato NON correttamente\n\n";
    } else
        cout<<"\nVettore svuotato correttamente\n\n";
    numtest_ql--;
  }
  return test_result_ql && !numtest_ql;
}

bool TestStackLst(lasd::StackLst<int> s2){
  bool test_result_sl = true;
  int numtest_sl = NUMERO_TEST_SL;
  ulong init_size = s2.Size();
  while(numtest_sl>0){
    lasd::StackLst<int> s1(s2);
    int temp_size = genSize(gen);
    cout<<"\n\n****************************** INIZIO RIEMPIMENTO ******************************\n\n";  
    for(ulong i=0; i<temp_size; i++){
      int temp_num = genNum(gen);
      s1.Push(temp_num);
      cout<<temp_num<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
    }
    cout<<"\n\n****************************** INIZIO SVUOTAMENTO ******************************\n\n";
    while(s1.Size()>0) {
      cout<<s1.TopNPop()<<"\t Size(): "<<s1.Size()<<endl;//"\t size: "<<s1.size<<endl;
      temp_size--;
    }
    if(temp_size+init_size!=0) {
      cout<<"\ntemp: "<<temp_size<<"\tinit: "<<init_size;
      test_result_sl = false;
      cout<<"\nLista svuotata NON correttamente\n\n";
    } else
        cout<<"\nLista svuotata correttamente\n\n";
    numtest_sl--;
  }
  return test_result_sl && !numtest_sl;
}


/* ************************************************************************** */

bool TestCopyQueueVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::QueueVec<int> qv1(v1);
  lasd::QueueVec<int> qv2(qv1);

  if(qv1!=qv2)
    correct=false;
  while(qv1.Size()>0)
    cout<<qv1.HeadNDequeue()<<"\t";
  cout<<endl;
  while(qv2.Size()>0)
    cout<<qv2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(qv1!=qv2)
    correct=false;
  cout<<endl;
  return correct;
}

bool TestCopyQueueVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::QueueVec<int> qv3(l1);
  lasd::QueueVec<int> qv4(qv3);

  if(qv3!=qv4)
    correct=false;
  while(qv3.Size()>0)
    cout<<qv3.HeadNDequeue()<<"\t";
  cout<<endl;
  while(qv4.Size()>0)
    cout<<qv4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(qv3!=qv4)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyQueueLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::QueueLst<int> ql1(l2);
  lasd::QueueLst<int> ql2(ql1);
  
  if(ql1!=ql2)
    correct=false;
  while(ql1.Size()>0)
    cout<<ql1.HeadNDequeue()<<"\t";
  cout<<endl;
  while(ql2.Size()>0)
    cout<<ql2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(ql1!=ql2)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyQueueLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::QueueLst<int> ql3(v2);
  lasd::QueueLst<int> ql4(ql3);

  if(ql3!=ql4)
    correct=false;
  while(ql3.Size()>0)
    cout<<ql3.HeadNDequeue()<<"\t";
  cout<<endl;
  while(ql4.Size()>0)
    cout<<ql4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(ql3!=ql4)
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestCopyAssignementQueueVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::QueueVec<int> qv1(v1);
  lasd::QueueVec<int> qv2;
  qv2=qv1;

  if(qv1!=qv2)
    correct=false;
  while(qv1.Size()>0)
    cout<<qv1.HeadNDequeue()<<"\t";
  cout<<endl;
  while(qv2.Size()>0)
    cout<<qv2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(qv1!=qv2)
    correct=false;
  cout<<endl;
  return correct;
}

bool TestCopyAssignementQueueVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::QueueVec<int> qv3(l1);
  lasd::QueueVec<int> qv4;
  qv4=qv3;

  if(qv3!=qv4)
    correct=false;
  while(qv3.Size()>0)
    cout<<qv3.HeadNDequeue()<<"\t";
  cout<<endl;
  while(qv4.Size()>0)
    cout<<qv4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(qv3!=qv4)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyAssignementQueueLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::QueueLst<int> ql1(l2);
  lasd::QueueLst<int> ql2;
  ql2=ql1;
  
  if(ql1!=ql2)
    correct=false;
  while(ql1.Size()>0)
    cout<<ql1.HeadNDequeue()<<"\t";
  cout<<endl;
  while(ql2.Size()>0)
    cout<<ql2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(ql1!=ql2)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyAssignementQueueLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::QueueLst<int> ql3(v2);
  lasd::QueueLst<int> ql4;
  ql4=ql3;

  if(ql3!=ql4)
    correct=false;
  while(ql3.Size()>0)
    cout<<ql3.HeadNDequeue()<<"\t";
  cout<<endl;
  while(ql4.Size()>0)
    cout<<ql4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(ql3!=ql4)
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestMoveQueueVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::QueueVec<int> qv1(move(v1));
  lasd::QueueVec<int> qv2(move(qv1));

  if(!(qv1.Empty()))
    correct=false;
  if(v1.Empty())
    correct=false;
  cout<<"v1 Empty? "<<v1.Empty()<<endl;
  cout<<"qv1 Empty? "<<qv1.Empty()<<endl;
  cout<<"qv2 Empty? "<<qv2.Empty()<<endl;
  while(qv2.Size()>0)
    cout<<qv2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(qv2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

bool TestMoveQueueVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::QueueVec<int> qv3(move(l1));
  lasd::QueueVec<int> qv4(move(qv3));

  if(!(qv3.Empty()))
    correct=false;
  if(l1.Empty())
    correct=false;
  cout<<"11 Empty? "<<l1.Empty()<<endl;
  cout<<"qv3 Empty? "<<qv3.Empty()<<endl;
  cout<<"qv4 Empty? "<<qv4.Empty()<<endl;
  while(qv4.Size()>0)
    cout<<qv4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(qv4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveQueueLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::QueueLst<int> ql1(move(l2));
  lasd::QueueLst<int> ql2(move(ql1));
  
  if(!(ql1.Empty()))
    correct=false;
  if(l2.Empty())
    correct=false;
  cout<<"l2 Empty? "<<l2.Empty()<<endl;
  cout<<"ql1 Empty? "<<ql1.Empty()<<endl;
  cout<<"ql2 Empty? "<<ql2.Empty()<<endl;
  while(ql2.Size()>0)
    cout<<ql2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(ql2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveQueueLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::QueueVec<int> ql3(move(v2));
  lasd::QueueVec<int> ql4(move(ql3));

  if(!(ql3.Empty()))
    correct=false;
  if(v2.Empty())
    correct=false;
  cout<<"v2 Empty? "<<v2.Empty()<<endl;
  cout<<"ql3 Empty? "<<ql3.Empty()<<endl;
  cout<<"ql4 Empty? "<<ql4.Empty()<<endl;
  while(ql4.Size()>0)
    cout<<ql4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(ql4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestMoveAssignementQueueVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::QueueVec<int> qv1(move(v1));
  lasd::QueueVec<int> qv2;
  qv2=move(qv1);

  if(!(qv1.Empty()))
    correct=false;
  if(v1.Empty())
    correct=false;
  cout<<"v1 Empty? "<<v1.Empty()<<endl;
  cout<<"qv1 Empty? "<<qv1.Empty()<<endl;
  cout<<"qv2 Empty? "<<qv2.Empty()<<endl;
  while(qv2.Size()>0)
    cout<<qv2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(qv2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

bool TestMoveAssignementQueueVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::QueueVec<int> qv3(move(l1));
  lasd::QueueVec<int> qv4;
  qv4=move(qv3);

  if(!(qv3.Empty()))
    correct=false;
  if(l1.Empty())
    correct=false;
  cout<<"l1 Empty? "<<l1.Empty()<<endl;
  cout<<"qv3 Empty? "<<qv3.Empty()<<endl;
  cout<<"qv4 Empty? "<<qv4.Empty()<<endl;
  while(qv4.Size()>0)
    cout<<qv4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(qv4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveAssignementQueueLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::QueueLst<int> ql1(move(l2));
  lasd::QueueLst<int> ql2;
  ql2=move(ql1);
  
  if(!(ql1.Empty()))
    correct=false;
  if(l2.Empty())
    correct=false;
  cout<<"l2 Empty? "<<l2.Empty()<<endl;
  cout<<"ql1 Empty? "<<ql1.Empty()<<endl;
  cout<<"ql2 Empty? "<<ql2.Empty()<<endl;
  while(ql2.Size()>0)
    cout<<ql2.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(ql2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveAssignementQueueLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::QueueVec<int> ql3(move(v2));
  lasd::QueueVec<int> ql4;
  ql4=move(ql3);

  if(!(ql3.Empty()))
    correct=false;
  if(v2.Empty())
    correct=false;
  cout<<"v2 Empty? "<<v2.Empty()<<endl;
  cout<<"ql3 Empty? "<<ql3.Empty()<<endl;
  cout<<"ql4 Empty? "<<ql4.Empty()<<endl;
  while(ql4.Size()>0)
    cout<<ql4.HeadNDequeue()<<"\t";
  cout<<endl;
  if(!(ql4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestCopyStackVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::StackVec<int> sv1(v1);
  lasd::StackVec<int> sv2(sv1);

  if(sv1!=sv2)
    correct=false;
  while(sv1.Size()>0)
    cout<<sv1.TopNPop()<<"\t";
  cout<<endl;
  while(sv2.Size()>0)
    cout<<sv2.TopNPop()<<"\t";
  cout<<endl;
  if(sv1!=sv2)
    correct=false;
  cout<<endl;
  return correct;
}

bool TestCopyStackVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::StackVec<int> sv3(l1);
  lasd::StackVec<int> sv4(sv3);

  if(sv3!=sv4)
    correct=false;
  while(sv3.Size()>0)
    cout<<sv3.TopNPop()<<"\t";
  cout<<endl;
  while(sv4.Size()>0)
    cout<<sv4.TopNPop()<<"\t";
  cout<<endl;
  if(sv3!=sv4)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyStackLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::StackLst<int> sl1(l2);
  lasd::StackLst<int> sl2(sl1);
  
  if(sl1!=sl2)
    correct=false;
  while(sl1.Size()>0)
    cout<<sl1.TopNPop()<<"\t";
  cout<<endl;
  while(sl2.Size()>0)
    cout<<sl2.TopNPop()<<"\t";
  cout<<endl;
  if(sl1!=sl2)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyStackLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::StackLst<int> sl3(v2);
  lasd::StackLst<int> sl4(sl3);

  if(sl3!=sl4)
    correct=false;
  while(sl3.Size()>0)
    cout<<sl3.TopNPop()<<"\t";
  cout<<endl;
  while(sl4.Size()>0)
    cout<<sl4.TopNPop()<<"\t";
  cout<<endl;
  if(sl3!=sl4)
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestCopyAssignementStackVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::StackVec<int> sv1(v1);
  lasd::StackVec<int> sv2;
  sv2=sv1;

  if(sv1!=sv2)
    correct=false;
  while(sv1.Size()>0)
    cout<<sv1.TopNPop()<<"\t";
  cout<<endl;
  while(sv2.Size()>0)
    cout<<sv2.TopNPop()<<"\t";
  cout<<endl;
  if(sv1!=sv2)
    correct=false;
  cout<<endl;
  return correct;
}

bool TestCopyAssignementStackVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::StackVec<int> sv3(l1);
  lasd::StackVec<int> sv4;
  sv4=sv3;

  if(sv3!=sv4)
    correct=false;
  while(sv3.Size()>0)
    cout<<sv3.TopNPop()<<"\t";
  cout<<endl;
  while(sv4.Size()>0)
    cout<<sv4.TopNPop()<<"\t";
  cout<<endl;
  if(sv3!=sv4)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyAssignementStackLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::StackLst<int> sl1(l2);
  lasd::StackLst<int> sl2;
  sl2=sl1;
  
  if(sl1!=sl2)
    correct=false;
  while(sl1.Size()>0)
    cout<<sl1.TopNPop()<<"\t";
  cout<<endl;
  while(sl2.Size()>0)
    cout<<sl2.TopNPop()<<"\t";
  cout<<endl;
  if(sl1!=sl2)
    correct=false;
  cout<<endl;
  return correct;
}


bool TestCopyAssignementStackLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::StackLst<int> sl3(v2);
  lasd::StackLst<int> sl4;
  sl4=sl3;

  if(sl3!=sl4)
    correct=false;
  while(sl3.Size()>0)
    cout<<sl3.TopNPop()<<"\t";
  cout<<endl;
  while(sl4.Size()>0)
    cout<<sl4.TopNPop()<<"\t";
  cout<<endl;
  if(sl3!=sl4)
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestMoveStackVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::StackVec<int> sv1(move(v1));
  lasd::StackVec<int> sv2(move(sv1));

  if(!(sv1.Empty()))
    correct=false;
  if(v1.Empty())
    correct=false;
  cout<<"v1 Empty? "<<v1.Empty()<<endl;
  cout<<"sv1 Empty? "<<sv1.Empty()<<endl;
  cout<<"sv2 Empty? "<<sv2.Empty()<<endl;
  while(sv2.Size()>0)
    cout<<sv2.TopNPop()<<"\t";
  cout<<endl;
  if(!(sv2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

bool TestMoveStackVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::StackVec<int> sv3(move(l1));
  lasd::StackVec<int> sv4(move(sv3));

  if(!(sv3.Empty()))
    correct=false;
  if(l1.Empty())
    correct=false;
  cout<<"11 Empty? "<<l1.Empty()<<endl;
  cout<<"sv3 Empty? "<<sv3.Empty()<<endl;
  cout<<"sv4 Empty? "<<sv4.Empty()<<endl;
  while(sv4.Size()>0)
    cout<<sv4.TopNPop()<<"\t";
  cout<<endl;
  if(!(sv4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveStackLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::StackLst<int> sl1(move(l2));
  lasd::StackLst<int> sl2(move(sl1));
  
  if(!(sl1.Empty()))
    correct=false;
  if(l2.Empty())
    correct=false;
  cout<<"l2 Empty? "<<l2.Empty()<<endl;
  cout<<"sl1 Empty? "<<sl1.Empty()<<endl;
  cout<<"sl2 Empty? "<<sl2.Empty()<<endl;
  while(sl2.Size()>0)
    cout<<sl2.TopNPop()<<"\t";
  cout<<endl;
  if(!(sl2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveStackLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::StackLst<int> sl3(move(v2));
  lasd::StackLst<int> sl4(move(sl3));

  if(!(sl3.Empty()))
    correct=false;
  if(v2.Empty())
    correct=false;
  cout<<"v2 Empty? "<<v2.Empty()<<endl;
  cout<<"sl3 Empty? "<<sl3.Empty()<<endl;
  cout<<"sl4 Empty? "<<sl4.Empty()<<endl;
  while(sl4.Size()>0)
    cout<<sl4.TopNPop()<<"\t";
  cout<<endl;
  if(!(sl4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestMoveAssignementStackVecFromVec(){
  bool correct=true;
  lasd::Vector<int> v1(genSmallSize(gen));
  for(int i=0; i<v1.Size(); i++){
    int temp_num = genSmallNum(gen);
    v1[i]=temp_num;
  }
  lasd::StackVec<int> sv1(move(v1));
  lasd::StackVec<int> sv2;
  sv2=move(sv1);

  if(!(sv1.Empty()))
    correct=false;
  if(v1.Empty())
    correct=false;
  cout<<"v1 Empty? "<<v1.Empty()<<endl;
  cout<<"sv1 Empty? "<<sv1.Empty()<<endl;
  cout<<"sv2 Empty? "<<sv2.Empty()<<endl;
  while(sv2.Size()>0)
    cout<<sv2.TopNPop()<<"\t";
  cout<<endl;
  if(!(sv2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

bool TestMoveAssignementStackVecFromLst(){
  bool correct=true;
  lasd::List<int> l1;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l1.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }
  lasd::StackVec<int> sv3(move(l1));
  lasd::StackVec<int> sv4;
  sv4=move(sv3);

  if(!(sv3.Empty()))
    correct=false;
  if(l1.Empty())
    correct=false;
  cout<<"l1 Empty? "<<l1.Empty()<<endl;
  cout<<"sv3 Empty? "<<sv3.Empty()<<endl;
  cout<<"sv4 Empty? "<<sv4.Empty()<<endl;
  while(sv4.Size()>0)
    cout<<sv4.TopNPop()<<"\t";
  cout<<endl;
  if(!(sv4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveAssignementStackLstFromLst(){
  bool correct=true;
  lasd::List<int> l2;
  int temp_size = genSmallSize(gen);
  for(int i=0; i<(temp_size*2); i++){
    int temp_num1 = genSmallNum(gen);
    l2.InsertAtBack(temp_num1);
    int temp_num2 = genSmallNum(gen);
    l2.InsertAtFront(temp_num2);
  }
  lasd::StackLst<int> sl1(move(l2));
  lasd::StackLst<int> sl2;
  sl2=move(sl1);
  
  if(!(sl1.Empty()))
    correct=false;
  if(sl2.Empty())
    correct=false;
  cout<<"l2 Empty? "<<l2.Empty()<<endl;
  cout<<"sl1 Empty? "<<sl1.Empty()<<endl;
  cout<<"sl2 Empty? "<<sl2.Empty()<<endl;
  while(sl2.Size()>0)
    cout<<sl2.TopNPop()<<"\t";
  cout<<endl;
  if(!(sl2.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}


bool TestMoveAssignementStackLstFromVec(){
  bool correct=true;
  lasd::Vector<int> v2(genSmallSize(gen));
  for(int i=0; i<v2.Size(); i++){
    int temp_num = genSmallNum(gen);
    v2[i]=temp_num;
  }
  lasd::StackLst<int> sl3;
  sl3=move(v2);
  lasd::StackLst<int> sl4;
  sl4=move(sl3);

  if(!(sl3.Empty()))
    correct=false;
  if(v2.Empty())
    correct=false;
  cout<<"v2 Empty? "<<v2.Empty()<<endl;
  cout<<"sl3 Empty? "<<sl3.Empty()<<endl;
  cout<<"sl4 Empty? "<<sl4.Empty()<<endl;
  while(sl4.Size()>0)
    cout<<sl4.TopNPop()<<"\t";
  cout<<endl;
  if(!(sl4.Empty()))
    correct=false;
  cout<<endl;
  return correct;
}

/* ************************************************************************** */

bool TestEqualVector(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::Vector<int> v1(temp_size);
    lasd::Vector<int> v2(temp_size);
    for(int i=0; i<temp_size; i++) v2[i]=v1[i]=genNum(gen);
    correct&=(v1==v2);
    v1[genSize(gen)%temp_size]=genNum(gen);
    correct&=!(v1==v2);
    v1.Clear();
    v2.Clear();
    correct&=(v1==v2);
    return correct;
}

bool TestEqualList(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::List<int> l1;
    lasd::List<int> l2;
    for(int i=0; i<temp_size; i++){
        int temp_num = genNum(gen);
        l1.InsertAtBack(temp_num);
        l2.InsertAtBack(temp_num);
    } 
    correct&=(l1==l2);
    l1[genSize(gen)%temp_size]=genNum(gen);
    correct&=(l1!=l2);
    l1.Clear();
    l2.Clear();
    correct&=(l1==l2);
    return correct;
}

bool TestEqualStackVec(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::StackVec<int> s1;
    lasd::StackVec<int> s2;
    for(int i=0; i<temp_size; i++){
        int temp_num = genNum(gen);
        s1.Push(temp_num);
        s2.Push(temp_num);
    } 
    correct&=(s1==s2);
    s2.Pop();
    s2.Push(genNum(gen));
    correct&=(s1!=s2);
    s1.Clear();
    s2.Clear();
    correct&=(s1==s2);
    return correct;
}

bool TestEqualStackLst(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::StackLst<int> s1;
    lasd::StackLst<int> s2;
    for(int i=0; i<temp_size; i++) {
        int temp_num = genNum(gen);
        s1.Push(temp_num);
        s2.Push(temp_num);
    } 
    correct&=(s1==s2);
    s2.Pop();
    s2.Push(genNum(gen));
    correct&=(s1!=s2);
    s1.Clear();
    s2.Clear();
    correct&=(s1==s2);
    return correct;
}

bool TestEqualQueueVec(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::QueueVec<int> s1;
    lasd::QueueVec<int> s2;
    for(int i=0; i<temp_size; i++) {
        int temp_num = genNum(gen);
        s1.Enqueue(temp_num);
        s2.Enqueue(temp_num);
    } 
    correct&=(s1==s2);
    s2.Dequeue();
    s2.Enqueue(genNum(gen));
    correct&=(s1!=s2);
    s1.Clear();
    s2.Clear();
    correct&=(s1==s2);
    return correct;
}

bool TestEqualQueueLst(){
    bool correct=true;
    int temp_size = genSize(gen)+1;
    lasd::QueueLst<int> s1;
    lasd::QueueLst<int> s2;
    for(int i=0; i<temp_size; i++) {
        int temp_num = genNum(gen);
        s1.Enqueue(temp_num);
        s2.Enqueue(temp_num);
    } 
    correct&=(s1==s2);
    s2.Dequeue();
    s2.Enqueue(genNum(gen));
    correct&=(s1!=s2);
    s1.Clear();
    s2.Clear();
    correct&=(s1==s2);
    return correct;
}

/* ************************************************************************** */


bool TestInsertCopyInDictionary(){
  bool inserted=false;
  bool isThere=false;

  int temp_num1=genSmallNum(gen);
  cout<<"numero creato= "<<temp_num1<<endl;

  lasd::List<int> l1;
  for(int i=0; i<genSmallSize(gen); i++){
    int temp_num2=genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }

  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    if(l1[i]==temp_num1)
      isThere=true;
  }
  cout<<endl;

  if(l1.Insert(temp_num1)){
    inserted=true;
    cout<<"Elemento inserito!"<<endl;
    for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    }
    cout<<endl;
    if (isThere==true)
      return false;
  }
  else
    cout<<"Elemento NON inserito!"<<endl;
  
  return true;
}

bool TestInsertMoveInDictionary(){
  bool inserted=false;
  bool isThere=false;

  int temp_num1=genSmallNum(gen);
  cout<<"numero creato= "<<temp_num1<<endl;

  lasd::List<int> l1;
  for(int i=0; i<genSmallSize(gen); i++){
    int temp_num2=genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }

  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    if(l1[i]==temp_num1)
      isThere=true;
  }
  cout<<endl;

  if(l1.Insert(move(temp_num1))){
    inserted=true;
    cout<<"Elemento inserito!"<<endl;
    for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    }
    cout<<endl;
    if (isThere==true)
      return false;
  }
  else
    cout<<"Elemento NON inserito!"<<endl;
  
  return true;
}


bool TestRemoveInDictionary(){
  bool result=true;
  bool isThere=false;

  int temp_num1=genSmallNum(gen);
  cout<<"numero creato= "<<temp_num1<<endl;

  lasd::List<int> l1;
  for(int i=0; i<genSmallSize(gen); i++){
    int temp_num2=genSmallNum(gen);
    l1.InsertAtFront(temp_num2);
  }

  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    if(l1[i]==temp_num1)
      isThere=true;
  }
  cout<<endl;

  if(l1.Remove(temp_num1)){
    result=true;
    cout<<"Elemento rimosso!"<<endl;
    for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
    }
    cout<<endl;
    if (isThere==false)
      return false;
  }
  else
    cout<<"Elemento NON rimosso!"<<endl;
  
  return true;
}



bool TestInsertAllCopyInDictionary(){
  bool result=false;

  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=6;
  v2[1]=7;
  v2[2]=8;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.InsertAll(v1);
  bool test2=l1.InsertAll(v2);
  if(!(test1) && test2)
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}

bool TestInsertAllMoveInDictionary(){
  bool result=false;

  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=6;
  v2[1]=7;
  v2[2]=8;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.InsertAll(move(v1));
  bool test2=l1.InsertAll(move(v2));
  if(!(test1) && test2)
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}

bool TestInsertSomeCopyInDictionary(){
  bool result=false;

  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=3;
  v2[1]=4;
  v2[2]=5;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.InsertSome(v1);
  bool test2=l1.InsertSome(v2);
  if(test1 && !(test2))
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}

bool TestInsertSomeMoveInDictionary(){
  bool result=false;

  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=3;
  v2[1]=4;
  v2[2]=5;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.InsertSome(move(v1));
  bool test2=l1.InsertSome(move(v2));
  if(test1 && !(test2))
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}


bool TestRemoveAllInDictionary(){
  bool result=false;

  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=4;
  v2[1]=5;
  v2[2]=6;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);
  l1.InsertAtBack(6);
  l1.InsertAtBack(7);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.RemoveAll(v1);
  bool test2=l1.RemoveAll(v2);
  if(!(test1) && test2)
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}


bool TestRemoveSomeInDictionary(){
  bool result=false;
  lasd::Vector<int> v1(3);
  v1[0]=1;
  v1[1]=2;
  v1[2]=3;

  lasd::Vector<int> v2(3);
  v2[0]=6;
  v2[1]=7;
  v2[2]=8;

  lasd::List<int> l1;
  l1.InsertAtBack(3);
  l1.InsertAtBack(4);
  l1.InsertAtBack(5);

  cout<<"vector 1: ";
  for(int i=0; i<v1.Size(); i++){
    cout<<v1[i]<<"-";
  }
  cout<<endl;
  cout<<"vector 2: ";
  for(int i=0; i<v2.Size(); i++){
    cout<<v2[i]<<"-";
  }
  cout<<endl;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;

  bool test1=l1.RemoveSome(v1);
  bool test2=l1.RemoveSome(v2);
  if(test1 && !(test2))
    result=true;
  cout<<"List: ";
  for(int i=0; i<l1.Size(); i++){
    cout<<l1[i]<<"->";
  }
  cout<<endl;
  cout<<endl;

  return result;
}

/* ************************************************************************** */

bool TestSortInt(){
  bool result=true;
  lasd::Vector<int> v1(genSize(gen)+1);
  for(int i=0; i<v1.Size(); i++){
    v1[i]=genNum(gen);
  }
  v1.Sort();
  for(int i=1; i<v1.Size(); i++)
    result&=(v1[i-1]<=v1[i]);

  return result;
}

bool TestSortChar(){
  bool result=true;
  lasd::Vector<int> v1(genSize(gen)+1);
  for(int i=0; i<v1.Size(); i++){
    v1[i]=(char)genSmallNum(gen);
  }
  v1.Sort();
  for(int i=1; i<v1.Size(); i++)
    result&=(v1[i-1]<=v1[i]);

  return result;
}

bool TestSortEmpty(){
  bool result=true;
  lasd::Vector<int> v1(0);
  v1.Sort();
  for(int i=1; i<v1.Size(); i++)
    result&=(v1[i-1]<=v1[i]);

  return result;
}


/* ************************************************************************** */
/* ************************** FUNZIONI ESERCIZIO 2 ************************** */
/* ************************************************************************** */

bool TestCompareBSTCopy(){
  bool result=true;
  int generated_size = genSize(gen);
  int generated_val;
  lasd::Vector<int> vec(generated_size);
  lasd::BST<int> BST1;
  for(int i=0; i<generated_size; i++){
    generated_val = genNum(gen);
    vec[i]=generated_val;
    BST1.Insert(generated_val);
  }
  lasd::BST<int> BST2(vec);
  lasd::BST<int> BST3(BST1);
  lasd::BST<int> BST4;
  BST4 = BST1;

  if(BST1!=BST2){
    result=false;
    cout<<"Costruttore da MutableMappableContainer errato"<<endl;
  }
  if(BST1!=BST3){
    result=false;
    cout<<"Costruttore da BST errato"<<endl;
  }
  if(BST1!=BST4){
    result=false;
    cout<<"Operatore di assegnazione errato"<<endl;
  }

  return result;
}

bool TestCompareBSTMove(){
  bool result=true;
  int generated_size = genSize(gen);
  int generated_val;
  lasd::Vector<int> vec(generated_size);
  lasd::BST<int> BST1;
  for(int i=0; i<generated_size; i++){
    generated_val = genNum(gen);
    vec[i]=generated_val;
    BST1.Insert(generated_val);
  }
  lasd::BST<int> BST2(std::move(vec));

  if(BST1!=BST2){
    result=false;
    cout<<"Costruttore move da MutableMappableContainer errato"<<endl;
  }

  lasd::BST<int> BST3(std::move(BST1));

  if(BST2!=BST3){
    result=false;
    cout<<"Costruttore move da BST errato"<<endl;
  }

  if(!(BST1.Empty())){
    result=false;
    cout<<"Il move constructor di BST non ha cancellato other"<<endl;
  }

  lasd::BST<int> BST4;
  BST4 = std::move(BST2);

  if(BST3!=BST4){
    result=false;
    cout<<"Operatore di assegnazione move errato"<<endl;
  }

  if(!(BST2.Empty())){
    result=false;
    cout<<"L'operatore di assegnazione move di BST non ha cancellato other"<<endl;
  }

  return result;
}

bool TestCompareBTAndBSTFromLstCopy(){
  bool result=true;

  lasd::List<int> l1;
  int temp_size = genSize(gen)+2;
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      l1.Insert(temp_val);
  }
  lasd::BST<int> BST1(l1);
  lasd::BST<int> BST2(l1);
  lasd::BinaryTreeLnk<int> BTL(l1);
  lasd::BinaryTreeVec<int> BTV(l1);

  if(BST1!=BST2)
    result=false;
  if(BST1.Size()>=20){
    if(BST1.lasd::BinaryTree<int>::operator==(BTL))
      result=false;
    if(BST1.lasd::BinaryTree<int>::operator==(BTV))
      result=false;
  }
  if(BST2.Size()>=2){
    BST2.MinNRemove();
    BST2.MaxNRemove();
    if(BST1==BST2)
      result=false;
  }
  
  lasd::List<int> staticList;
  lasd::BST<int> staticBST;
  
  staticList.InsertAtFront(2);
  staticList.InsertAtFront(1);
  staticList.InsertAtFront(3);

  staticBST.InsertAll(staticList);
  lasd::BinaryTreeLnk<int> staticBTL(staticList);
  lasd::BinaryTreeVec<int> staticBTV(staticList);

  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTV))
    result=false;
  if(!staticBST.Remove(2))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTV))
    result=false;

  return result;
}

bool TestCompareBTAndBSTFromLstMove(){
  bool result=true;

  lasd::List<int> l1;
  int temp_size = genSize(gen)+2;
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      l1.Insert(temp_val);
  }
  lasd::List<int> l2(l1);
  lasd::List<int> l3(l1);
  lasd::List<int> l4(l1);
  lasd::BST<int> BST1(std::move(l1));
  lasd::BST<int> BST2(std::move(l2));
  if((l1==l3) || (l2==l4) || (l3!=l4))
    result=false;
  lasd::BinaryTreeLnk<int> BTL(std::move(l3));
  lasd::BinaryTreeVec<int> BTV(std::move(l4));

  if(BST1!=BST2)
    result=false;
  if(BST1.Size()>=20){
    if(BST1.lasd::BinaryTree<int>::operator==(BTL))
      result=false;
    if(BST1.lasd::BinaryTree<int>::operator==(BTV))
      result=false;
  }
  if(BST2.Size()>=2){
    BST2.MinNRemove();
    BST2.MaxNRemove();
    if(BST1==BST2)
      result=false;
  }
  
  lasd::List<int> staticList;
  lasd::BST<int> staticBST;
  
  staticList.InsertAtFront(2);
  staticList.InsertAtFront(1);
  staticList.InsertAtFront(3);

  staticBST.InsertAll(staticList);

  lasd::List<int> staticList2(staticList);
  lasd::BinaryTreeLnk<int> staticBTL(std::move(staticList));
  if(staticList == staticList2)
    result=false;
  lasd::BinaryTreeVec<int> staticBTV(std::move(staticList2));
  if(staticList != staticList2)
    result=false;

  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTV))
    result=false;
  if(!staticBST.Remove(2))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTV))
    result=false;

  return result;
}

bool TestCompareBTAndBSTFromVecCopy(){
  bool result=true;

  int temp_size = genSize(gen)+2;
  lasd::Vector<int> v1(temp_size);
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      v1[i]=temp_val;
  }
  lasd::BST<int> BST1(v1);
  lasd::BST<int> BST2(v1);
  lasd::BinaryTreeLnk<int> BTL(v1);
  lasd::BinaryTreeVec<int> BTV(v1);

  if(BST1!=BST2)
    result=false;
  if(BST1.Size()>=20){
    if(BST1.lasd::BinaryTree<int>::operator==(BTL))
      result=false;
    if(BST1.lasd::BinaryTree<int>::operator==(BTV))
      result=false;
  }
  if(BST2.Size()>=2){
    BST2.MinNRemove();
    BST2.MaxNRemove();
    if(BST1==BST2)
      result=false;
  }
  
  lasd::Vector<int> staticVector(3);
  lasd::BST<int> staticBST;
  
  staticVector[0]=2;
  staticVector[1]=1;
  staticVector[2]=3;

  staticBST.InsertAll(staticVector);
  lasd::BinaryTreeLnk<int> staticBTL(staticVector);
  lasd::BinaryTreeVec<int> staticBTV(staticVector);

  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTV))
    result=false;
  if(!staticBST.Remove(2))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTV))
    result=false;

  return result;
}

bool TestCompareBTAndBSTFromVecMove(){
  bool result=true;
  
  int temp_size = genSize(gen)+2;
  lasd::Vector<int> v1(temp_size);
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      v1[i]=temp_val;
  }
  lasd::Vector<int> v2(v1);
  lasd::Vector<int> v3(v1);
  lasd::Vector<int> v4(v1);
  lasd::BST<int> BST1(std::move(v1));
  lasd::BST<int> BST2(std::move(v2));
  if((v1==v3) || (v2==v4) || (v3!=v4))
    result=false;
  lasd::BinaryTreeLnk<int> BTL(std::move(v3));
  lasd::BinaryTreeVec<int> BTV(std::move(v4));

  if(BST1!=BST2)
    result=false;
  if(BST1.Size()>=20){
    if(BST1.lasd::BinaryTree<int>::operator==(BTL))
      result=false;
    if(BST1.lasd::BinaryTree<int>::operator==(BTV))
      result=false;
  }
  if(BST2.Size()>=2){
    BST2.MinNRemove();
    BST2.MaxNRemove();
    if(BST1==BST2)
      result=false;
  }
  
  lasd::Vector<int> staticVector(3);
  lasd::BST<int> staticBST;
  
  staticVector[0]=2;
  staticVector[1]=1;
  staticVector[2]=3;

  staticBST.InsertAll(staticVector);

  lasd::Vector<int> staticVector2(staticVector);
  lasd::BinaryTreeLnk<int> staticBTL(std::move(staticVector));
  if(staticVector == staticVector2)
    result=false;
  lasd::BinaryTreeVec<int> staticBTV(std::move(staticVector2));
  if(staticVector != staticVector2)
    result=false;

  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator!=(staticBTV))
    result=false;
  if(!staticBST.Remove(2))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTL))
    result=false;
  if(staticBST.lasd::BinaryTree<int>::operator==(staticBTV))
    result=false;

  return result;
}

bool TestCompareEmptyBTAndBST(){
  bool result=true;
  lasd::Vector<int> vec(0);

  lasd::BST<int> BST1;
  lasd::BST<int> BST2(vec);
  lasd::BST<int> BST3(BST1);
  lasd::BST<int> BST4;
  BST4 = BST1;

  lasd::BinaryTreeLnk<int> BT1;
  lasd::BinaryTreeLnk<int> BT2(vec);
  lasd::BinaryTreeLnk<int> BT3(BT1);
  lasd::BinaryTreeLnk<int> BT4;
  BT4 = BT1;

  if(BST1!=BST2){
    result=false;
    cout<<"Costruttore di BST da MutableMappableContainer errato"<<endl;
  }
  if(BST1!=BST3){
    result=false;
    cout<<"Costruttore di BST da BST errato"<<endl;
  }
  if(BST1!=BST4){
    result=false;
    cout<<"Operatore di assegnazione di BST errato"<<endl;
  }

  if(BT1!=BT2){
    result=false;
    cout<<"Costruttore di BT da MutableMappableContainer errato"<<endl;
  }
  if(BT1!=BT3){
    result=false;
    cout<<"Costruttore di BT da BST errato"<<endl;
  }
  if(BT1!=BT4){
    result=false;
    cout<<"Operatore di assegnazione di BT errato"<<endl;
  }

  lasd::BST<int>BST5(BT1);
  lasd::BST<int>BST6;
  BST6 = BT1;
  if(BST5!=BST1){
    result=false;
    cout<<"Costruttore di BST da BT vuoto errato"<<endl;
  }
  if(BST6!=BST1){
    result=false;
    cout<<"Assegnazione di BT a BST vuoto errato"<<endl;
  }


  lasd::BST<int> move_BST1;
  lasd::BST<int> move_BST2(std::move(vec));

  if(move_BST1!=move_BST2){
    result=false;
    cout<<"Costruttore di BST da MutableMappableContainer errato"<<endl;
  }

  lasd::BST<int> move_BST3(std::move(move_BST1));
  
  if(move_BST2!=move_BST3){
    result=false;
    cout<<"Costruttore di BST da BST errato"<<endl;
  }

  lasd::BST<int> move_BST4;
  move_BST4 = std::move(move_BST2);
  
  if(move_BST3!=move_BST4){
    result=false;
    cout<<"Operatore di assegnazione di BST errato"<<endl;
  }

  if(!(move_BST1.Empty())){
    result=false;
    cout<<"Il move constructor di BST non ha cancellato other"<<endl;
  }
  if(!(move_BST2.Empty())){
    result=false;
    cout<<"L'assegnazione con move di BST non ha cancellato other"<<endl;
  }

  lasd::BinaryTreeLnk<int> move_BT1;
  lasd::BinaryTreeLnk<int> move_BT2(std::move(vec));

  if(move_BT1!=move_BT2){
    result=false;
    cout<<"Costruttore di BT da MutableMappableContainer errato"<<endl;
  }

  lasd::BinaryTreeLnk<int> move_BT3(std::move(move_BT1));

  if(move_BT2!=move_BT3){
    result=false;
    cout<<"Costruttore di BT da BST errato"<<endl;
  }

  lasd::BinaryTreeLnk<int> move_BT4;
  move_BT4 = std::move(move_BT1);

  if(move_BT3!=move_BT4){
    result=false;
    cout<<"Operatore di assegnazione di BT errato"<<endl;
  }

  if(!(move_BT1.Empty())){
    result=false;
    cout<<"Il move constructor di BT non ha cancellato other"<<endl;
  }
  if(!(move_BT2.Empty())){
    result=false;
    cout<<"L'assegnazione con move di BT non ha cancellato other"<<endl;
  }

  lasd::BST<int>move_BST5(std::move(move_BT3));
  lasd::BST<int>move_BST6;
  move_BST6 = std::move(move_BT4);
  lasd::BST<int>move_BST7;

  if(move_BST5!=move_BST7){
    result=false;
    cout<<"Costruttore con move di BST da BT vuoto errato"<<endl;
  }
  if(move_BST6!=move_BST7){
    result=false;
    cout<<"Assegnazione con move di BT a BST vuoto errato"<<endl;
  }

  return result;
}

/* ************************************************************************** */

bool TestIteratorOnBT(){
  bool result=true;

  // cotruttori vari e assegnazioni

  lasd::Vector<int> vec(3);
  vec[0]=1;
  vec[1]=2;
  vec[2]=3;

  lasd::BinaryTreeLnk<int> BT(vec);

  lasd::BTPreOrderIterator pre_i(BT);
  lasd::BTPostOrderIterator post_i(BT);
  lasd::BTInOrderIterator inOrder_i(BT);
  lasd::BTBreadthIterator breadth_i(BT);

  cout<<"pre: ";
  for(; !(pre_i.Terminated()); pre_i.operator++())
    cout<<pre_i.operator*()<<"-";
  cout<<endl;
  pre_i.Reset();
  cout<<"post: ";
  for(; !(post_i.Terminated()); post_i.operator++())
    cout<<post_i.operator*()<<"-";
  cout<<endl;
  post_i.Reset();
  cout<<"inOrder: ";
  for(; !(inOrder_i.Terminated()); inOrder_i.operator++())
    cout<<inOrder_i.operator*()<<"-";
  cout<<endl;
  inOrder_i.Reset();
  cout<<"breadth: ";
  for(; !(breadth_i.Terminated()); breadth_i.operator++())
    cout<<breadth_i.operator*()<<"-";
  cout<<endl;
  breadth_i.Reset();
  
  lasd::BTPreOrderMutableIterator pre_mut_i(BT);
  lasd::BTPostOrderMutableIterator post_mut_i(BT);
  lasd::BTInOrderMutableIterator inOrder_mut_i(BT);
  lasd::BTBreadthMutableIterator breadth_mut_i(BT);

  lasd::BTPreOrderMutableIterator pre_mut_i_cop(pre_mut_i);
  lasd::BTPostOrderMutableIterator post_mut_i_cop(post_mut_i);
  lasd::BTInOrderMutableIterator inOrder_mut_i_cop(inOrder_mut_i);
  lasd::BTBreadthMutableIterator breadth_mut_i_cop(breadth_mut_i);

  lasd::BTPreOrderMutableIterator pre_mut_i_mov(std::move(pre_mut_i));
  lasd::BTPostOrderMutableIterator post_mut_i_mov(std::move(post_mut_i));
  lasd::BTInOrderMutableIterator inOrder_mut_i_mov(std::move(inOrder_mut_i));
  lasd::BTBreadthMutableIterator breadth_mut_i_mov(std::move(breadth_mut_i));

  lasd::BTPreOrderIterator pre_i_as(BT);
  pre_i_as = pre_i;
  lasd::BTPostOrderIterator post_i_as(BT);
  post_i_as = post_i;
  lasd::BTInOrderIterator inOrder_i_as(BT);
  inOrder_i_as = inOrder_i;
  lasd::BTBreadthIterator breadth_i_as(BT);
  breadth_i_as = breadth_i;
  
  lasd::BTPreOrderMutableIterator pre_mut_i_as_mov(BT);
  pre_mut_i_as_mov = std::move(pre_mut_i_cop);
  lasd::BTPostOrderMutableIterator post_mut_i_as_mov(BT);
  post_mut_i_as_mov = std::move(post_mut_i_cop);
  lasd::BTInOrderMutableIterator inOrder_mut_i_as_mov(BT);
  inOrder_mut_i_as_mov = std::move(inOrder_mut_i_cop);
  lasd::BTBreadthMutableIterator breadth_mut_i_as_mov(BT);
  breadth_mut_i_as_mov = std::move(breadth_mut_i_cop);

  int val;

  // operazioni su iterator

  if(pre_i_as.Terminated())
    result=false;
  try{
    val = pre_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    pre_i_as.operator++();
    val = pre_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  pre_i_as.Reset();
  try{
    pre_i_as.operator*();
    val = pre_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(pre_i_as.Terminated())
    result=false;
  if(!(pre_i_as.operator==(pre_i_as)))
    result=false;
  if(pre_i_as.operator!=(pre_i_as))
    result=false;
  try{
    pre_i_as.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(post_i_as.Terminated())
    result=false;
  try{
    val = post_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    post_i_as.operator++();
    val = post_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=3)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  post_i_as.Reset();
  try{
    post_i_as.operator*();
    val = post_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(post_i_as.Terminated())
    result=false;
  if(!(post_i_as.operator==(post_i_as)))
    result=false;
  if(post_i_as.operator!=(post_i_as))
    result=false;
  try{
    post_i_as.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(inOrder_i_as.Terminated())
    result=false;
  try{
    val = inOrder_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    inOrder_i_as.operator++();
    val = inOrder_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  inOrder_i_as.Reset();
  try{
    inOrder_i_as.operator*();
    val = inOrder_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(inOrder_i_as.Terminated())
    result=false;
  if(!(inOrder_i_as.operator==(inOrder_i_as)))
    result=false;
  if(inOrder_i_as.operator!=(inOrder_i_as))
    result=false;
  try{
    inOrder_i_as.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(breadth_i_as.Terminated())
    result=false;
  try{
    val = breadth_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    breadth_i_as.operator++();
    val = breadth_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  breadth_i_as.Reset();
  try{
    breadth_i_as.operator*();
    val = breadth_i_as.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(breadth_i_as.Terminated())
    result=false;
  if(!(breadth_i_as.operator==(breadth_i_as)))
    result=false;
  if(breadth_i_as.operator!=(breadth_i_as))
    result=false;
  try{
    breadth_i_as.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }

  // operazioni su mutable iterator

  cout<<"pre: ";
  for(; !(pre_mut_i_as_mov.Terminated()); pre_mut_i_as_mov.operator++())
    cout<<pre_mut_i_as_mov.operator*()<<"-";
  cout<<endl;
  pre_mut_i_as_mov.Reset();
  cout<<"post: ";
  for(; !(post_mut_i_as_mov.Terminated()); post_mut_i_as_mov.operator++())
    cout<<post_mut_i_as_mov.operator*()<<"-";
  cout<<endl;
  post_mut_i_as_mov.Reset();
  cout<<"inOrder: ";
  for(; !(inOrder_mut_i_as_mov.Terminated()); inOrder_mut_i_as_mov.operator++())
    cout<<inOrder_mut_i_as_mov.operator*()<<"-";
  cout<<endl;
  inOrder_mut_i_as_mov.Reset();
  cout<<"breadth: ";
  for(; !(breadth_mut_i_as_mov.Terminated()); breadth_mut_i_as_mov.operator++())
    cout<<breadth_mut_i_as_mov.operator*()<<"-";
  cout<<endl;
  breadth_mut_i_as_mov.Reset();


  if(pre_mut_i_as_mov.Terminated())
    result=false;
  try{
    val = pre_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    pre_mut_i_as_mov.operator++();
    val = pre_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  pre_mut_i_as_mov.Reset();
  try{
    pre_mut_i_as_mov.operator*();
    val = pre_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(pre_mut_i_as_mov.Terminated())
    result=false;
  if(!(pre_mut_i_as_mov.operator==(pre_mut_i_as_mov)))
    result=false;
  if(pre_mut_i_as_mov.operator!=(pre_mut_i_as_mov))
    result=false;
  try{
    pre_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(post_mut_i_as_mov.Terminated())
    result=false;
  try{
    val = post_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    post_mut_i_as_mov.operator++();
    val = post_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=3)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  post_mut_i_as_mov.Reset();
  try{
    post_mut_i_as_mov.operator*();
    val = post_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(post_mut_i_as_mov.Terminated())
    result=false;
  if(!(post_mut_i_as_mov.operator==(post_mut_i_as_mov)))
    result=false;
  if(post_mut_i_as_mov.operator!=(post_mut_i_as_mov))
    result=false;
  try{
    post_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(inOrder_mut_i_as_mov.Terminated())
    result=false;
  try{
    val = inOrder_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    inOrder_mut_i_as_mov.operator++();
    val = inOrder_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  inOrder_mut_i_as_mov.Reset();
  try{
    inOrder_mut_i_as_mov.operator*();
    val = inOrder_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(inOrder_mut_i_as_mov.Terminated())
    result=false;
  if(!(inOrder_mut_i_as_mov.operator==(inOrder_mut_i_as_mov)))
    result=false;
  if(inOrder_mut_i_as_mov.operator!=(inOrder_mut_i_as_mov))
    result=false;
  try{
    inOrder_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(breadth_mut_i_as_mov.Terminated())
    result=false;
  try{
    val = breadth_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  try{
    breadth_mut_i_as_mov.operator++();
    val = breadth_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=2)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }
  breadth_mut_i_as_mov.Reset();
  try{
    breadth_mut_i_as_mov.operator*();
    val = breadth_mut_i_as_mov.operator*();
    cout<<"val: "<<val<<endl;
    if(val!=1)
      result=false;
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(breadth_mut_i_as_mov.Terminated())
    result=false;
  if(!(breadth_mut_i_as_mov.operator==(breadth_mut_i_as_mov)))
    result=false;
  if(breadth_mut_i_as_mov.operator!=(breadth_mut_i_as_mov))
    result=false;
  try{
    breadth_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    result=false;
    cout<<"catchata out_of_range in operator++()"<<endl;
  }

  return result;
}


bool TestIteratorOnEmptyBT(){
  bool result=true;

  // cotruttori vari e assegnazioni

  lasd::BinaryTreeLnk<int> BT;
  lasd::BTPreOrderIterator pre_i(BT);
  lasd::BTPostOrderIterator post_i(BT);
  lasd::BTInOrderIterator inOrder_i(BT);
  lasd::BTBreadthIterator breadth_i(BT);
  
  lasd::BTPreOrderMutableIterator pre_mut_i(BT);
  lasd::BTPostOrderMutableIterator post_mut_i(BT);
  lasd::BTInOrderMutableIterator inOrder_mut_i(BT);
  lasd::BTBreadthMutableIterator breadth_mut_i(BT);

  lasd::BTPreOrderIterator pre_i_mov_bt(std::move(BT));
  lasd::BTPostOrderIterator post_i_mov_bt(std::move(BT));
  lasd::BTInOrderIterator inOrder_i_mov_bt(std::move(BT));
  lasd::BTBreadthIterator breadth_i_mov_bt(std::move(BT));

  lasd::BTPreOrderIterator pre_i_cop(pre_i);
  lasd::BTPostOrderIterator post_i_cop(post_i);
  lasd::BTInOrderIterator inOrder_i_cop(inOrder_i);
  lasd::BTBreadthIterator breadth_i_cop(breadth_i);

  lasd::BTPreOrderMutableIterator pre_mut_i_cop(pre_mut_i);
  lasd::BTPostOrderMutableIterator post_mut_i_cop(post_mut_i);
  lasd::BTInOrderMutableIterator inOrder_mut_i_cop(inOrder_mut_i);
  lasd::BTBreadthMutableIterator breadth_mut_i_cop(breadth_mut_i);

  lasd::BTPreOrderIterator pre_i_mov(std::move(pre_i));
  lasd::BTPostOrderIterator post_i_mov(std::move(post_i));
  lasd::BTInOrderIterator inOrder_i_mov(std::move(inOrder_i));
  lasd::BTBreadthIterator breadth_i_mov(std::move(breadth_i));

  lasd::BTPreOrderMutableIterator pre_mut_i_mov(std::move(pre_mut_i));
  lasd::BTPostOrderMutableIterator post_mut_i_mov(std::move(post_mut_i));
  lasd::BTInOrderMutableIterator inOrder_mut_i_mov(std::move(inOrder_mut_i));
  lasd::BTBreadthMutableIterator breadth_mut_i_mov(std::move(breadth_mut_i));

  lasd::BTPreOrderIterator pre_i_as(BT);
  pre_i_as = pre_i;
  lasd::BTPostOrderIterator post_i_as(BT);
  post_i_as = post_i;
  lasd::BTInOrderIterator inOrder_i_as(BT);
  inOrder_i_as = inOrder_i;
  lasd::BTBreadthIterator breadth_i_as(BT);
  breadth_i_as = breadth_i;
  
  lasd::BTPreOrderMutableIterator pre_mut_i_as(BT);
  pre_mut_i_as = pre_mut_i;
  lasd::BTPostOrderMutableIterator post_mut_i_as(BT);
  post_mut_i_as = post_mut_i;
  lasd::BTInOrderMutableIterator inOrder_mut_i_as(BT);
  inOrder_mut_i_as = inOrder_mut_i;
  lasd::BTBreadthMutableIterator breadth_mut_i_as(BT);
  breadth_mut_i_as = breadth_mut_i;

  lasd::BTPreOrderIterator pre_i_as_mov(BT);
  pre_i_as_mov = std::move(pre_i);
  lasd::BTPostOrderIterator post_i_as_mov(BT);
  post_i_as_mov = std::move(post_i);
  lasd::BTInOrderIterator inOrder_i_as_mov(BT);
  inOrder_i_as_mov = std::move(inOrder_i);
  lasd::BTBreadthIterator breadth_i_as_mov(BT);
  breadth_i_as_mov = std::move(breadth_i);
  
  lasd::BTPreOrderMutableIterator pre_mut_i_as_mov(BT);
  pre_mut_i_as_mov = std::move(pre_mut_i);
  lasd::BTPostOrderMutableIterator post_mut_i_as_mov(BT);
  post_mut_i_as_mov = std::move(post_mut_i);
  lasd::BTInOrderMutableIterator inOrder_mut_i_as_mov(BT);
  inOrder_mut_i_as_mov = std::move(inOrder_mut_i);
  lasd::BTBreadthMutableIterator breadth_mut_i_as_mov(BT);
  breadth_mut_i_as_mov = std::move(breadth_mut_i);

  // operazioni su iterator vuoto

  if(!(pre_i_as.Terminated()))
    result=false;
  pre_i_as.Reset();
  if(!(pre_i_as.Terminated()))
    result=false;
  try{
    pre_i_as.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(pre_i_as.operator==(pre_i_as)))
    result=false;
  if(pre_i_as.operator!=(pre_i_as))
    result=false;
  try{
    pre_i_as.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(post_i_as.Terminated()))
    result=false;
  post_i_as.Reset();
  if(!(post_i_as.Terminated()))
    result=false;
  try{
    post_i_as.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(post_i_as.operator==(post_i_as)))
    result=false;
  if(post_i_as.operator!=(post_i_as))
    result=false;
  try{
    post_i_as.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(inOrder_i_as.Terminated()))
    result=false;
  inOrder_i_as.Reset();
  if(!(inOrder_i_as.Terminated()))
    result=false;
  try{
    inOrder_i_as.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(inOrder_i_as.operator==(inOrder_i_as)))
    result=false;
  if(inOrder_i_as.operator!=(inOrder_i_as))
    result=false;
  try{
    inOrder_i_as.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(breadth_i_as.Terminated()))
    result=false;
  breadth_i_as.Reset();
  if(!(breadth_i_as.Terminated()))
    result=false;
  try{
    breadth_i_as.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(breadth_i_as.operator==(breadth_i_as)))
    result=false;
  if(breadth_i_as.operator!=(breadth_i_as))
    result=false;
  try{
    breadth_i_as.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }

  // operazioni su mutable iterator vuoto

  if(!(pre_mut_i_as_mov.Terminated()))
    result=false;
  pre_mut_i_as_mov.Reset();
  if(!(pre_mut_i_as_mov.Terminated()))
    result=false;
  try{
    pre_mut_i_as_mov.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(pre_mut_i_as_mov.operator==(pre_mut_i_as_mov)))
    result=false;
  if(pre_mut_i_as_mov.operator!=(pre_mut_i_as_mov))
    result=false;
  try{
    pre_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(post_mut_i_as_mov.Terminated()))
    result=false;
  post_mut_i_as_mov.Reset();
  if(!(post_mut_i_as_mov.Terminated()))
    result=false;
  try{
    post_mut_i_as_mov.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(post_mut_i_as_mov.operator==(post_mut_i_as_mov)))
    result=false;
  if(post_mut_i_as_mov.operator!=(post_mut_i_as_mov))
    result=false;
  try{
    post_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(inOrder_mut_i_as_mov.Terminated()))
    result=false;
  inOrder_mut_i_as_mov.Reset();
  if(!(inOrder_mut_i_as_mov.Terminated()))
    result=false;
  try{
    inOrder_mut_i_as_mov.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(inOrder_mut_i_as_mov.operator==(inOrder_mut_i_as_mov)))
    result=false;
  if(inOrder_mut_i_as_mov.operator!=(inOrder_mut_i_as_mov))
    result=false;
  try{
    inOrder_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }


  if(!(breadth_mut_i_as_mov.Terminated()))
    result=false;
  breadth_mut_i_as_mov.Reset();
  if(!(breadth_mut_i_as_mov.Terminated()))
    result=false;
  try{
    breadth_mut_i_as_mov.operator*();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator*()"<<endl;
  }
  if(!(breadth_mut_i_as_mov.operator==(breadth_mut_i_as_mov)))
    result=false;
  if(breadth_mut_i_as_mov.operator!=(breadth_mut_i_as_mov))
    result=false;
  try{
    breadth_mut_i_as_mov.operator++();
  }
  catch(std::out_of_range our){
    cout<<"catchata out_of_range in operator++()"<<endl;
  }

  return result;
}


bool TestIteratorAfterMove(){
  bool result=false;

  lasd::Vector<int> vec(6);
  for(int i=0; i<6; i++)
      vec[i]=i;

  lasd::BinaryTreeVec<int> btVec1(vec);
  lasd::BinaryTreeVec<int> btVec2;

  btVec2=std::move(btVec1);

  lasd::BTPreOrderIterator<int> itr1(btVec2);
  while(!(itr1.Terminated())){
    cout<<" - "<<*itr1;
    ++itr1;
  }


  lasd::BinaryTreeLnk<int> btLnk1(vec);
  lasd::BinaryTreeLnk<int> btLnk2;

  btLnk2=std::move(btLnk1);

  lasd::BTPreOrderIterator<int> itr2(btLnk2);
  while(!(itr2.Terminated())){
    cout<<" - "<<*itr2;
    ++itr2;
  }

  result = true;

  return result;
}

/* ************************************************************************** */

bool TestMapsAndFoldOnBTLnk(){
  bool result=true;

  lasd::List<int> lst;
  for(int i=0; i<6; i++)
      lst.InsertAtBack(i);

  lasd::BinaryTreeLnk<int> btLnk(lst);

  cout<<"Atteso con Map: 0->1->3->4->2->5->"<<endl;
  cout<<"Stampa con Map: ";
  btLnk.Map(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  int acc=0;
  btLnk.Fold(&FoldAdd<int>, &acc);
  cout<<"\nValore di acc atteso con Fold: 15 - Valore ottenuto: "<<acc<<endl;
  if(acc!=15)
    result=false;
  cout<<endl<<endl;


  cout<<"Atteso con PreOrderMap: 0->1->3->4->2->5->"<<endl;
  cout<<"Stampa con PreOrderMap: ";
  btLnk.PreOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTPreOrderIterator<int> itrPre(btLnk);
  cout<<"Stampa PreOrder con iteratore: ";
  while(!(itrPre.Terminated())){
    cout<<*itrPre<<"->";
    ++itrPre;
  }

  static_test_index = 0;
  acc = 0;
  btLnk.PreOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con PreOrderFold: 52 - Valore ottenuto: "<<acc<<endl;
  if(acc!=52)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;


  cout<<"Atteso con PostOrderMap: 3->4->1->5->2->0->"<<endl;
  cout<<"Stampa con PostOrderMap: ";
  btLnk.PostOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTPostOrderIterator<int> itrPost(btLnk);
  cout<<"Stampa PostOrder con iteratore: ";
  while(!(itrPost.Terminated())){
    cout<<*itrPost<<"->";
    ++itrPost;
  }

  static_test_index = 0;
  acc = 0;
  btLnk.PostOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con PostOrderFold: 29 - Valore ottenuto: "<<acc<<endl;
  if(acc!=29)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;


  cout<<"Atteso con InOrderMap: 3->1->4->0->5->2->"<<endl;
  cout<<"Stampa con InOrderMap: ";
  btLnk.InOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTInOrderIterator<int> itrIn(btLnk);
  cout<<"Stampa InOrder con iteratore: ";
  while(!(itrIn.Terminated())){
    cout<<*itrIn<<"->";
    ++itrIn;
  }
  
  static_test_index = 0;
  acc = 0;
  btLnk.InOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con InOrderFold: 39 - Valore ottenuto: "<<acc<<endl;
  if(acc!=39)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;

  cout<<"Atteso con BreadthMap: 0->1->2->3->4->5->"<<endl;
  cout<<"Stampa con BreadthMap: ";
  btLnk.BreadthMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTBreadthIterator<int> itrBreadth(btLnk);
  cout<<"Stampa BreadthOrder con iteratore: ";
  while(!(itrBreadth.Terminated())){
    cout<<*itrBreadth<<"->";
    ++itrBreadth;
  }

  static_test_index = 0;
  acc = 0;
  btLnk.BreadthFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con BreadthFold: 55 - Valore ottenuto: "<<acc<<endl;
  if(acc!=55)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;
  
  return result;
}


bool TestMapsAndFoldOnBTVec(){
  bool result=true;

  lasd::Vector<int> vec(6);
  for(int i=0; i<6; i++)
      vec[i]=i;

  lasd::BinaryTreeVec<int> btVec(vec);

  cout<<"Atteso con Map: 0->1->3->4->2->5->"<<endl;
  cout<<"Stampa con Map: ";
  btVec.Map(
    [](int& dat){
      cout<<dat<<"->";
    }
  );

  int acc=0;
  btVec.Fold(&FoldAdd<int>, &acc);
  cout<<"\nValore di acc atteso con Fold: 15 - Valore ottenuto: "<<acc<<endl;
  if(acc!=15)
    result=false;
  cout<<endl<<endl;


  cout<<"Atteso con PreOrderMap: 0->1->3->4->2->5->"<<endl;
  cout<<"Stampa con PreOrderMap: ";
  btVec.PreOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTPreOrderIterator<int> itrPre(btVec);
  cout<<"Stampa PreOrder con iteratore: ";
  while(!(itrPre.Terminated())){
    cout<<*itrPre<<"->";
    ++itrPre;
  }

  static_test_index = 0;
  acc = 0;
  btVec.PreOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con PreOrderFold: 52 - Valore ottenuto: "<<acc<<endl;
  if(acc!=52)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;


  cout<<"Atteso con PostOrderMap: 3->4->1->5->2->0->"<<endl;
  cout<<"Stampa con PostOrderMap: ";
  btVec.PostOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTPostOrderIterator<int> itrPost(btVec);
  cout<<"Stampa PostOrder con iteratore: ";
  while(!(itrPost.Terminated())){
    cout<<*itrPost<<"->";
    ++itrPost;
  }
  
  static_test_index = 0;
  acc = 0;
  btVec.PostOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con PostOrderFold: 29 - Valore ottenuto: "<<acc<<endl;
  if(acc!=29)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;


  cout<<"Atteso con InOrderMap: 3->1->4->0->5->2->"<<endl;
  cout<<"Stampa con InOrderMap: ";
  btVec.InOrderMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTInOrderIterator<int> itrIn(btVec);
  cout<<"Stampa InOrder con iteratore: ";
  while(!(itrIn.Terminated())){
    cout<<*itrIn<<"->";
    ++itrIn;
  }
  
  static_test_index = 0;
  acc = 0;
  btVec.InOrderFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con InOrderFold: 39 - Valore ottenuto: "<<acc<<endl;
  if(acc!=39)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;


  cout<<"Atteso con BreadthMap: 0->1->2->3->4->5->"<<endl;
  cout<<"Stampa con BreadthMap: ";
  btVec.BreadthMap(
    [](int& dat){
      cout<<dat<<"->";
    }
  );
  cout<<endl;
  lasd::BTBreadthIterator<int> itrBreadth(btVec);
  cout<<"Stampa BreadthOrder con iteratore: ";
  while(!(itrBreadth.Terminated())){
    cout<<*itrBreadth<<"->";
    ++itrBreadth;
  }
  
  static_test_index = 0;
  acc = 0;
  btVec.BreadthFold(&FoldSumAndMultyplyPerPosition<int>, &acc);
  cout<<"\nValore di acc atteso con BreadthFold: 55 - Valore ottenuto: "<<acc<<endl;
  if(acc!=55)
    result=false;
  static_test_index = 0;
  cout<<endl<<endl;
  
  return result;
}

/* ************************************************************************** */

bool TestFindMinInBST(){
  bool result=true;
  int generated_size = genSize(gen)+1;
  int generated_val;
  lasd::Vector<int> vec(generated_size);
  lasd::BST<int> BST;
  for(int i=0; i<generated_size; i++){
    generated_val = genNum(gen);
    vec[i]=generated_val;
    BST.Insert(generated_val);
  }

  int minVec=vec[0];
  for(int i=0; i<generated_size; i++){
    if(vec[i]<minVec)
      minVec=vec[i];
  }
  cout<<"minVec: "<<minVec<<endl;

  int minBST = BST.Min();
  cout<<"minBST: "<<minBST<<endl;

  if(minVec!=minBST)
    result = false;

  return result;
}

bool TestFindMaxInBST(){
  bool result=true;
  int generated_size = genSize(gen)+1;
  int generated_val;
  lasd::Vector<int> vec(generated_size);
  lasd::BST<int> BST;
  for(int i=0; i<generated_size; i++){
    generated_val = genNum(gen);
    vec[i]=generated_val;
    BST.Insert(generated_val);
  }

  int maxVec=vec[0];
  for(int i=0; i<generated_size; i++){
    if(vec[i]>maxVec)
      maxVec=vec[i];
  }
  cout<<"maxVec: "<<maxVec<<endl;

  int maxBST = BST.Max();
  cout<<"maxBST: "<<maxBST<<endl;

  if(maxVec!=maxBST)
    result = false;


  return result;
}


bool TestPredecessorAndSuccessor(){
  bool result=true;

  lasd::List<int> list;
  int temp_size = genSize(gen)+1;
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      list.Insert(temp_val);
  }

  lasd::BST<int> BST1(list);

  if(BST1.Size()>3){
    cout<<"Root: "<<BST1.Root().Element()<<endl;
    if(!(BST1.Exists(BST1.Root().Element())))
      result = false;
    try{
      if(BST1.Exists(BST1.Successor(BST1.Max())))
        result = false;
    }
    catch(std::length_error exc){
        cout<<"Catchata eccezione std::lenght_error in Successor di Max"<<endl;
    }
    try{
      if(BST1.Exists(BST1.Predecessor(BST1.Min())))
        result = false;
    }
    catch(std::length_error exc){
        cout<<"Catchata eccezione std::lenght_error in Predecessir di Min"<<endl;
    }
    cout<<"Max: "<<BST1.Max()<<endl;
    cout<<"Predecessor di Max: "<<BST1.Predecessor(BST1.Max())<<endl;
    cout<<"Successor di Predecessor di Max: "<<BST1.Successor(BST1.Predecessor(BST1.Max()))<<endl;
    cout<<"Min: "<<BST1.Min()<<endl;
    cout<<"Successor di Min: "<<BST1.Successor(BST1.Min())<<endl;
    cout<<"Predecessor di Successor di Min: "<<BST1.Predecessor(BST1.Successor(BST1.Min()))<<endl;
    if(BST1.Successor(BST1.Predecessor(BST1.Max())) != BST1.Max())
      result = false;
    if(BST1.Predecessor(BST1.Successor(BST1.Min())) != BST1.Min())
      result = false;
    int test_successor = BST1.Max()-1;
    int test_predecessor = BST1.Min()+1;
    if(BST1.Max() != BST1.Successor(test_successor))
      result = false;
    if(BST1.Min() != BST1.Predecessor(test_predecessor))
      result = false;
    int old_pred_max = BST1.Predecessor(BST1.Max());
    int old_succ_min = BST1.Successor(BST1.Min());
    BST1.PredecessorNRemove(BST1.Max());
    BST1.SuccessorNRemove(BST1.Min());
    if(BST1.Predecessor(BST1.Max()) == old_pred_max)
      result = false;
    if(BST1.Successor(BST1.Min()) == old_succ_min)
      result = false;
  }


  lasd::BST<int> BST2(std::move(list));

  if(BST2.Size()>3){
    cout<<"Root: "<<BST2.Root().Element()<<endl;
    if(!(BST2.Exists(BST2.Root().Element())))
      result = false;
    try{
      if(BST2.Exists(BST2.Successor(BST2.Max())))
        result = false;
    }
    catch(std::length_error exc){
        cout<<"Catchata eccezione std::lenght_error in Successor di Max"<<endl;
    }
    try{
      if(BST2.Exists(BST2.Predecessor(BST2.Min())))
        result = false;
    }
    catch(std::length_error exc){
        cout<<"Catchata eccezione std::lenght_error in Predecessir di Min"<<endl;
    }
    cout<<"Max: "<<BST2.Max()<<endl;
    cout<<"Predecessor di Max: "<<BST2.Predecessor(BST2.Max())<<endl;
    cout<<"Successor di Predecessor di Max: "<<BST2.Successor(BST2.Predecessor(BST2.Max()))<<endl;
    cout<<"Min: "<<BST2.Min()<<endl;
    cout<<"Successor di Min: "<<BST2.Successor(BST2.Min())<<endl;
    cout<<"Predecessor di Successor di Min: "<<BST2.Predecessor(BST2.Successor(BST2.Min()))<<endl;
    if(BST2.Successor(BST2.Predecessor(BST2.Max())) != BST2.Max())
      result = false;
    if(BST2.Predecessor(BST2.Successor(BST2.Min())) != BST2.Min())
      result = false;
    int test_successor = BST2.Max()-1;
    int test_predecessor = BST2.Min()+1;
    if(BST2.Max() != BST2.Successor(test_successor))
      result = false;
    if(BST2.Min() != BST2.Predecessor(test_predecessor))
      result = false;
    int old_pred_max = BST2.Predecessor(BST2.Max());
    int old_succ_min = BST2.Successor(BST2.Min());
    BST2.PredecessorNRemove(BST2.Max());
    BST2.SuccessorNRemove(BST2.Min());
    if(BST2.Predecessor(BST2.Max()) == old_pred_max)
      result = false;
    if(BST2.Successor(BST2.Min()) == old_succ_min)
      result = false;
  }
  
  return result;
}


bool TestDictionaryMethods(){
  bool result=true;

  lasd::List<int> list;
  int temp_size = genSize(gen)+1;
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      list.Insert(temp_val);
  }
  lasd::BST<int> BST1(list);
  lasd::BST<int> BST2(list);

  if(BST1!=BST2)
    result = false;

  if(BST1.Empty())
    result = false;

  if(BST1.Size()>2){
    if(BST1.Max()!=BST1.MaxNRemove())
      result = false;
    if(BST1.Min()!=BST1.MinNRemove())
      result = false;

    BST1.Insert(10);
    if(!(BST1.Exists(10)))
      result = false;
    if(!(BST1.Remove(10)))
      result = false;
  }

  BST1.Insert(10);
  BST1.Clear();
  if(!BST1.Empty())
    result = false;
  if(BST1==BST2)
    result = false;

  lasd::Vector<int> vec1(6);
  for(int i=0; i<6; i++)
    vec1[i]=i;
  lasd::Vector<int> vec2(2);
  vec2[0]=8;
  vec2[1]=9;

  BST1.Insert(3);
  if(BST1.InsertAll(vec1))
    result=false;
  if(!(BST1.InsertAll(vec2)))
    result=false;
  BST1.Remove(3);
  if(!(BST1.InsertSome(vec1)))
    result=false;

  if(!(BST1.RemoveAll(vec1)))
    result=false;
  if(!(BST1.RemoveSome(vec2)))
    result=false;
  BST1.InsertAll(vec2);
  BST1.Remove(9);
  if(!(BST1.RemoveSome(vec2)))
    result=false;
  BST1.InsertAll(vec2);
  BST1.Remove(9);
  if(BST1.RemoveAll(vec2))
    result=false;
  
  return result;
}

/* ************************************************************************** */

bool TestBTVec(){
  bool result=true;

  int temp_size = genSize(gen)+1;
  lasd::Vector<int> vec(temp_size);
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      vec[i]=temp_val;
  } 
  lasd::BinaryTreeVec<int> btv1(vec);
  lasd::BinaryTreeVec<int> btv2(vec);
  vec[genSize(gen)%temp_size]=genNum(gen);
  vec[genSize(gen)%temp_size]=genNum(gen);
  vec[genSize(gen)%temp_size]=genNum(gen);
  lasd::BinaryTreeVec<int> btv3(vec);
  lasd::BinaryTreeVec<int> btv4;
  btv4 = btv1;
  if(btv1!=btv4)
    result=false;
  if(btv1!=btv2)
    result=false;
  if(btv1==btv3)
    result=false;
  btv2.Clear();
  if(btv1==btv2)
    result=false;
  btv1.Clear();
  if(btv1!=btv2)
    result=false;

  lasd::Vector<int> vec2(vec);
  lasd::Vector<int> vec3(vec);
  lasd::Vector<int> vec4(vec);
  lasd::BinaryTreeVec<int> mbtv0(std::move(vec));
  lasd::BinaryTreeVec<int> mbtv1(std::move(vec2));
  if((vec==vec3) || (vec2==vec4) || (vec!=vec2) || (vec3!=vec4))
    result=false;
  lasd::BinaryTreeVec<int> mbtv2(std::move(vec3));
  vec4[genSize(gen)%temp_size]=genNum(gen);
  vec4[genSize(gen)%temp_size]=genNum(gen);
  vec4[genSize(gen)%temp_size]=genNum(gen);
  lasd::BinaryTreeVec<int> mbtv3(std::move(vec4));
  lasd::BinaryTreeVec<int> mbtv4;
  mbtv4 = std::move(mbtv0);
  if(!(mbtv0.Empty()))
    result=false;
  if(mbtv1!=mbtv4)
    result=false;
  if(mbtv1!=mbtv2)
    result=false;
  if(mbtv1==mbtv3)
    result=false;
  mbtv2.Clear();
  if(mbtv1==mbtv2)
    result=false;
  mbtv1.Clear();
  if(mbtv1!=mbtv2)
    result=false;

  return result;
}


bool TestVecFromBTVecAndMove(){
  bool result=true;

  lasd::Vector<int> v1(10);

  for(int i=0; i<v1.Size(); i++)
    v1[i]=i;

  cout<<"vec 1 prima: ";
  for(int i=0; i<v1.Size(); i++)
    cout<<v1[i];
  cout<<endl;

  lasd::BinaryTreeLnk<int> btl(std::move(v1));
  lasd::Vector<int> v2(std::move(btl));

  cout<<"vec 1 dopo: ";
  for(int i=0; i<v1.Size(); i++)
    cout<<v1[i];
  cout<<endl;

  cout<<"vec 2: ";
  for(int i=0; i<v2.Size(); i++)
    cout<<v2[i];
  cout<<endl;

  cout<<"btl: ";
  btl.Map(
    [](const int &dat){
      cout<<dat<<"-";
    }
  );
  cout<<endl;

  lasd::BinaryTreeVec<int> btv(std::move(v2));
  cout<<"btv: ";
  btv.Map(
    [](const int &dat){
      cout<<dat<<"-";
    }
  );
  cout<<endl;

  lasd::Vector<int> v3((lasd::MutableMappableContainer<int>&)btv);

  cout<<"vec 3: ";
  for(int i=0; i<v3.Size(); i++)
    cout<<v3[i];
  cout<<endl;

  cout<<"btv prima di move: ";
  btv.Map(
    [](const int &dat){
      cout<<dat<<"-";
    }
  );
  cout<<endl;

  lasd::Vector<int> v4(std::move((lasd::MutableMappableContainer<int>&)btv));

  cout<<"vec 4: ";
  for(int i=0; i<v4.Size(); i++)
    cout<<v4[i];
  cout<<endl;

  cout<<"btv dopo la move: ";
  btv.Map(
    [](const int &dat){
      cout<<dat<<"-";
    }
  );
  cout<<endl;

  return result;
}


bool TestBTVecMethods(){
  bool result=true;

  lasd::Vector<int> vec(10);
  for(int i=0; i<10; i++)
      vec[i]=i;

  lasd::BinaryTreeVec<int> btVec1(vec);
  lasd::BinaryTreeVec<int> btVec2(vec);

  if(btVec1.Root().Element()!=0)
    result = false;
  if(btVec1.Root().LeftChild().Element()!=1)
    result = false;
  if(btVec1.Root().RightChild().Element()!=2)
    result = false;

  if(btVec1!=btVec2)
    result = false;
  btVec1.Root().LeftChild().Element()=15;
  if(btVec1==btVec2)
    result = false;
  btVec2.Root().LeftChild().Element()=15;
  if(btVec1!=btVec2)
    result = false;

  cout<<"left child before map: "<<btVec1.Root().LeftChild().Element()<<endl;

  lasd::BinaryTreeVec<int> btVec3;
  btVec3=btVec1;
  lasd::BinaryTreeVec<int> btVec4(btVec1);
  
  btVec1.Map(
    [](int& dat){
      dat+=dat;
    }
  );

  if(btVec1==btVec2)
    result = false;

  cout<<"left child after map: "<<btVec1.Root().LeftChild().Element()<<endl;
  if(btVec1.Root().LeftChild().Element()!=30)
    result = false;
  cout<<"left child btVec3 after map: "<<btVec3.Root().LeftChild().Element()<<endl;
  if(btVec3.Root().LeftChild().Element()!=15)
    result = false;
  cout<<"left child btVec4 after map: "<<btVec4.Root().LeftChild().Element()<<endl;
  if(btVec4.Root().LeftChild().Element()!=15)
    result = false;

  return result;
}


bool TestCompareBTVecAndBTLnk(){
  bool result=true;

  int temp_size = genSize(gen)+1;
  lasd::Vector<int> vec(temp_size);
  for(int i=0; i<temp_size; i++){
      int temp_val = genNum(gen);
      vec[i]=temp_val;
  } 

  lasd::BinaryTreeVec<int> btVec(vec);
  lasd::BinaryTreeLnk<int> btLnk(vec);
  lasd::BinaryTreeVec<int> btVec2(btLnk);
  lasd::BinaryTreeLnk<int> btLnk2(btVec);
  
  if(btVec.lasd::BinaryTree<int>::operator!=(btLnk))
    result=false;
  btVec.Clear();
  if(btVec.lasd::BinaryTree<int>::operator==(btLnk))
    result=false;
  btLnk.Clear();
  if(btVec.lasd::BinaryTree<int>::operator!=(btLnk))
    result=false;

  if(btVec2.lasd::BinaryTree<int>::operator!=(btLnk2))
    result=false;
  btVec2.Clear();
  if(btVec2.lasd::BinaryTree<int>::operator==(btLnk2))
    result=false;
  btLnk2.Clear();
  if(btVec2.lasd::BinaryTree<int>::operator!=(btLnk2))
    result=false;
  
  cout<<"vec prima: ";
  for(int j=0; j<vec.Size(); j++)
    cout<<vec[j]<<"-";
  cout<<endl;
  lasd::Vector<int> vec2(vec);
  lasd::BinaryTreeVec<int> mbtVec(std::move(vec));
  if(vec==vec2)
    result=false;
  cout<<"vec dopo: ";
  for(int j=0; j<vec.Size(); j++)
    cout<<vec[j]<<"-";
  cout<<endl;
  cout<<"vec2: ";
  for(int j=0; j<vec2.Size(); j++)
    cout<<vec2[j]<<"-";
  cout<<endl;
  lasd::BinaryTreeLnk<int> mbtLnk(std::move(vec2));
  lasd::BinaryTreeVec<int> mbtVec2(std::move(mbtLnk));
  lasd::BinaryTreeLnk<int> mbtLnk2(std::move(mbtVec));
  
  if(mbtVec.lasd::BinaryTree<int>::operator==(mbtVec2))
    result=false;
  if(mbtLnk.lasd::BinaryTree<int>::operator==(mbtLnk2))
    result=false;

  if(mbtVec2.lasd::BinaryTree<int>::operator!=(mbtLnk2))
    result=false;
  mbtVec2.Clear();
  if(mbtVec2.lasd::BinaryTree<int>::operator==(mbtLnk2))
    result=false;
  mbtLnk2.Clear();
  if(mbtVec2.lasd::BinaryTree<int>::operator!=(mbtLnk2))
    result=false;

  return result;
}



/* ************************************************************************** */
/* ************************** FUNZIONI ESERCIZIO 3 ************************** */
/* ************************************************************************** */

bool TestHtConstructors(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare le size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  lasd::HashTableClsAdr<int> clsHT;
  lasd::HashTableOpnAdr<int> opnHT;
  if(clsHT.Size()!=0 || opnHT.Size()!=0 || clsHT.ReadArraySize()!=16 || opnHT.ReadArraySize()!=16)
    result = false;

  lasd::HashTableClsAdr<int> clsHT2(64);
  lasd::HashTableOpnAdr<int> opnHT2(64);
  if(clsHT2.Size()!=0 || opnHT2.Size()!=0 || clsHT2.ReadArraySize()!=64 || opnHT2.ReadArraySize()!=64)
    result = false;

  int temp_val;
  lasd::Vector<int> v1(200);
  for(int i=0; i<200; i++){
    temp_val = genNum(gen);
    v1[i]=temp_val;
  }

  lasd::HashTableClsAdr<int> clsHT3(v1);
  lasd::HashTableOpnAdr<int> opnHT3(v1);
  if(clsHT3.Size()!=v1.Size() || opnHT3.Size()!=v1.Size() || clsHT3.ReadArraySize()!=256 || opnHT3.ReadArraySize()!=512)
    result = false;

  lasd::HashTableClsAdr<int> clsHT4(64, v1);
  lasd::HashTableOpnAdr<int> opnHT4(64, v1);
  if(clsHT4.Size()!=v1.Size() || opnHT4.Size()!=v1.Size() || clsHT4.ReadArraySize()<64 || opnHT4.ReadArraySize()!=512)
    result = false;

  
  lasd::Vector<int> v2(v1);
  lasd::Vector<int> v3(v1);
  lasd::HashTableClsAdr<int> clsHT5(std::move(v2));
  lasd::HashTableOpnAdr<int> opnHT5(std::move(v3));
  if(clsHT5.Size()!=v1.Size() || opnHT5.Size()!=v1.Size() || clsHT5.ReadArraySize()!=256 || opnHT5.ReadArraySize()!=512)
    result = false;
  if(v2.Empty() || v3.Empty())
    result = false;

  lasd::List<int> l1(v1);
  lasd::List<int> l2(v1);
  lasd::HashTableClsAdr<int> clsHT6(64, std::move(l1));
  lasd::HashTableOpnAdr<int> opnHT6(64, std::move(l2));
  if(clsHT6.Size()!=v1.Size() || opnHT6.Size()!=v1.Size() || clsHT6.ReadArraySize()<64 || opnHT6.ReadArraySize()!=512)
    result = false;
  if(l1.Empty() || l2.Empty())
    result = false;

  lasd::HashTableClsAdr<int> clsHT7(clsHT3);
  lasd::HashTableOpnAdr<int> opnHT7(opnHT3);
  if(clsHT7.Size()!=v1.Size() || opnHT7.Size()!=v1.Size() || clsHT7.ReadArraySize()!=256 || opnHT7.ReadArraySize()!=512)
    result = false;

  lasd::HashTableClsAdr<int> clsHT8(std::move(clsHT3));
  lasd::HashTableOpnAdr<int> opnHT8(std::move(opnHT3));
  if(clsHT8.Size()!=v1.Size() || opnHT8.Size()!=v1.Size() || clsHT8.ReadArraySize()!=256 || opnHT8.ReadArraySize()!=512)
    result = false;
  if(!clsHT3.Empty() || !opnHT3.Empty())
    result = false;

  return result;
}


bool TestHtAssignements(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare le size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  lasd::HashTableClsAdr<int> clsHT1;
  lasd::HashTableOpnAdr<int> opnHT1;
  lasd::HashTableClsAdr<int> clsHT2(64);
  lasd::HashTableOpnAdr<int> opnHT2(64);

  int temp_val;
  lasd::Vector<int> v1(200);
  for(int i=0; i<200; i++){
    temp_val = genNum(gen);
    v1[i]=temp_val;
  }

  clsHT1 = v1;
  opnHT1 = v1;
  if(clsHT1.Size()!=v1.Size() || opnHT1.Size()!=v1.Size() || clsHT1.ReadArraySize()!=256 || opnHT1.ReadArraySize()!=512)
    result = false;

  clsHT2 = clsHT1;
  opnHT2 = opnHT1;
  if(clsHT2.Size()!=clsHT1.Size() || opnHT2.Size()!=opnHT1.Size() || clsHT2.ReadArraySize()!=256 || opnHT2.ReadArraySize()!=512)
    result = false;

  lasd::List<int> l1(v1);
  lasd::List<int> l2(v1);
  lasd::HashTableClsAdr<int> clsHT3;
  lasd::HashTableOpnAdr<int> opnHT3;
  lasd::HashTableClsAdr<int> clsHT4(64);
  lasd::HashTableOpnAdr<int> opnHT4(64);

  clsHT3 = std::move(l1);
  opnHT3 = std::move(l2);
  if(clsHT3.Size()!=v1.Size() || opnHT3.Size()!=v1.Size() || clsHT3.ReadArraySize()!=256 || opnHT3.ReadArraySize()!=512)
    result = false;
  if(l1.Empty() || l2.Empty())
    result = false;

  clsHT4 = std::move(clsHT3);
  opnHT4 = std::move(opnHT3);
  if(clsHT4.Size()!=v1.Size() || opnHT4.Size()!=v1.Size() || clsHT4.ReadArraySize()!=256 || opnHT4.ReadArraySize()!=512)
    result = false;
  if(!clsHT3.Empty() || !opnHT3.Empty() || clsHT3.ReadArraySize()!=64 || opnHT3.ReadArraySize()!=64)
    result = false;

  return result;
}

/* ************************************************************************** */

bool TestCompareClsAdr(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare la size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  lasd::HashTableClsAdr<int> ht1;
  lasd::HashTableClsAdr<int> ht2(64);

  if(ht1.Size()!=0 || ht1.Size()!=ht2.Size() || ht1.ReadArraySize()==ht2.ReadArraySize())
    result = false;
  if(ht1!=ht2)
    result = false;

  int temp_val;
  int temp_size = genSize(gen)+1;
  lasd::Vector<int> v1(temp_size);
  for(int i=0; i<temp_size; i++){
    temp_val = genSmallNum(gen);
    v1[i]=temp_val;
  }
  lasd::HashTableClsAdr<int> ht3(v1);
  lasd::HashTableClsAdr<int> ht4(ht3);
  ht1=ht3;
  ht2=ht4;

  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
    result = false;
  if(ht1.ReadArraySize()!=ht2.ReadArraySize() || ht3.ReadArraySize()!=ht4.ReadArraySize() || ht3.ReadArraySize()!=ht1.ReadArraySize())
    result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;
  
  ht1.Resize(300);
  ht2.Resize(400);

  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
    result = false;
  if(ht1.ReadArraySize()!=ht2.ReadArraySize() || ht3.ReadArraySize()==ht1.ReadArraySize())
    result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;

  ht2.RemoveAll(v1);
  if(!ht2.Empty() || ht1==ht2)
    result = false;
  ht2.InsertAll(v1);
  if(ht2.Empty() || ht1!=ht2)
    result = false;
  ht2.RemoveSome(v1);
  if(!ht2.Empty() || ht1==ht2)
    result = false;
  ht2.InsertSome(v1);
  if(ht2.Empty() || ht1!=ht2)
    result = false;

  temp_size = genSize(gen);
  lasd::Vector<int> v2(temp_size);
  for(int i=0; i<temp_size; i++){
    temp_val = genNum(gen);
    v2[i]=temp_val;
  }
  if(v2.Size()>=5){
    ht2.InsertAll(v2);
    ht4.InsertAll(v2);
    if(ht3.Size()==ht4.Size() || ht1.Size()==ht2.Size() || ht2.Size()!=ht4.Size())
      result = false;
    if(ht1.ReadArraySize()!=ht2.ReadArraySize() || ht3.ReadArraySize()==ht1.ReadArraySize())
      result = false;
    if(ht3==ht4 || ht1==ht2 || ht2!=ht4)
      result = false;
    
    if(v2[0]!=v2[1]){
      ht2.Remove(v2[0]);
      ht4.Remove(v2[1]);
      if(ht2==ht4 || ht2.Size()!=ht4.Size())
        result = false;
    }
    
    result = ht2.RemoveSome(v2);
    result = ht4.RemoveSome(v2);
    if(ht2!=ht4 || ht2.Size()!=ht4.Size())
      result = false;
    
    if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
      result = false;
    if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
      result = false;
  }
  if(v2.Size()>=1){
    ht1.InsertAll(v2);
    ht1.RemoveAll(v1);
    if(ht1==ht2)
      result = false;
  }
  ht1.Clear();
  if(ht1==ht2 || !ht1.Empty())
    result = false;
  ht1=ht2;
  if(ht1!=ht2 || ht1.Empty())
    result = false;
  ht1.Resize(0);
  if(ht1==ht2 || !ht1.Empty())
    result = false;
  ht1=ht2;
  if(ht1!=ht2 || ht1.Empty())
    result = false;
  
  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
      result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;
    
  lasd::Vector<int> v3(v1);
  lasd::Vector<int> v4(v1);
  lasd::Vector<int> v5(v1);
  lasd::Vector<int> v6(v1);
  lasd::HashTableClsAdr<int> ht5(std::move(v3));
  lasd::HashTableClsAdr<int> ht6(std::move(ht3));
  lasd::HashTableClsAdr<int> ht7;
  ht7=std::move(ht4);
  if(!ht3.Empty() || !ht4.Empty())
    result=false;
  if(ht5.Size()!=ht6.Size() || ht6.Size()!=ht7.Size() || ht1.Size()!=ht5.Size())
      result = false;
  if(ht5!=ht6 || ht6!=ht7 || ht1!=ht5)
    result = false;

  result = ht5.RemoveSome(std::move(v4));
  if(!ht5.Empty() || ht5==ht6)
    result=false;
  result = ht5.InsertSome(std::move(v5));
  if(ht5.Empty() || ht5!=ht6)
    result=false;

  if(v2.Size()>=1){
    ht5.InsertAll(std::move(v2));
    ht5.RemoveAll(std::move(v6));
    if(ht5==ht6)
      result = false;
  }
  ht5.Clear();
  if(ht5==ht6 || !ht5.Empty())
    result = false;
  ht5=std::move(ht2);
  if(ht5!=ht6 || ht5.Empty())
    result = false;
  ht5.Resize(0);
  if(ht5==ht6 || !ht5.Empty())
    result = false;
  ht5=std::move(ht7);
  if(ht5!=ht6 || ht5.Empty())
    result = false;

  return result;
}


bool TestCompareOpnAdr(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  lasd::HashTableOpnAdr<int> ht1;
  lasd::HashTableOpnAdr<int> ht2(64);

  if(ht1.Size()!=0 || ht1.Size()!=ht2.Size() || ht1.ReadArraySize()==ht2.ReadArraySize())
    result = false;
  if(ht1!=ht2)
    result = false;

  int temp_val;
  int temp_size = genSize(gen)+1;
  lasd::Vector<int> v1(temp_size);
  for(int i=0; i<temp_size; i++){
    temp_val = genSmallNum(gen);
    v1[i]=temp_val;
  }
  lasd::HashTableOpnAdr<int> ht3(v1);
  lasd::HashTableOpnAdr<int> ht4(ht3);
  ht1=ht3;
  ht2=ht4;

  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
    result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;
  
  ht1.Resize(300);
  ht2.Resize(400);

  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
    result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;

  ht2.RemoveAll(v1);
  if(!ht2.Empty() || ht1==ht2)
    result = false;
  ht2.InsertAll(v1);
  if(ht2.Empty() || ht1!=ht2)
    result = false;
  ht2.RemoveSome(v1);
  if(!ht2.Empty() || ht1==ht2)
    result = false;
  ht2.InsertSome(v1);
  if(ht2.Empty() || ht1!=ht2)
    result = false;

  temp_size = genSize(gen);
  lasd::Vector<int> v2(temp_size);
  for(int i=0; i<temp_size; i++){
    temp_val = genNum(gen);
    v2[i]=temp_val;
  }
  if(v2.Size()>=5){
    ht2.InsertAll(v2);
    ht4.InsertAll(v2);
    if(ht3.Size()==ht4.Size() || ht1.Size()==ht2.Size() || ht2.Size()!=ht4.Size())
      result = false;
    if(ht3==ht4 || ht1==ht2 || ht2!=ht4)
      result = false;
    
    if(v2[0]!=v2[1]){
      ht2.Remove(v2[0]);
      ht4.Remove(v2[1]);
      if(ht2==ht4 || ht2.Size()!=ht4.Size())
        result = false;
    }
    
    result = ht2.RemoveSome(v2);
    result = ht4.RemoveSome(v2);
    if(ht2!=ht4 || ht2.Size()!=ht4.Size())
      result = false;
    
    if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
      result = false;
    if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
      result = false;
  }
  if(v2.Size()>=1){
    ht1.InsertAll(v2);
    ht1.RemoveAll(v1);
    if(ht1==ht2)
      result = false;
  }
  ht1.Clear();
  if(ht1==ht2 || !ht1.Empty())
    result = false;
  ht1=ht2;
  if(ht1!=ht2 || ht1.Empty())
    result = false;
  ht1.Resize(0);
  if(ht1==ht2 || !ht1.Empty())
    result = false;
  ht1=ht2;
  if(ht1!=ht2 || ht1.Empty())
    result = false;
  
  if(ht3.Size()!=ht4.Size() || ht1.Size()!=ht2.Size() || ht3.Size()!=ht1.Size())
      result = false;
  if(ht3!=ht4 || ht1!=ht2 || ht3!=ht1)
    result = false;
    
  lasd::Vector<int> v3(v1);
  lasd::Vector<int> v4(v1);
  lasd::Vector<int> v5(v1);
  lasd::Vector<int> v6(v1);
  lasd::HashTableOpnAdr<int> ht5(std::move(v3));
  lasd::HashTableOpnAdr<int> ht6(std::move(ht3));
  lasd::HashTableOpnAdr<int> ht7;
  ht7=std::move(ht4);
  if(!ht3.Empty() || !ht4.Empty())
    result=false;
  if(ht5.Size()!=ht6.Size() || ht6.Size()!=ht7.Size() || ht1.Size()!=ht5.Size())
      result = false;
  if(ht5!=ht6 || ht6!=ht7 || ht1!=ht5)
    result = false;

  result = ht5.RemoveSome(std::move(v4));
  if(!ht5.Empty() || ht5==ht6)
    result=false;
  result = ht5.InsertSome(std::move(v5));
  if(ht5.Empty() || ht5!=ht6)
    result=false;

  if(v2.Size()>=1){
    ht5.InsertAll(std::move(v2));
    ht5.RemoveAll(std::move(v6));
    if(ht5==ht6)
      result = false;
  }
  ht5.Clear();
  if(ht5==ht6 || !ht5.Empty())
    result = false;
  ht5=std::move(ht2);
  if(ht5!=ht6 || ht5.Empty())
    result = false;
  ht5.Resize(0);
  if(ht5==ht6 || !ht5.Empty())
    result = false;
  ht5=std::move(ht7);
  if(ht5!=ht6 || ht5.Empty())
    result = false;

  return result;
}


bool TestCompareDifferentHT(){
  bool result = true;

  lasd::HashTableClsAdr<int> htCls1;
  lasd::HashTableOpnAdr<int> htOpn1;

  if(htCls1.HashTable::operator!=(htOpn1) || htCls1.ReadArraySize()!=htOpn1.ReadArraySize())
    result = false;

  lasd::HashTableClsAdr<int> htCls2(64);
  lasd::HashTableOpnAdr<int> htOpn2(64);

  if(htCls2.HashTable::operator!=(htOpn2) || htCls2.ReadArraySize()!=htOpn2.ReadArraySize())
    result = false;

  int temp_val;
  int temp_size = genSize(gen)+1;
  lasd::Vector<int> v1(temp_size);
  for(int i=0; i<temp_size; i++){
    temp_val = genSmallNum(gen);
    v1[i]=temp_val;
  }

  lasd::HashTableClsAdr<int> htCls3(v1);
  lasd::HashTableOpnAdr<int> htOpn3(v1);

  if(htCls3.HashTable::operator!=(htOpn3))
    result = false;

  htCls1=htCls3;
  htOpn1=htOpn3;
  if(htCls1.HashTable::operator!=(htOpn1))
    result = false;

  lasd::Vector<int> v2(temp_size/2);
  for(int i=0; i<temp_size/2; i++)
    v2[i]=v1[i];

  htOpn3.RemoveAll(v2);

  if(htCls3.HashTable::operator==(htOpn3) || htCls3.Size()==htOpn3.Size())
    result = false;

  htCls3.Clear();
  htOpn3.Resize(0);
  if(htCls3.HashTable::operator!=(htOpn3))
  result = false;

  htCls3.Resize(0);
  if(htCls3.HashTable::operator!=(htOpn3) || htCls3.ReadArraySize()!=htOpn3.ReadArraySize())
    result = false;


  htCls1.Clear();
  htOpn1.Clear();
  lasd::Vector<int> v3(v1);
  lasd::HashTableClsAdr<int> htCls3Move(std::move(v1));
  lasd::HashTableOpnAdr<int> htOpn3Move(std::move(v3));

  if(htCls3Move.HashTable::operator!=(htOpn3Move))
    result = false;

  lasd::HashTableClsAdr<int> htCls4(htCls3Move);
  lasd::HashTableOpnAdr<int> htOpn4(htOpn3Move);
  htCls1=std::move(htCls4);
  htOpn1=std::move(htOpn4);
  if(htCls1.HashTable::operator!=(htOpn1))
    result = false;

  htOpn3Move.RemoveAll(std::move(v2));

  if(htCls3Move.HashTable::operator==(htOpn3Move) || htCls3Move.Size()==htOpn3Move.Size())
    result = false;

  htCls3Move.Clear();
  htOpn3Move.Resize(0);
  if(htCls3Move.HashTable::operator!=(htOpn3Move))
  result = false;

  htCls3Move.Resize(0);
  if(htCls3Move.HashTable::operator!=(htOpn3Move) || htCls3Move.ReadArraySize()!=htOpn3Move.ReadArraySize())
    result = false;

  return result;
}

/* ************************************************************************** */

bool TestResizeWithMoreElements(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare le size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  int temp_val;
  lasd::Vector<int> v1(200);
  for(int i=0; i<200; i++){
    temp_val = genNum(gen);
    v1[i]=temp_val;
  }

  cout<<"\nv1 size: "<<v1.Size();

  lasd::HashTableClsAdr<int> clsHT(v1);
  cout<<"\nclsHT Size(): "<<clsHT.Size()<<"\t clsHT arraySize: "<<clsHT.ReadArraySize();
  clsHT.Resize(30);
  cout<<"\nclsHT Size(): "<<clsHT.Size()<<"\t clsHT arraySize: "<<clsHT.ReadArraySize();

  lasd::HashTableOpnAdr<int> opnHT(v1);
  cout<<"\nopnHT Size(): "<<opnHT.Size()<<"\t opnHT arraySize: "<<opnHT.ReadArraySize();
  opnHT.Resize(30);
  cout<<"\nopnHT Size(): "<<opnHT.Size()<<"\t opnHT arraySize: "<<opnHT.ReadArraySize();

  if(clsHT.Size()<33 || opnHT.Size()<33 || clsHT.ReadArraySize()<32 || opnHT.ReadArraySize()!=512)
    result = false;

  lasd::HashTableClsAdr<int> clsHT2; 
  clsHT2 = v1;
  cout<<"\nclsHT2 Size(): "<<clsHT2.Size()<<"\t clsHT2 arraySize: "<<clsHT2.ReadArraySize();
  clsHT2.Resize(30);
  cout<<"\nclsHT2 Size(): "<<clsHT2.Size()<<"\t clsHT2 arraySize: "<<clsHT2.ReadArraySize();

  lasd::HashTableOpnAdr<int> opnHT2;
  opnHT2 = v1;
  cout<<"\nopnHT2 Size(): "<<opnHT2.Size()<<"\t opnHT2 arraySize: "<<opnHT2.ReadArraySize();
  opnHT2.Resize(30);
  cout<<"\nopnHT2 Size(): "<<opnHT2.Size()<<"\t opnHT2 arraySize: "<<opnHT2.ReadArraySize();

  if(clsHT2.Size()<33 || opnHT2.Size()<33 || clsHT2.ReadArraySize()<32 || opnHT2.ReadArraySize()!=512)
    result = false;

  lasd::HashTableClsAdr<int> clsHT3 = std::move(clsHT2);
  cout<<"\nclsHT3 Size(): "<<clsHT3.Size()<<"\t clsHT3 arraySize: "<<clsHT3.ReadArraySize();
  clsHT3.Resize(30);
  cout<<"\nclsHT3 Size(): "<<clsHT3.Size()<<"\t clsHT3 arraySize: "<<clsHT3.ReadArraySize();

  lasd::HashTableOpnAdr<int> opnHT3 = std::move(opnHT2);
  cout<<"\nopnHT3 Size(): "<<opnHT3.Size()<<"\t opnHT3 arraySize: "<<opnHT3.ReadArraySize();
  opnHT3.Resize(30);
  cout<<"\nopnHT3 Size(): "<<opnHT3.Size()<<"\t opnHT3 arraySize: "<<opnHT3.ReadArraySize();

  if(clsHT3.Size()<33 || opnHT3.Size()<33 || clsHT3.ReadArraySize()<32 || opnHT3.ReadArraySize()!=512)
    result = false;
  
  cout<<"\nopnHT2 Size(): "<<opnHT2.Size()<<"\t opnHT2 arraySize: "<<opnHT2.ReadArraySize();
  if(clsHT2.Size()!=0 || opnHT2.Size()!= 0 || clsHT2.ReadArraySize()!=16 || opnHT2.ReadArraySize()!=16)
    result = false;

  return result;
}


bool TestResizeToDefault(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare le size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
  */

  int temp_val;
  lasd::Vector<int> v1(200);
  for(int i=0; i<200; i++){
    temp_val = genNum(gen);
    v1[i]=temp_val;
  }

  cout<<"\nv1 size: "<<v1.Size();

  lasd::HashTableClsAdr<int> clsHT(v1);
  cout<<"\nclsHT Size(): "<<clsHT.Size()<<"\t clsHT arraySize: "<<clsHT.ReadArraySize();
  clsHT.Resize(0);
  cout<<"\nclsHT Size(): "<<clsHT.Size()<<"\t clsHT arraySize: "<<clsHT.ReadArraySize();

  lasd::HashTableOpnAdr<int> opnHT(v1);
  cout<<"\nopnHT Size(): "<<opnHT.Size()<<"\t opnHT arraySize: "<<opnHT.ReadArraySize();
  opnHT.Resize(0);
  cout<<"\nopnHT Size(): "<<opnHT.Size()<<"\t opnHT arraySize: "<<opnHT.ReadArraySize();

  if(clsHT.Size()!=0 || opnHT.Size()!=0 || clsHT.ReadArraySize()!=16 || opnHT.ReadArraySize()!=16)
    result = false;

  return result;
}


bool TestResizeWhenLoadedClsAdr(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare i coefficienti A=1, B=0;
  - Impostare le size di default a 16;
  - Impostare il ritorno di Operator() di int a val;
  - Mettere pubblico array in HashTableClsAdr;
  - Commentare il controllo nelle Insert() di HashTableClsAdr sulla size dei Dictionary;
  - Decommentare i controlli nel test in cui è chiamato ht.array[5].Size();
  - Decommentare i controlli nel test sulla arraySize.
  */

  cout<<"\n***Resize ClsAdr: "<<endl;
  lasd::HashTableClsAdr<int> ht;
  for(int i=0; i<12; i++){
    ht.Insert(i);
  }
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=12 || ht.ReadArraySize()!=16)
    result = false;

  ht.Insert(12);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=13 || ht.ReadArraySize()!=32)
    result = false;

  ht.Resize(0);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=0 || ht.ReadArraySize()!=16)
    result = false;


  for(int i=0; i<12; i++){
    ht.Insert(5+(16*i));
  }
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<"\tDictionary size: "/*<<ht.array[5].Size()*/<<endl;
  if(ht.Size()!=12 /*|| ht.ReadArraySize()!=16*/ /*|| ht.array[5].Size()!=12*/)
    result = false;
  
  ht.Insert(5+(16*12));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<"\tDictionary size: "/*<<ht.array[5].Size()*/<<endl;
  if(ht.Size()!=13 /*|| ht.ReadArraySize()!=32*/ /*|| ht.array[5].Size()>7*/)
    result = false;

  ht.Resize(0);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<"\tDictionary size: "/*<<ht.array[5].Size()*/<<endl;
  if(ht.Size()!=0 || ht.ReadArraySize()!=16 /*|| ht.array[5].Size()>7*/)
    result = false;

  return result;
}


bool TestResizeWhenLoadedDictionary(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare i coefficienti A=1, B=0;
  - Impostare le size di default a 16;
  - Impostare il ritorno di Operator() di int a val;
  - Mettere pubblico array in HashTableClsAdr;
  */

  cout<<"\n***Resize ClsAdr for loaded dictionary: "<<endl;
  lasd::HashTableClsAdr<int> ht;
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(!ht.Empty() || ht.ReadArraySize()!=16)
    result = false;

  for(int i=0; i<4; i++)
    ht.Insert(1+(16*i));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=4 || ht.ReadArraySize()!=16)
    result = false;

  ht.Remove(1);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=3 || ht.ReadArraySize()!=16)
    result = false;
  ht.Insert(1);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=4 || ht.ReadArraySize()!=16)
    result = false;

  ht.Insert(1+(16*4));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=5 || ht.ReadArraySize()!=32)
    result = false;
  ht.Insert(2);
  ht.Insert(3);
  ht.Remove(1+(16*4));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=6 || ht.ReadArraySize()!=32)
    result = false;

  ht.Insert(1+(16*4));
  ht.Insert(4);
  ht.Insert(5);
  ht.Insert(6);
  ht.Insert(7);
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=11 || ht.ReadArraySize()!=32)
    result = false;

  ht.Insert(1+(32*5));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=12 || ht.ReadArraySize()!=32)
    result = false;

  ht.Insert(7+(32*2));
  ht.Insert(7+(32*3));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=14 || ht.ReadArraySize()!=32)
    result = false;

  ht.Insert(1+(32*6));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=15 || ht.ReadArraySize()!=32)
    result = false;
    
  ht.Insert(1+(32*7));
  cout<<"size: "<<ht.Size()<<"\tarraySize: "<<ht.ReadArraySize()<<endl;
  if(ht.Size()!=16 || ht.ReadArraySize()!=64)
    result = false;

  ht.PrintClsAdrHT();

  return result;
}


bool TestResizeAfterManyDeletedElements(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare i coefficienti A=1, B=0;
  - Impostare le size di default a 16;
  - Mettere pubblico flagsArray in HashTableOpnAdr;
  - Mettere pubblico deleted_elements in HashTableOpnAdr;
  - Assicurarsi di usare l'Hashing quadratico.
  */

  lasd::HashTableOpnAdr<int> ht;
  for(int i=0; i<7; i++)
    ht.Insert(5+(16*i));
  ht.PrintOpnAdrHT();
  if(ht.Size()!=7 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=0)
    result = false;

  ht.Remove(5+(16*5));
  ht.Remove(5+(16*4));
  ht.Remove(5+(16*3));
  ht.Remove(5+(16*2));
  ht.PrintOpnAdrHT();
  if(ht.Size()!=3 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=4)
    result = false;

  ht.Remove(5+(16*1));
  ht.PrintOpnAdrHT();
  if(ht.Size()!=2 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=0)
    result = false;

  return result;
}

/* ************************************************************************** */

bool TestNoLoopOnDeleted(){
  bool result = true;

  /*
  ******************** README ********************
  Per eseguire correttamente il test:
  - Impostare le size di default a 16;
  - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni
  */

  lasd::HashTableOpnAdr<int> ht(30);
  for(int i=0; i<2000; i++){
    ht.Insert(i);
    ht.Remove(i);
  }
  ht.Insert(0);
  ht.Remove(0);
  ht.Insert(0);
  cout<<"\nesiste? (atteso 1) "<<ht.Exists(0);
  ht.Insert(44);
  ht.Insert(45);
  ht.Insert(46);
  ht.Remove(45);
  ht.Remove(45);
  ht.Remove(21000);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(36);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(39);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(7);
  cout<<"\nesiste? (atteso 1) "<<ht.Exists(44);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(45);
  cout<<"\nesiste? (atteso 1) "<<ht.Exists(46);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(12);
  cout<<"\nesiste? (atteso 0) "<<ht.Exists(21000);
  cout<<endl;

  lasd::HashTableOpnAdr<int> ht2(5);
  for(int i=0; i<100; i++){
    ht2.Insert(i);
    //cout<<"size: "<<ht2.Size();
    ht2.Remove(i);
    //cout<<" - size: "<<ht2.Size()<<"\t"<<" - arraySize: "<<ht2.ReadArraySize()<<endl;
    //ht2.CheckIfAllElementsAreDeleted();
  }
  cout<<"\nesiste? (atteso 0) "<<ht2.Exists(10);
  cout<<"\nesiste? (atteso 0) "<<ht2.Exists(1243);
  ht2.Insert(555);
  cout<<"\nesiste? (atteso 1) "<<ht2.Exists(555);
  ht2.Remove(555);
  cout<<"\nesiste? (atteso 0) "<<ht2.Exists(555);
  cout<<"\nNessun problema di loop\n";

  return result;
}


bool TestQuadraticProbing(){
    bool result = true;

    /*
    ******************** README ********************
    Per eseguire correttamente il test:
    - Impostare i coefficienti A=1, B=0;
    - Impostare le size di default a 16;
    - Impostare il ritorno di Operator() di int a val;
    - Assicurarsi di usare l'Hashing quadratico;
    - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
    - Decommentare il controllo al termine della funzione.
    */

    lasd::HashTableOpnAdr<int> ht(8);

    cout<<"\n\nTabella vuota: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(6);
    cout<<"\n\nInserito 6: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(5);
    cout<<"\n\nInserito 5: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(21);
    cout<<"\n\nInserito 21(5 collision->6 collision->8): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(22);
    cout<<"\n\nInserito 22(6 collision->7): ";
    //ht.PrintOpnAdrHT();

    ht.Insert(9);
    ht.Insert(10);
    ht.Insert(11);
    ht.Insert(13);
    cout<<"\n\nInseriti 9, 10, 11, 13: ";
    //ht.PrintOpnAdrHT();

    ht.Insert(31);
    cout<<"\n\nResize a 32: 21 spostato da 8 a 21, 22 spostato da 7 a 22";
    cout<<"\n\nInserito 31: ";
    //ht.PrintOpnAdrHT();

    ht.Insert(66);
    cout<<"\n\nInserito 66(2): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(5);
    cout<<"\n\nInserito 5(Già presente: non inserito): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(-61);
    cout<<"\n\nInserito -61(3): ";
    //ht.PrintOpnAdrHT();
    ht.Remove(14);
    cout<<"\n\nRimosso 14 (non presente, non cambia nulla): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(2);
    cout<<"\n\nInserito 2(2 collision->3 collision->5 collision->8): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(34);
    cout<<"\n\nInserito 34(2 collision->3 collision->5 collision->8 collision->12): ";
    //ht.PrintOpnAdrHT();

    cout<<"\nExists(13): "<<ht.Exists(13);
    cout<<"\nExists(5): "<<ht.Exists(5);
    cout<<"\nExists(61): "<<ht.Exists(61);
    cout<<"\nExists(-61): "<<ht.Exists(-61);
    cout<<"\nExists(14): "<<ht.Exists(14);
    cout<<"\nExists(2): "<<ht.Exists(2);
    cout<<"\nExists(18): "<<ht.Exists(18);

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;
    cout<<"\n\nRimosso 2: ";
    ht.Remove(2);
    //ht.PrintOpnAdrHT();
    cout<<"\nExists(2): "<<ht.Exists(2);
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<"\n\nRimosso -61: ";
    ht.Remove(-61);
    //ht.PrintOpnAdrHT();
    cout<<"\nExists(-61): "<<ht.Exists(-61);
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<endl;

    if(!ht.Exists(13) || ht.Exists(-61) || ht.Exists(14) || ht.ReadArraySize()!=32 || ht.Size()!=11)
      result = false;
    cout<<"\n\nResult: "<<result<<endl;

    return result;
  }


  bool TestQuadraticProbingAfterResize(){
    bool result = true;

    /*
    ******************** README ********************
    Per eseguire correttamente il test:
    - Impostare i coefficienti A=1, B=0;
    - Impostare le size di default a 16;
    - Impostare il ritorno di Operator() di int a val;
    - Assicurarsi di usare l'Hashing quadratico;
    - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
    - Decommentare il controllo al termine della funzione.
    */

    lasd::HashTableOpnAdr<int> ht(16);

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<"\n\nTabella vuota: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(3);
    cout<<"\n\nInserito 3: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(19);
    cout<<"\n\nInserito 19(3 collision->4): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(35);
    cout<<"\n\nInserito 35(3 collision->4 collision->6): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(51);
    cout<<"\n\nInserito 51(3 collision->4 collision->6 collision ->9): ";
    //ht.PrintOpnAdrHT();

    cout<<"\n\nInseriti 12, 13, 14 e 15: ";
    ht.Insert(12);
    ht.Insert(13);
    ht.Insert(14);
    ht.Insert(15);
    //ht.PrintOpnAdrHT();

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    ht.Insert(67);
    cout<<"\n\nInserito 67(3 collision->4 collision->6), arraySize>=8 dunque chiama Resize()";
    cout<<"\nDopo la resize mi aspetto 3 in 3, 19 in 19, 35 in 4, 51 in 20, 67 in 6";
    //ht.PrintOpnAdrHT();

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<"\nEffettuo Clear():";
    ht.Clear();

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<"\n\nTabella vuota: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(3);
    cout<<"\n\nInserito 3: ";
    //ht.PrintOpnAdrHT();
    ht.Insert(35);
    cout<<"\n\nInserito 35(3 collision->4): ";
    //ht.PrintOpnAdrHT();
    ht.Insert(51);
    cout<<"\n\nInserito 51(19): ";
    //ht.PrintOpnAdrHT();

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    ht.Insert(67);
    cout<<"\n\nInserito 67(3 collision->4 collision->6): ";
    //ht.PrintOpnAdrHT();

    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    ht.Remove(67);
    cout<<"\n\nRimosso 67 (dopo 2 collisioni) - Effettua una Resize";
    //ht.PrintOpnAdrHT();
    cout<<"\nEsiste 67?: "<<ht.Exists(67)<<endl;
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    ht.Remove(35);
    cout<<"\n\nRimosso 35 (dopo 1 collisione)";
    //ht.PrintOpnAdrHT();

    cout<<"\nEsiste 35?: "<<ht.Exists(35)<<endl;
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    cout<<"\nEsiste 51?: "<<ht.Exists(51)<<endl;
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    ht.Insert(51);
    cout<<"\n\nInserito 51(3 collision->4) e cancella il successivo in 6: ";
    //ht.PrintOpnAdrHT();
    cout<<"\nEsiste 51?: "<<ht.Exists(51)<<endl;
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    if((ht.Size()!=2) || (ht.ReadArraySize()!=16) || (!ht.Exists(51)) || (ht.Exists(35)))
      result=false;

    cout<<"\nEffettuo Resize(0):";
    ht.Resize(0);
    cout<<"\n\narraySize: "<<ht.ReadArraySize()<<"\tSize: "<<ht.Size()<<endl;

    if(ht.Size()!=0 || ht.ReadArraySize()!=16)
      result=false;

    return result;
  }


  bool TestSwapDeletedElements(){
    bool result = true;

    /*
    ******************** README ********************
    Per eseguire correttamente il test:
    - Impostare i coefficienti A=1, B=0;
    - Impostare le size di default a 16;
    - Mettere pubblico flagsArray in HashTableOpnAdr;
    - Mettere pubblico flagsArray in HashTableOpnAdr;
    - Assicurarsi di usare l'Hashing quadratico;
    - Decommentare i controlli sul bit negli if all'interno del test.
    */

    lasd::HashTableOpnAdr<int> ht;
    for(int i=0; i<5; i++)
      ht.Insert(5+(16*i));
    ht.PrintOpnAdrHT();
    if(ht.Size()!=5 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=0)
      result = false;

    ht.Remove(5+(16*3));
    ht.Remove(5+(16*2));
    ht.Remove(5+(16*1));
    ht.PrintOpnAdrHT();
    if(ht.Size()!=2 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=3)
      result = false;
    if(/*ht.flagsArray[6][1]==1 ||*/ ht.Exists(5+(16*1)) || !ht.Exists(5+(16*4)))
      result = false;

    ht.Exists(5+(16*4));
    ht.PrintOpnAdrHT();
    if(ht.Size()!=2 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=3)
      result = false;
    if(/*ht.flagsArray[6][1]==0 ||*/ ht.Exists(5+(16*1)) || !ht.Exists(5+(16*4)))
      result = false;

    ht.Clear();
    for(int i=0; i<5; i++)
      ht.Insert(5+(16*i));
    ht.PrintOpnAdrHT();

    ht.Remove(5+(16*1));
    ht.Remove(5+(16*2));
    ht.Remove(5+(16*3));
    ht.PrintOpnAdrHT();

    ht.Exists(5+(16*4));
    ht.PrintOpnAdrHT();
    if(ht.Size()!=2 || ht.ReadArraySize()!=16 || ht.ReadDeletedElements()!=3)
      result = false;
    if(/*ht.flagsArray[6][1]==0 ||*/ ht.Exists(5+(16*1)) || !ht.Exists(5+(16*4)))
      result = false;

    return result;
  }


  bool TestAllDictionaryFunctions(){
    bool result = true;

    /*
    ******************** README ********************
    Per eseguire correttamente il test:
    - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
    */

    lasd::List<int> myList;
    lasd::BST<int> myBST;
    lasd::HashTableClsAdr<int> myClsHT;
    lasd::HashTableOpnAdr<int> myOpnHT;

    bool resultOnList = false;
    bool resultOnBST = false;
    bool resultOnClsHT = false;
    bool resultOnOpnHT = false;

    int temp_val;
    int temp_size1 = genSize(gen)+1;
    int temp_size2 = genSize(gen)+1;
    lasd::List<int> l1;
    lasd::List<int> l2;
    lasd::Vector<int> v1(temp_size1);
    lasd::Vector<int> v2(temp_size2);

    for(int i=0; i<temp_size1; i++){
      temp_val = genNum(gen);
      v1[i]=temp_val;
      l1.Insert(temp_val);
    }
    for(int i=0; i<temp_size2; i++){
      temp_val = genNum(gen);
      v2[i]=temp_val;
      l2.Insert(temp_val);
    }

    if(!myList.Empty() || !myBST.Empty() || !myClsHT.Empty() || !myOpnHT.Empty())
      result = false;
    
    resultOnList = myList.InsertAll(v1);
    resultOnBST = myBST.InsertAll(v1);
    resultOnClsHT = myClsHT.InsertAll(v1);
    resultOnOpnHT = myOpnHT.InsertAll(v1);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    resultOnList = myList.InsertSome(v2);
    resultOnBST = myBST.InsertSome(v2);
    resultOnClsHT = myClsHT.InsertSome(v2);
    resultOnOpnHT = myOpnHT.InsertSome(v2);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;
    
    resultOnList = myList.RemoveAll(v2);
    resultOnBST = myBST.RemoveAll(v2);
    resultOnClsHT = myClsHT.RemoveAll(v2);
    resultOnOpnHT = myOpnHT.RemoveAll(v2);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    resultOnList = myList.RemoveSome(v1);
    resultOnBST = myBST.RemoveSome(v1);
    resultOnClsHT = myClsHT.RemoveSome(v1);
    resultOnOpnHT = myOpnHT.RemoveSome(v1);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;
    
    if(!myList.Empty() || !myBST.Empty() || !myClsHT.Empty() || !myOpnHT.Empty())
      result = false;

    resultOnList = myList.InsertAll(l1);
    resultOnBST = myBST.InsertAll(l1);
    resultOnClsHT = myClsHT.InsertAll(l1);
    resultOnOpnHT = myOpnHT.InsertAll(l1);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    resultOnList = myList.InsertSome(l2);
    resultOnBST = myBST.InsertSome(l2);
    resultOnClsHT = myClsHT.InsertSome(l2);
    resultOnOpnHT = myOpnHT.InsertSome(l2);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;
    
    resultOnList = myList.RemoveAll(l2);
    resultOnBST = myBST.RemoveAll(l2);
    resultOnClsHT = myClsHT.RemoveAll(l2);
    resultOnOpnHT = myOpnHT.RemoveAll(l2);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    resultOnList = myList.RemoveSome(l1);
    resultOnBST = myBST.RemoveSome(l1);
    resultOnClsHT = myClsHT.RemoveSome(l1);
    resultOnOpnHT = myOpnHT.RemoveSome(l1);
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;
    
    if(!myList.Empty() || !myBST.Empty() || !myClsHT.Empty() || !myOpnHT.Empty())
      result = false;

    lasd::List<int> l1Move1(l1);
    lasd::List<int> l1Move2(l1);
    lasd::List<int> l1Move3(l1);
    lasd::List<int> l1Move4(l1);
    lasd::List<int> l1Move5(l1);
    lasd::List<int> l1Move6(l1);
    lasd::List<int> l1Move7(l1);
    lasd::List<int> l1Move8(l1);
    lasd::List<int> l2Move1(l2);
    lasd::List<int> l2Move2(l2);
    lasd::List<int> l2Move3(l2);
    lasd::List<int> l2Move4(l2);
    lasd::List<int> l2Move5(l2);
    lasd::List<int> l2Move6(l2);
    lasd::List<int> l2Move7(l2);
    lasd::List<int> l2Move8(l2);

    resultOnList = myList.InsertAll(std::move(l1Move1));
    resultOnBST = myBST.InsertAll(std::move(l1Move2));
    resultOnClsHT = myClsHT.InsertAll(std::move(l1Move3));
    resultOnOpnHT = myOpnHT.InsertAll(std::move(l1Move4));
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    resultOnList = myList.InsertSome(std::move(l2Move1));
    resultOnBST = myBST.InsertSome(std::move(l2Move2));
    resultOnClsHT = myClsHT.InsertSome(std::move(l2Move3));
    resultOnOpnHT = myOpnHT.InsertSome(std::move(l2Move4));
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    if(myList.Size()!=myBST.Size() || myList.Size()!=myClsHT.Size() || myList.Size()!=myOpnHT.Size())
      result = false;
    
    resultOnList = myList.RemoveAll(std::move(l2Move5));
    resultOnBST = myBST.RemoveAll(std::move(l2Move6));
    resultOnClsHT = myClsHT.RemoveAll(std::move(l2Move7));
    resultOnOpnHT = myOpnHT.RemoveAll(std::move(l2Move8));
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;

    if(myList.Size()!=myBST.Size() || myList.Size()!=myClsHT.Size() || myList.Size()!=myOpnHT.Size())
      result = false;

    resultOnList = myList.RemoveSome(std::move(l1Move5));
    resultOnBST = myBST.RemoveSome(std::move(l1Move6));
    resultOnClsHT = myClsHT.RemoveSome(std::move(l1Move7));
    resultOnOpnHT = myOpnHT.RemoveSome(std::move(l1Move8));
    if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
      result = false;
    
    if(!myList.Empty() || !myBST.Empty() || !myClsHT.Empty() || !myOpnHT.Empty())
      result = false;

    return result;
  }


  bool TestIterativeDictionaryAndAutoresize(){
    bool result=true;

    /*
    ******************** README ********************
    Per eseguire correttamente il test:
    - Commentare i controlli per la resize quando raggiunto un certo numero di collisioni;
    */

    lasd::List<int> myList;
    lasd::BST<int> myBST;
    lasd::HashTableClsAdr<int> myClsHT;
    lasd::HashTableOpnAdr<int> myOpnHT;

    bool resultOnList = false;
    bool resultOnBST = false;
    bool resultOnClsHT = false;
    bool resultOnOpnHT = false;

    int temp_val;
    for(int iterations=0; iterations<NUMERO_TEST_ITERATIVI_HT; iterations++){
      int temp_size1 = genSize(gen)+1;
      int temp_size2 = genSize(gen)+1;
      int temp_size3 = genSize(gen)+1;
      lasd::Vector<int> v1(temp_size1);
      lasd::Vector<int> v2(temp_size2);
      lasd::Vector<int> v3(temp_size3);
      lasd::List<int> l1;

      for(int i=0; i<temp_size1; i++){
        temp_val = genNum(gen);
        v1[i]=temp_val;
      }
      for(int i=0; i<temp_size2; i++){
        temp_val = genNum(gen);
        v2[i]=temp_val;
      }
      for(int i=0; i<temp_size3; i++){
        temp_val = genSmallNum(gen);
        v3[i]=temp_val;
        temp_val = genNum(gen);
        l1.Insert(temp_val);
      }
      
      resultOnList = myList.InsertAll(v1);
      resultOnBST = myBST.InsertAll(v1);
      resultOnClsHT = myClsHT.InsertAll(v1);
      resultOnOpnHT = myOpnHT.InsertAll(v1);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      resultOnList = myList.InsertSome(v2);
      resultOnBST = myBST.InsertSome(v2);
      resultOnClsHT = myClsHT.InsertSome(v2);
      resultOnOpnHT = myOpnHT.InsertSome(v2);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      resultOnList = myList.InsertAll(v2);
      resultOnBST = myBST.InsertAll(v2);
      resultOnClsHT = myClsHT.InsertAll(v2);
      resultOnOpnHT = myOpnHT.InsertAll(v2);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      if(myList.Size()!=myBST.Size() || myList.Size()!=myClsHT.Size() || myList.Size()!=myOpnHT.Size())
        result = false;
      
      resultOnList = myList.RemoveAll(v2);
      resultOnBST = myBST.RemoveAll(v2);
      resultOnClsHT = myClsHT.RemoveAll(v2);
      resultOnOpnHT = myOpnHT.RemoveAll(v2);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      resultOnList = myList.RemoveSome(v1);
      resultOnBST = myBST.RemoveSome(v1);
      resultOnClsHT = myClsHT.RemoveSome(v1);
      resultOnOpnHT = myOpnHT.RemoveSome(v1);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      if(myList.Size()!=myBST.Size() || myList.Size()!=myClsHT.Size() || myList.Size()!=myOpnHT.Size())
        result = false;
      
      resultOnList = myList.InsertAll(v3);
      resultOnBST = myBST.InsertAll(v3);
      resultOnClsHT = myClsHT.InsertAll(v3);
      resultOnOpnHT = myOpnHT.InsertAll(v3);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;

      resultOnList = myList.InsertSome(l1);
      resultOnBST = myBST.InsertSome(l1);
      resultOnClsHT = myClsHT.InsertSome(l1);
      resultOnOpnHT = myOpnHT.InsertSome(l1);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;
      cout<<"\nSIZE:\t\t"<<"List:"<<myList.Size()<<"\t\tBST:"<<myBST.Size()<<"\t\tClsHT:"<<myClsHT.Size()<<"\t\tOpnHT:"<<myOpnHT.Size();
      cout<<"\nArraySize:\t"<<"List:"<<myList.Size()<<"\t\tBST:"<<myBST.Size()<<"\t\tClsHT:"<<myClsHT.ReadArraySize()<<"\t\tOpnHT:"<<myOpnHT.ReadArraySize()<<endl;
    }

    if(myList.Size()!=myBST.Size() || myList.Size()!=myClsHT.Size() || myList.Size()!=myOpnHT.Size())
        result = false;
    
    lasd::List<int> ListToRemove;
    while(!myList.Empty()){
      for(int i=0; i<=(myList.Size()/2); i++)
        ListToRemove.Insert(myList[i]);
      resultOnList = myList.RemoveAll(ListToRemove);
      resultOnBST = myBST.RemoveAll(ListToRemove);
      resultOnClsHT = myClsHT.RemoveAll(ListToRemove);
      resultOnOpnHT = myOpnHT.RemoveAll(ListToRemove);
      if(resultOnList!=resultOnBST || resultOnList!=resultOnClsHT || resultOnList!=resultOnOpnHT)
        result = false;
      cout<<"\nSIZE:\t\t"<<"List:"<<myList.Size()<<"\t\tBST:"<<myBST.Size()<<"\t\tClsHT:"<<myClsHT.Size()<<"\t\tOpnHT:"<<myOpnHT.Size();
      cout<<"\nArraySize:\t"<<"List:"<<myList.Size()<<"\t\tBST:"<<myBST.Size()<<"\t\tClsHT:"<<myClsHT.ReadArraySize()<<"\t\tOpnHT:"<<myOpnHT.ReadArraySize()<<endl;
      ListToRemove.Clear();
    }

    if(!myList.Empty() || !myBST.Empty() || !myClsHT.Empty() || !myOpnHT.Empty())
      result = false;

    return result;
  }


/* ************************************************************************** */

bool myTest(){

/* ********************************* INIZIO ESERCIZIO 1 ***************************************** */

    bool test_result_qv = true;
    bool test_result_sv = true;
    bool test_result_sl = true;
    bool test_result_ql = true;
    bool test_copy_qv_from_vec = true;
    bool test_copy_qv_from_lst = true;
    bool test_copy_ql_from_lst = true;
    bool test_copy_ql_from_vec = true;
    bool test_copy_assignement_qv_from_vec = true;
    bool test_copy_assignement_qv_from_lst = true;
    bool test_copy_assignement_ql_from_lst = true;
    bool test_copy_assignement_ql_from_vec = true;
    bool test_move_qv_from_vec = true;
    bool test_move_qv_from_lst = true;
    bool test_move_ql_from_lst = true;
    bool test_move_ql_from_vec = true;
    bool test_move_assignement_qv_from_vec = true;
    bool test_move_assignement_qv_from_lst = true;
    bool test_move_assignement_ql_from_lst = true;
    bool test_move_assignement_ql_from_vec = true;
    bool test_copy_sv_from_vec = true;
    bool test_copy_sv_from_lst = true;
    bool test_copy_sl_from_lst = true;
    bool test_copy_sl_from_vec = true;
    bool test_copy_assignement_sv_from_vec = true;
    bool test_copy_assignement_sv_from_lst = true;
    bool test_copy_assignement_sl_from_lst = true;
    bool test_copy_assignement_sl_from_vec = true;
    bool test_move_sv_from_vec = true;
    bool test_move_sv_from_lst = true;
    bool test_move_sl_from_lst = true;
    bool test_move_sl_from_vec = true;
    bool test_move_assignement_sv_from_vec = true;
    bool test_move_assignement_sv_from_lst = true;
    bool test_move_assignement_sl_from_lst = true;
    bool test_move_assignement_sl_from_vec = true;

    bool test_equal_vec = true;
    bool test_equal_lst = true;
    bool test_equal_sv = true;
    bool test_equal_sl = true;
    bool test_equal_qv = true;
    bool test_equal_ql = true;

    bool test_insert_copy = true;
    bool test_insert_move = true;
    bool test_remove = true;
    bool test_insert_all_copy = true;
    bool test_insert_all_move = true;
    bool test_insert_some_copy = true;
    bool test_insert_some_move = true;
    bool test_remove_all = true;
    bool test_remove_some = true;

    bool test_sort_int = true;
    bool test_sort_char = true;
    bool test_sort_empty = true;
    
    for(int i=0; i<NUMERO_TEST_ITERATIVI; i++){
      lasd::Vector<int> v1(genSize(gen));
      for(ulong i=0; i<v1.Size(); i++)
        v1[i]=genNum(gen);
      lasd::QueueVec<int> qv1(v1);
      lasd::StackVec<int> sv1(v1);
      lasd::StackLst<int> sl1(v1);
      lasd::QueueLst<int> ql1(v1);
      test_result_qv &= TestQueueVec(qv1);
      test_result_sv &= TestStackVec(sv1);
      test_result_sl &= TestStackLst(sl1);
      test_result_ql &= TestQueueLst(ql1);
    }

    cout<<"\n\n*********** OUTPUTS DI DEBUG ESERCIZIO 1: ***********\n"<<endl;


    test_copy_qv_from_vec = TestCopyQueueVecFromVec();
    test_copy_qv_from_lst = TestCopyQueueVecFromLst();
    test_copy_ql_from_lst = TestCopyQueueLstFromLst();
    test_copy_ql_from_vec = TestCopyQueueLstFromVec();

    test_copy_assignement_qv_from_vec = TestCopyAssignementQueueVecFromVec();
    test_copy_assignement_qv_from_lst = TestCopyAssignementQueueVecFromLst();
    test_copy_assignement_ql_from_lst = TestCopyAssignementQueueLstFromLst();
    test_copy_assignement_ql_from_vec = TestCopyAssignementQueueLstFromVec();

    test_move_qv_from_vec = TestMoveQueueVecFromVec();
    test_move_qv_from_lst = TestMoveQueueVecFromLst();
    test_move_ql_from_lst = TestMoveQueueLstFromLst();
    test_move_ql_from_vec = TestMoveQueueLstFromVec();

    test_move_assignement_qv_from_vec = TestMoveAssignementQueueVecFromVec();
    test_move_assignement_qv_from_lst = TestMoveAssignementQueueVecFromLst();
    test_move_assignement_ql_from_lst = TestMoveAssignementQueueLstFromLst();
    test_move_assignement_ql_from_vec = TestMoveAssignementQueueLstFromVec();

    test_copy_sv_from_vec = TestCopyStackVecFromVec();
    test_copy_sv_from_lst = TestCopyStackVecFromLst();
    test_copy_sl_from_lst = TestCopyStackLstFromLst();
    test_copy_sl_from_vec = TestCopyStackLstFromVec();

    test_copy_assignement_sv_from_vec = TestCopyAssignementStackVecFromVec();
    test_copy_assignement_sv_from_lst = TestCopyAssignementStackVecFromLst();
    test_copy_assignement_sl_from_lst = TestCopyAssignementStackLstFromLst();
    test_copy_assignement_sl_from_vec = TestCopyAssignementStackLstFromVec();

    test_move_sv_from_vec = TestMoveStackVecFromVec();
    test_move_sv_from_lst = TestMoveStackVecFromLst();
    test_move_sl_from_lst = TestMoveStackLstFromLst();
    test_move_sl_from_vec = TestMoveStackLstFromVec();

    test_move_assignement_sv_from_vec = TestMoveAssignementStackVecFromVec();
    test_move_assignement_sv_from_lst = TestMoveAssignementStackVecFromLst();
    test_move_assignement_sl_from_lst = TestMoveAssignementStackLstFromLst();
    test_move_assignement_sl_from_vec = TestMoveAssignementStackLstFromVec();

    test_equal_vec = TestEqualVector();
    test_equal_lst = TestEqualList();
    test_equal_sv = TestEqualStackVec();
    test_equal_sl = TestEqualStackLst();
    test_equal_qv = TestEqualQueueVec();
    test_equal_ql = TestEqualQueueLst();
    
    test_insert_copy = TestInsertCopyInDictionary();
    test_insert_move = TestInsertMoveInDictionary();
    test_remove = TestRemoveInDictionary();
    test_insert_all_copy = TestInsertAllCopyInDictionary();
    test_insert_all_move = TestInsertAllMoveInDictionary();
    test_insert_some_copy = TestInsertSomeCopyInDictionary();
    test_insert_some_move = TestInsertSomeMoveInDictionary();
    test_remove = TestRemoveAllInDictionary();
    test_remove = TestRemoveSomeInDictionary();

    test_sort_int = TestSortInt();
    test_sort_char = TestSortChar();
    test_sort_empty = TestSortEmpty();

  

    bool test_exercise1 = (test_copy_qv_from_vec && test_copy_qv_from_lst &&
      test_copy_ql_from_lst && test_copy_ql_from_vec &&
      test_copy_assignement_qv_from_vec && test_copy_assignement_qv_from_lst &&
      test_copy_assignement_ql_from_lst && test_copy_assignement_ql_from_vec &&
      test_move_qv_from_vec && test_move_qv_from_lst && 
      test_move_ql_from_lst && test_move_ql_from_vec && 
      test_move_assignement_qv_from_vec && test_move_assignement_qv_from_lst && 
      test_move_assignement_ql_from_lst && test_move_assignement_ql_from_vec && 
      test_copy_sv_from_vec && test_copy_sv_from_lst && 
      test_copy_sl_from_lst && test_copy_sl_from_vec && 
      test_copy_assignement_sv_from_vec && test_copy_assignement_sv_from_lst && 
      test_copy_assignement_sl_from_lst && test_copy_assignement_sl_from_vec && 
      test_move_sv_from_vec && test_move_sv_from_lst && 
      test_move_sl_from_lst && test_move_sl_from_vec && 
      test_move_assignement_sv_from_vec && test_move_assignement_sv_from_lst && 
      test_move_assignement_sl_from_lst && test_move_assignement_sl_from_vec && 
      test_equal_vec && test_equal_lst && 
      test_equal_sv && test_equal_sl && 
      test_equal_qv && test_equal_ql && 
      test_insert_copy && test_insert_move && 
      test_remove && test_insert_all_copy && 
      test_insert_all_move && test_insert_some_copy &&
      test_insert_some_move && test_remove && 
      test_remove && test_result_qv && 
      test_result_sv && test_result_ql && 
      test_result_sl && test_sort_int && 
      test_sort_char && test_sort_empty
      );

/* ********************************* FINE ESERCIZIO 1 ***************************************** */



/* ********************************* INIZIO ESERCIZIO 2 ***************************************** */

    bool test_compare_BST_copy = true;
    bool test_compare_BST_move = true;
    bool test_compare_BT_and_BST_from_lst_copy = true;
    bool test_compare_BT_and_BST_from_lst_move = true;
    bool test_compare_BT_and_BST_from_vec_copy = true;
    bool test_compare_BT_and_BST_from_vec_move = true;
    bool test_compare_empty_BT_and_BST = true;

    bool test_iterator_on_BT = true;
    bool test_iterator_on_empty_BT = true;
    bool test_iterator_after_move = true;

    bool test_maps_and_fold_on_BTLnk = true;
    bool test_maps_and_fold_on_BTVec = true;

    bool test_find_min_in_BST = true;
    bool test_find_max_in_BST = true;
    bool test_predecessor_and_successor = true;
    bool test_dictionary_methods = true;

    bool test_BT_Vec = true;
    bool test_Vec_from_BTVec_And_Move = true;
    bool test_BT_Vec_methods = true;
    bool test_compare_BTVec_And_BTLnk = true;

    cout<<"\n\n*********** OUTPUTS DI DEBUG ESERCIZIO 2: ***********\n"<<endl;

    test_compare_BST_copy = TestCompareBSTCopy();
    test_compare_BST_move = TestCompareBSTMove();
    test_compare_BT_and_BST_from_lst_copy = TestCompareBTAndBSTFromLstCopy();
    test_compare_BT_and_BST_from_lst_move = TestCompareBTAndBSTFromLstMove();
    test_compare_BT_and_BST_from_vec_copy = TestCompareBTAndBSTFromVecCopy();
    test_compare_BT_and_BST_from_vec_move = TestCompareBTAndBSTFromVecMove();
    test_compare_empty_BT_and_BST = TestCompareEmptyBTAndBST();

    test_iterator_on_BT = TestIteratorOnBT();
    test_iterator_on_empty_BT = TestIteratorOnEmptyBT();
    test_iterator_after_move = TestIteratorAfterMove();

    test_maps_and_fold_on_BTLnk = TestMapsAndFoldOnBTLnk();
    test_maps_and_fold_on_BTVec = TestMapsAndFoldOnBTVec();

    test_find_min_in_BST = TestFindMinInBST();
    test_find_max_in_BST = TestFindMaxInBST();
    test_predecessor_and_successor = TestPredecessorAndSuccessor();
    test_dictionary_methods = TestDictionaryMethods();

    test_BT_Vec = TestBTVec();
    test_Vec_from_BTVec_And_Move = TestVecFromBTVecAndMove();
    test_BT_Vec_methods = TestBTVecMethods();
    test_compare_BTVec_And_BTLnk = TestCompareBTVecAndBTLnk();



    bool test_exercise2 = (test_compare_BST_copy && test_compare_BST_move && 
      test_compare_BT_and_BST_from_lst_copy && test_compare_BT_and_BST_from_lst_move && 
      test_compare_BT_and_BST_from_vec_copy && test_compare_BT_and_BST_from_vec_move && 
      test_compare_empty_BT_and_BST && test_iterator_on_empty_BT && test_iterator_on_BT && 
      test_iterator_after_move && test_maps_and_fold_on_BTLnk && test_maps_and_fold_on_BTVec && 
      test_find_min_in_BST && test_find_max_in_BST && test_predecessor_and_successor && 
      test_dictionary_methods && test_BT_Vec && test_Vec_from_BTVec_And_Move && 
      test_BT_Vec_methods && test_compare_BTVec_And_BTLnk
      );

/* ********************************* FINE ESERCIZIO 2 ***************************************** */




/* ********************************* INIZIO ESERCIZIO 3 ***************************************** */

    bool test_ht_constructors = true;
    bool test_ht_assignements = true;

    bool test_compare_ClsAdr = true;
    bool test_compare_OpnAdr = true;
    bool test_compare_different_HT = true;

    bool test_resize_with_more_elements = true;
    bool test_resize_to_default = true;
    bool test_resize_when_loaded_ClsAdr = true;
    bool test_resize_when_loaded_Dictionary = true;
    bool test_resize_after_many_deleted_elements = true;
    
    bool test_no_loop_on_deleted = true;
    bool test_quadratic_probing = true;
    bool test_quadratic_probing_after_resize = true;
    bool test_swap_deleted_element = true;
    bool test_all_dictionary_functions = true;
    bool test_iterative_dictionary_and_autoresize = true;

    cout<<"\n\n*********** OUTPUTS DI DEBUG ESERCIZIO 3: ***********\n"<<endl;

    test_ht_constructors = TestHtConstructors();
    test_ht_assignements = TestHtAssignements();

    test_compare_ClsAdr = TestCompareClsAdr();
    test_compare_OpnAdr = TestCompareOpnAdr();
    test_compare_different_HT = TestCompareDifferentHT();

    test_resize_with_more_elements = TestResizeWithMoreElements();
    test_resize_to_default = TestResizeToDefault();
    test_resize_when_loaded_ClsAdr = TestResizeWhenLoadedClsAdr();
    test_resize_when_loaded_Dictionary = TestResizeWhenLoadedDictionary();
    test_resize_after_many_deleted_elements = TestResizeAfterManyDeletedElements();
    
    test_no_loop_on_deleted = TestNoLoopOnDeleted();
    test_quadratic_probing = TestQuadraticProbing();
    test_quadratic_probing_after_resize = TestQuadraticProbingAfterResize();
    test_swap_deleted_element = TestSwapDeletedElements();
    test_all_dictionary_functions = TestAllDictionaryFunctions();
    test_iterative_dictionary_and_autoresize = TestIterativeDictionaryAndAutoresize();




    bool test_exercise3 = (test_ht_constructors && test_ht_assignements &&
      test_compare_ClsAdr && test_compare_OpnAdr && test_compare_different_HT &&
      test_resize_with_more_elements && test_resize_to_default &&
      test_resize_when_loaded_ClsAdr && test_resize_when_loaded_Dictionary &&
      test_resize_after_many_deleted_elements && test_no_loop_on_deleted &&
      test_quadratic_probing && test_quadratic_probing_after_resize &&
      test_swap_deleted_element && test_all_dictionary_functions &&
      test_iterative_dictionary_and_autoresize
      );


/* ********************************* FINE ESERCIZIO 3 ***************************************** */
  


    /* ******************** OUTPUTS ******************** */
    cout<<"\n\n*********** RISULTATI DEI TEST SULL'ESERCIZIO 1: ***********"<<endl<<endl;

    cout<<"> COPY CONSTRUCTORS:"<<endl;
    cout<<"Creazione, modifica e confronto di QueueVec da Vector e da un'altra QueueVec: "<<((test_copy_qv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueVec da List e da un'altra QueueVec: "<<((test_copy_qv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueLst da List e da un'altra QueueLst: "<<((test_copy_ql_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueLst da Vector e da un'altra QueueLst: "<<((test_copy_ql_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackVec da Vector e da un'altra StackVec: "<<((test_copy_sv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackVec da List e da un'altra StackVec: "<<((test_copy_sv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackLst da List e da un'altra StackLst: "<<((test_copy_sl_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackLst da Vector e da un'altra StackLst: "<<((test_copy_sl_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;
    cout<<"> COPY ASSIGNEMENTS:"<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueVec creata da Vector ad un'altra QueueVec: "<<((test_copy_assignement_qv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueVec creata da List ad un'altra QueueVec: "<<((test_copy_assignement_qv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueLst creata da List ad un'altra QueueLst: "<<((test_copy_assignement_ql_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueLst creata da Vector ad un'altra QueueLst: "<<((test_copy_assignement_ql_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackVec creata da Vector ad un'altra StackVec: "<<((test_copy_assignement_sv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackVec creata da List ad un'altra StackVec: "<<((test_copy_assignement_sv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackLst creata da List ad un'altra StackLst: "<<((test_copy_assignement_sl_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackLst creata da Vector ad un'altra StackLst: "<<((test_copy_assignement_sl_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;
    cout<<"> MOVE CONSTRUCTORS:"<<endl;
    cout<<"Creazione, modifica e confronto di QueueVec da Vector e da un'altra QueueVec: "<<((test_move_qv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueVec da List e da un'altra QueueVec: "<<((test_move_qv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueLst da List e da un'altra QueueLst: "<<((test_move_ql_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di QueueLst da Vector e da un'altra QueueLst: "<<((test_move_ql_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackVec da Vector e da un'altra StackVec: "<<((test_move_sv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackVec da List e da un'altra StackVec: "<<((test_move_sv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackLst da List e da un'altra StackLst: "<<((test_move_sl_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di StackLst da Vector e da un'altra StackLst: "<<((test_move_sl_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;
    cout<<"> MOVE ASSIGNEMENTS:"<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueVec creata da Vector ad un'altra QueueVec: "<<((test_move_assignement_qv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueVec creata da List ad un'altra QueueVec: "<<((test_move_assignement_qv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueLst creata da List ad un'altra QueueLst: "<<((test_move_assignement_ql_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di QueueLst creata da Vector ad un'altra QueueLst: "<<((test_move_assignement_ql_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackVec creata da Vector ad StackVec: "<<((test_move_assignement_sv_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackVec creata da List ad un'altra StackVec: "<<((test_move_assignement_sv_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackLst creata da List ad un'altra StackLst: "<<((test_move_assignement_sl_from_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Assegnazione, modifica e confronto di StackLst creata da Vector ad un'altra StackLst: "<<((test_move_assignement_sl_from_vec) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;

    cout<<"> COMPARSION:"<<endl;
    cout<<"Confronto tra due Vector: "<<((test_equal_vec) ? "Corretto" : "Errore")<<endl;
    cout<<"Confronto tra due List: "<<((test_equal_lst) ? "Corretto" : "Errore")<<endl;
    cout<<"Confronto tra due StackVec: "<<((test_equal_sv) ? "Corretto" : "Errore")<<endl;
    cout<<"Confronto tra due StackLst: "<<((test_equal_sl) ? "Corretto" : "Errore")<<endl;
    cout<<"Confronto tra due QueueVec: "<<((test_equal_qv) ? "Corretto" : "Errore")<<endl;
    cout<<"Confronto tra due QueueLst: "<<((test_equal_ql) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;

    cout<<"> DICTIONARY:"<<endl;
    cout<<"Inserimento di un elemento in un dizionario (copy): "<<((test_insert_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Inserimento di un elemento in un dizionario (move): "<<((test_insert_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Rimozione di un elemento in un dizionario: "<<((test_remove) ? "Corretto" : "Errore")<<endl;
    cout<<"Inserimento di tutti gli elementi in un dizionario (copy): "<<((test_insert_all_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Inserimento di tutti gli elementi in un dizionario (move): "<<((test_insert_all_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Inserimento di alcuni elementi in un dizionario (copy): "<<((test_insert_some_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Inserimento di alcuni elementi in un dizionario (move): "<<((test_insert_some_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Rimozione di tutti gli elementi in un dizionario: "<<((test_remove_all) ? "Corretto" : "Errore")<<endl;
    cout<<"Rimozione di alcuni elementi in un dizionario: "<<((test_remove_some) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;

    cout<<"> SORT:"<<endl;
    cout<<"Sort di un vettore di interi: "<<((test_sort_int) ? "Corretto" : "Errore")<<endl;
    cout<<"Sort di un vettore di char: "<<((test_sort_char) ? "Corretto" : "Errore")<<endl;
    cout<<"Sort di un vettore vuoto: "<<((test_sort_empty) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl;

    cout<<"> FILLING AND EMPTYING:"<<endl;
    cout<<"Risultato "<<NUMERO_TEST_QV<<" test di confronto, riempimento e svuotamento su QueueVec "<<((test_result_qv) ? "Corretto" : "Errore")<<endl;
    cout<<"Risultato "<<NUMERO_TEST_SV<<" test di confronto, riempimento e svuotamento su StackVec: "<<((test_result_sv) ? "Corretto" : "Errore")<<endl;
    cout<<"Risultato "<<NUMERO_TEST_QL<<" test di confronto, riempimento e svuotamento su QueueLst: "<<((test_result_ql) ? "Corretto" : "Errore")<<endl;
    cout<<"Risultato "<<NUMERO_TEST_SL<<" test di confronto, riempimento e svuotamento su StackLst: "<<((test_result_sl) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl<<endl;




    cout<<"\n\n*********** RISULTATI DEI TEST SULL'ESERCIZIO 2: ***********"<<endl<<endl;
    
    cout<<"> BT AND BST COMPARSION:"<<endl;
    cout<<"Creazione, modifica e confronto di BST da copy: "<<((test_compare_BST_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di BST da move: "<<((test_compare_BST_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di BT e BST da copy di una lista: "<<((test_compare_BT_and_BST_from_lst_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di BT e BST da move di una lista: "<<((test_compare_BT_and_BST_from_lst_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di BT e BST da copy di un vettore: "<<((test_compare_BT_and_BST_from_vec_copy) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione, modifica e confronto di BT e BST da move di un vettore: "<<((test_compare_BT_and_BST_from_vec_move) ? "Corretto" : "Errore")<<endl;
    cout<<"Creazione e confronto di BT e BST vuoti: "<<((test_compare_empty_BT_and_BST) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test del corretto funzionamento dell'istanziazione di BT e BST vuoti;"<<endl;
    cout<<endl;
    cout<<"> ITERATORS:"<<endl;
    cout<<"Creazione, copia, assegnazione e confronto di Iteratori su BT: "<<((test_iterator_on_BT) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Istanziazione dei 4 tipi di iteratori su diversi BT sia per copia che con move;"<<endl;
        cout<<"\t- Test del corretto funzionamento degli operatori di accesso e di incremento;"<<endl;
        cout<<"\t- Test del corretto funzionamento delle eccezioni;"<<endl;
    cout<<"Creazione, copia, assegnazione e confronto di Iteratori su BT vuoti: "<<((test_iterator_on_empty_BT) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Istanziazione dei 4 tipi di iteratori su diversi BT vuoti sia per copia che con move;"<<endl;
        cout<<"\t- Test del corretto funzionamento degli operatori di accesso e di incremento;"<<endl;
        cout<<"\t- Test del corretto funzionamento delle eccezioni;"<<endl;
    cout<<"Creazione ed utilizzo di Iteratori in seguito a funzioni di move: "<<((test_iterator_after_move) ? "Corretto" : "Errore")<<endl;
    cout<<endl;
    cout<<"> MAPS AND FOLD:"<<endl;
    cout<<"Test di funzioni di Map e di Fold su BTLnk: "<<((test_maps_and_fold_on_BTLnk) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test statici per il corretto funzionamento delle Map (tutti gli ordini) su BTLnk;"<<endl;
        cout<<"\t- Test statici per il corretto funzionamento delle Fold (tutti gli ordini) su BTLnk;"<<endl;
    cout<<"Test di funzioni di Map e di Fold su BTVec: "<<((test_maps_and_fold_on_BTVec) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test statici per il corretto funzionamento delle Map (tutti gli ordini) su BTVec;"<<endl;
        cout<<"\t- Test statici per il corretto funzionamento delle Fold (tutti gli ordini) su BTVec;"<<endl;
    cout<<endl;
    cout<<"> RESEARCH ON BST:"<<endl;
    cout<<"Ricerca randomica del min su un BST: "<<((test_find_min_in_BST) ? "Corretto" : "Errore")<<endl;
    cout<<"Ricerca randomica del max su un BST: "<<((test_find_max_in_BST) ? "Corretto" : "Errore")<<endl;
    cout<<"Operazioni su predecessore e successore in un BST: "<<((test_predecessor_and_successor) ? "Corretto" : "Errore")<<endl;
    cout<<"Operazioni di dizionario in un BST: "<<((test_dictionary_methods) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test di tutte le operazioni di Dictionary su un BST e confronto coi risultati di List;"<<endl;
        cout<<"\t- Test di Insert, InsertSome, InsertAll, Remove, RemoveSome, RemoveAll, Exists, Empty;"<<endl;
    cout<<endl;
    cout<<"> BT VECTOR:"<<endl;
    cout<<"Creazione, modifica e confronti di BTVec: "<<((test_BT_Vec) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Creazione di BTVec da diversi MappableContainers (Vector, List...) e da altri BT;"<<endl;
    cout<<"Creazione di Vec da BTVec e funzionamento delle move: "<<((test_Vec_from_BTVec_And_Move) ? "Corretto" : "Errore")<<endl;
    cout<<"Operazioni eseguibili su BTVec: "<<((test_BT_Vec_methods) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test sul corretto funzionamento di Root, HasLeftChild, LeftChild, HasRightChild, RightChild;"<<endl;
    cout<<"Confronti tra BTVec e BTLnk: "<<((test_compare_BTVec_And_BTLnk) ? "Corretto" : "Errore")<<endl;
    cout<<endl<<endl<<endl;




    cout<<"\n\n*********** RISULTATI DEI TEST SULL'ESERCIZIO 3: ***********"<<endl<<endl;

    cout<<"> CONSTRUCTORS AND ASSIGNEMENTS:"<<endl;
    cout<<"Creazioni e modifiche tramite costruttori per copy e move: "<<((test_ht_constructors) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Costruzioni da diversi tipi di MutableMappableContainer (Vector, List...) e da altre HT;"<<endl;
        cout<<"\t- Operazioni varie di modifica e test su confronti e correttezza a seguito di svuotamenti;"<<endl;
    cout<<endl;
    cout<<"Creazioni e modifiche tramite assegnamento per copy e move: "<<((test_ht_assignements) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Assegnazioni da diversi tipi di MutableMappableContainer (Vector, List...) e da altre HT;"<<endl;
        cout<<"\t- Operazioni varie di modifica e test su confronti e correttezza a seguito di svuotamenti;"<<endl;
    cout<<endl<<endl;
    
    cout<<"> COMPARSION:"<<endl;
    cout<<"Confronti vari tra HashTableClsAdr con copy e move: "<<((test_compare_ClsAdr) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Confronti di vario genere tra HashTableClsAdr costruite in diversi modi (copy/move constructor, assegnamento);"<<endl;
        cout<<"\t- Confronti a seguito di inserimenti, rimozioni, svuotamenti e resize;"<<endl;
    cout<<endl;
    cout<<"Confronti vari tra HashTableOpnAdr con copy e move: "<<((test_compare_OpnAdr) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Confronti di vario genere tra HashTableOpnAdr costruite in diversi modi (copy/move constructor, assegnamento);"<<endl;
        cout<<"\t- Confronti a seguito di inserimenti, rimozioni, svuotamenti e resize;"<<endl;
    cout<<endl;
    cout<<"Confronti vari tra diverse HashTable con copy e move: "<<((test_compare_different_HT) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Confronti di vario genere tra HTOpnAdr e HTClsAdr costruite in diversi modi (copy/move constructor, assegnamento);"<<endl;
        cout<<"\t- Confronti a seguito di inserimenti, rimozioni, svuotamenti e resize;"<<endl;
    cout<<endl<<endl;

    cout<<"> RESIZING:"<<endl;
    cout<<"Resize di una HashTable contenente più elementi del valore richiesto nella resize: "<<((test_resize_with_more_elements) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Verifica che non ci sia perdita di elementi in HTClsAdr e HTOpnAdr e controlli sulla corretta gestione delle espansioni;"<<endl;
    cout<<endl;
    cout<<"Resize di una HashTable passando il valore 0: "<<((test_resize_to_default) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Verifica che la Resize(0) su HTClsAdr e HTOpnAdr corrisponda ad una Clear ed una Resize a valore di default;"<<endl;
    cout<<endl;
    cout<<"Resize di una HashTable ClsAdr al riempimento eccessivo della struttura: "<<((test_resize_when_loaded_ClsAdr) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Verifica che la HTClsAdr venga resizata al raggiungimento di un certo riempimento e che i dizionari vengano alleggeriti;"<<endl;
    cout<<endl;
    cout<<"Resize di una HashTable ClsAdr al caricamento eccessivo di uno dei dizionari: "<<((test_resize_when_loaded_Dictionary) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Verifica che la HTClsAdr venga resizata al sovraccaricamento di un dizionario e che questi vengano alleggeriti;"<<endl;
    cout<<endl;
    cout<<"Resize di una HashTable OpnAdr a seguito di troppi salti per via del probing: "<<((test_resize_after_many_deleted_elements) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Verifica che la HTOpnAdr venga pulita dalle celle deleted al raggiungimento di una certa soglia di 'buchi';"<<endl;
    cout<<endl<<endl;
    
    cout<<"> PROPER FUNCTIONING:"<<endl;
    cout<<"Corretta esecuzione dell'intero test utilizzando BST come dizionario di ClsAdr anziché List: "<<((true) ? "Corretto" : "Errore")<<endl;
    cout<<endl;
    cout<<"Non si crea loop per array OpnAdr con tutte celle deleted: "<<((test_no_loop_on_deleted) ? "Corretto" : "Errore")<<endl;
    cout<<endl;
    cout<<"Corretta gestione delle collisioni con il QuadraticProbing: "<<((test_quadratic_probing) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Creazione e riempimento statico (per controllare gli output) di HashTable sia ClsAdr che OpnAdr;"<<endl;
        cout<<"\t- Visualizzazione output per la corretta gestione del Probing Quadratico;"<<endl;
    cout<<endl;
    cout<<"Creazione array OpnAdr a seguito di una Resize e funzionamento dopo le Remove: "<<((test_quadratic_probing_after_resize) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Creazione e riempimento statico (per controllare gli output) di HashTable sia ClsAdr che OpnAdr;"<<endl;
        cout<<"\t- Visualizzazione output per il corretto funzionamento del Probing Quadratico a seguito della resize;"<<endl;
    cout<<endl;
    cout<<"Swap di un elemento inserito se era presente una cella deleted sul percorso: "<<((test_swap_deleted_element) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test statico che verifica la correttezza dello swap per ottimizzare ricerca e cancellamento;"<<endl;
        cout<<"\t- Verifica che nel caso di salti dovuti a celle precedentemente cancellate, il valore trovato venga riportato alla prima di queste;"<<endl;
    cout<<endl;
    cout<<"Testing di tutte le funzioni di Dicionary: "<<((test_all_dictionary_functions) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test delle funzioni di dizionario su HashTable ClsAdr e OpnAdr create in diversi modi (copy/move constructor, assegnamento);"<<endl;
        cout<<"\t- Corretto funzionamento di Insert, InsertSome, InsertAll, Remove, RemoveSome, RemoveAll, Exists, Empty;"<<endl;
        cout<<"\t- Confronto dei risultati con quelli ottenuti su List e BST;"<<endl;
    cout<<endl;
    cout<<"Test iterativi delle funzioni di Dicionary e funzionamento resize automatiche: "<<((test_iterative_dictionary_and_autoresize) ? "Corretto" : "Errore")<<endl;
        cout<<"\t- Test iterativi delle funzioni di dizionario su HashTable ClsAdr e OpnAdr create in diversi modi (copy/move constructor, assegnamento);"<<endl;
        cout<<"\t- Corretto funzionamento di riempimenti e svuotamenti con controlli sulle dimensioni e sul corretto funzionamento della Resize;"<<endl;
        cout<<"\t- Confronto dei risultati con quelli ottenuti su List e BST;"<<endl;
    cout<<endl<<endl<<endl;




/* ********************************* OUTPUTS FINALI ***************************************** */

    bool total_test = (test_exercise1 && test_exercise2 && test_exercise3);

    cout<<"RISULTATO TEST:"<<endl;
    cout<<"Esercizio 1: "<<((test_exercise1) ? "Superato" : "Contiene errori")<<endl;
    cout<<"Esercizio 2: "<<((test_exercise2) ? "Superato" : "Contiene errori")<<endl;
    cout<<"Esercizio 3: "<<((test_exercise3) ? "Superato" : "Contiene errori")<<endl;
    cout<<endl;
    cout<<((total_test) ? "Non sono stati trovati errori." : "ATTENZIONE: sono presenti alcuni errori!")<<endl;
    cout<<endl;

            

    return true;
}

#endif