
#ifndef STACKVEC_HPP
#define STACKVEC_HPP

#define stack_starting_size 5

/* ************************************************************************** */

#include "../stack.hpp"
#include "../../vector/vector.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class StackVec : virtual public Stack<Data>,
                 virtual protected Vector<Data> {

private:


protected:

  using Vector<Data>::Elements;
  ulong filling = 0;
  using Container::size;

public:

  // Default constructor
  StackVec() : Vector<Data>(stack_starting_size) {};
    
  /* ************************************************************************ */

  // Specific constructor
  StackVec(const MappableContainer<Data>& cont); // A stack obtained from a MappableContainer
  StackVec(MutableMappableContainer<Data>&& cont) noexcept; // A stack obtained from a MutableMappableContainer

  /* ************************************************************************ */

  // Copy constructor
  StackVec(const StackVec& other);

  // Move constructor
  StackVec(StackVec&& other) noexcept;
  
  /* ************************************************************************ */

  // Destructor
  ~StackVec() = default;

  /* ************************************************************************ */

  // Copy assignment
  StackVec<Data>& operator=(const StackVec& other);

  // Move assignment
  StackVec<Data>& operator=(StackVec&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const StackVec& other) const noexcept;
  inline bool operator!=(const StackVec& other) const noexcept { return !operator==(other); }
  /* ************************************************************************ */

  // Specific member functions (inherited from Stack)
  const Data& Top() const override; // Override Stack member (non-mutable version; must throw std::length_error when empty)
  Data& Top() override; // Override Stack member (non-mutable version; must throw std::length_error when empty)
  void Pop() override; // Override Stack member (must throw std::length_error when empty)
  Data TopNPop() override; // Override Stack member (must throw std::length_error when empty)
  void Push(const Data& elem) override; // Override Stack member (copy of the value)
  void Push(Data&& elem) override; // Override Stack member (move of the value)

  /* ************************************************************************ */

  // Specific member functions (inherited from Container) - (Si riferiscono al filling e non alla dimensione della struttura)
  inline bool Empty() const noexcept override { return filling==0; } // Override Container member
  inline ulong Size() const noexcept override { return filling; } // Override Container member

  /* ************************************************************************ */

  // Specific member function (inherited from ClearableContainer)
  void Clear(); // Override ClearableContainer member

protected:

  // Auxiliary member functions
  void CheckNExpand();
  void CheckNReduce();

};


/* ************************************************************************** */

}

#include "stackvec.cpp"

#endif
