
namespace lasd {

/* ************************************************************************** */

template <typename Data>
StackVec<Data>::StackVec(const MappableContainer<Data>& cont) : Vector<Data>::Vector(cont) {
    filling = cont.Size();
    CheckNExpand();
}

template <typename Data>
StackVec<Data>::StackVec(MutableMappableContainer<Data>&& cont) noexcept : Vector<Data>::Vector(std::move(cont)) {
    filling = cont.Size();
    CheckNExpand();
}

/* ************************************************************************** */

template <typename Data>
StackVec<Data>::StackVec(const StackVec<Data>& other) {
    size = (other.Size());
    filling=other.filling;
    Elements = new Data[filling];
    std::copy(other.Elements, other.Elements+filling, Elements);
}

template <typename Data>
StackVec<Data>::StackVec(StackVec<Data>&& other) noexcept : Vector<Data>(std::move(other)) {
    std::swap(other.filling, filling);
    other.Clear();
}

/* ************************************************************************** */

template <typename Data>
StackVec<Data>& StackVec<Data>::operator=(const StackVec& other) {
    Vector<Data>::operator=(other);
    filling=other.filling;
    CheckNExpand();
    return *this;
}

template <typename Data>
StackVec<Data>& StackVec<Data>::operator=(StackVec&& other) noexcept {
    std::swap(size, other.size);
    std::swap(Elements, other.Elements);
    std::swap(filling, other.filling);
    CheckNExpand();
    return *this;
}

/* ************************************************************************** */

template <typename Data>
bool StackVec<Data>::operator==(const StackVec& other) const noexcept {
    bool result=true;
    if(filling!=other.filling)
        return false;
    for(ulong i=0; i<filling; i++) {
        if(Elements[i]!=other[i])
            return false;
    }
    return true;
}

/* ************************************************************************** */

template <typename Data>
const Data& StackVec<Data>::Top() const {
    if(Empty())
        throw std::length_error("StackVec: the stack is empty in Top()");
    return Elements[filling-1];
}

template <typename Data>
Data& StackVec<Data>::Top() {
    if(Empty())
        throw std::length_error("StackVec: the stack is empty in Top()");
    return Elements[filling-1];
}

template <typename Data>
void StackVec<Data>::Pop() {
    if(Empty())
        throw std::length_error("StackVec: the stack is empty in Pop()");
    CheckNReduce();
    filling--;
}

template <typename Data>
Data StackVec<Data>::TopNPop() {
    if(Empty())
        throw std::length_error("StackVec: the stack is empty in TopNPop()");
    CheckNReduce();
    return Elements[--filling];
}

template <typename Data>
void StackVec<Data>::Push(const Data& elem) {
    CheckNExpand();
    Elements[filling++] = elem;
}

template <typename Data>
void StackVec<Data>::Push(Data&& elem) {
    CheckNExpand();
    std::swap(Elements[filling++] , elem);
}

/* ************************************************************************** */

template <typename Data>
void StackVec<Data>::Clear() {
    delete[] Elements;
    Elements = new Data[stack_starting_size];
    size = stack_starting_size;
    filling = 0;
}

/* ************************************************************************** */

template <typename Data>
void StackVec<Data>::CheckNExpand() {
    if (filling==size)
        Vector<Data>::Resize((ulong)size*2);
}

template <typename Data>
void StackVec<Data>::CheckNReduce() {
    if(filling<=3)
        Vector<Data>::Resize(stack_starting_size);
    else if (filling<=((ulong)size*0.3))
        Vector<Data>::Resize((ulong)size*0.5);
}


}

