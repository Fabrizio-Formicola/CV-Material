#include "hashtable.hpp"

namespace lasd {

/* ************************************************************************** */

template <>
class Hashable<int>{
    public:
        ulong operator()(const int val) const noexcept {        
            return (val+1)*val;
            //return val;   //Return widely used for testing
        }
};

template <>
class Hashable<std::string>{
    public:
        ulong operator()(const std::string val) const noexcept {
            unsigned int hashValue = 0;
            for(int i=0; i<val.size(); i++)
                hashValue += (i*val[i]);
            return hashValue;
        }
};

template <>
class Hashable<double>{
    public:
        ulong operator()(const double val) const noexcept {
            ulong int_part = floor(val);
            return (int_part*int_part + ((val-int_part)*(val-int_part))) - int_part;
            //return val+1; //Return widely used for testing
        }
};

/* ************************************************************************** */

template <typename Data>
HashTable<Data>::HashTable(const HashTable<Data>& other) {
    size = other.size;
    arraySize = other.arraySize;
    A = other.A;
    B = other.B;
}

template <typename Data>
HashTable<Data>::HashTable(HashTable<Data>&& other) noexcept {
    std::swap(size, other.size);
    std::swap(arraySize, other.arraySize);
    std::swap(A, other.A);
    std::swap(B, other.B);
}


template <typename Data>
HashTable<Data>& HashTable<Data>::operator=(const HashTable<Data>& other) {
    size = other.size;
    arraySize = other.arraySize;
    A = other.A;
    B = other.B;
    return *this;
}

template <typename Data>
HashTable<Data>& HashTable<Data>::operator=(HashTable<Data>&& other) noexcept {
    std::swap(size, other.size);
    std::swap(arraySize, other.arraySize);
    std::swap(A, other.A);
    std::swap(B, other.B);
    return *this;
}


template <typename Data>
bool HashTable<Data>::operator==(const HashTable<Data> &other) const noexcept {
    if(size!=other.size)
        return false;
    bool equal = true;
    this->Map(
        [&equal, &other](const Data& dat){
            equal &= other.Exists(dat);
        }
    );
    return equal;
}

/* ************************************************************************** */

template <typename Data>
ulong HashTable<Data>::NextPowOf2(ulong new_size) {
    if(new_size<16)
        return 16;
    return std::pow(2, ceil(log2(new_size)));
}

}
