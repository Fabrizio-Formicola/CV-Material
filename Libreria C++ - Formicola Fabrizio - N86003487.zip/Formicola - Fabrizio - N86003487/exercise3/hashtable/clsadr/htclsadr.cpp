#include "htclsadr.hpp"

namespace lasd {

/* ************************************************************************** */

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(const ulong new_size) {
    arraySize = NextPowOf2(new_size);
    array = new List<Data>[arraySize] {};
}

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(const MappableContainer<Data>& other) : HashTableClsAdr(other.Size()){
    InsertAll(other);
}

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(const ulong new_size, const MappableContainer<Data>& other) : HashTableClsAdr(new_size) {
    InsertAll(other);
}

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(MutableMappableContainer<Data>&& other) noexcept : HashTableClsAdr(other.Size()){
    InsertAll(std::move(other));
}

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(const ulong new_size, MutableMappableContainer<Data>&& other) noexcept : HashTableClsAdr(new_size) {
    InsertAll(std::move(other));
}


template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(const HashTableClsAdr<Data>& other) : HashTable<Data>(other){
    array = new List<Data>[arraySize] {};
    std::copy(other.array, other.array + arraySize, array);
}

template <typename Data>
HashTableClsAdr<Data>::HashTableClsAdr(HashTableClsAdr<Data>&& other) noexcept : HashTable<Data>(std::move(other)) {
    std::swap(array, other.array);
}


template <typename Data>
HashTableClsAdr<Data> &HashTableClsAdr<Data>::operator=(const HashTableClsAdr& other){
    HashTable<Data>::operator=(other);
    delete[] array;
    array = new List<Data>[arraySize] {};
    for (ulong i = 0; i < arraySize; i++)
        array[i] = other.array[i];
    return *this;
}

template <typename Data>
HashTableClsAdr<Data>& HashTableClsAdr<Data>::operator=(HashTableClsAdr&& other) noexcept {
    HashTable<Data>::operator=(std::move(other));
    std::swap(array, other.array);
    return *this;
}


template <typename Data>
bool HashTableClsAdr<Data>::operator==(const HashTableClsAdr& other) const noexcept {
    if(other.size!=this->size)
        return false;
    bool result=true;
    for(ulong i=0; i<this->arraySize; i++){
        array[i].Map(
            [&other, &result](const Data& dat){
                result&=other.Exists(dat);
            }
        );
        if(result==false)
            return false;
    }
    return true;
}


template <typename Data>
bool HashTableClsAdr<Data>::Insert(const Data& val){
    ulong index = this->HashKey(Hashable<Data>()(val));
    if(array[index].Insert(val)){
        size++;
        if(((float)size/arraySize)>0.8 || array[index].Size()>(floor(sqrt(arraySize))))
            Resize(arraySize*2);    //loses advantages if goes above a load factor of 0.75 OR too loaded dictionary
        return true;
    }
    return false;
}

template <typename Data>
bool HashTableClsAdr<Data>::Insert(Data&& val) noexcept {
    ulong index = this->HashKey(Hashable<Data>()(val));
    if(array[index].Insert(std::move(val))){
        size++;
        if(((float)size/arraySize)>0.8 || array[index].Size()>(floor(sqrt(arraySize))))
            Resize(arraySize*2);    //loses advantages if goes above a load factor of 0.75 OR too loaded dictionary
        return true;
    }
    return false;
}

template <typename Data>
bool HashTableClsAdr<Data>::Remove(const Data& val){
    ulong index = this->HashKey(Hashable<Data>()(val));
    if(array[index].List<Data>::Remove(val)){
        size--;
        if(size<(arraySize/5) && arraySize!=16)
            Resize(arraySize/2);
        return true;
    }
    return false;
}


template <typename Data>
bool HashTableClsAdr<Data>::Exists(const Data &val) const noexcept {
    ulong index = this->HashKey(Hashable<Data>()(val));
    if(array[index].Exists(val))
        return true;
    return false;
}


template <typename Data>
void HashTableClsAdr<Data>::Resize(const ulong new_size){
    if(new_size == 0){
        Clear();
        Resize(16);
        return;
    }
    ulong temp_size = NextPowOf2(new_size);
    this->size = 0;
    List<Data>* temp_vec = new List<Data>[temp_size] {};
    std::swap(temp_vec, array);
    std::swap(temp_size, arraySize);
    for(ulong i=0; i<temp_size; i++)
        InsertAll(temp_vec[i]);
    delete [] temp_vec;
}


template <typename Data>
void HashTableClsAdr<Data>::Clear(){
    delete [] array;
    array = new List<Data>[arraySize];
    size=0;
}

/* ************************************************************************** */

template <typename Data>
void HashTableClsAdr<Data>::Map(MapFunctor func) const {
    for(int i=0; i<arraySize; i++){
        static_cast<const lasd::List<Data>&>(array[i]).Map(func);
    }
}

}
