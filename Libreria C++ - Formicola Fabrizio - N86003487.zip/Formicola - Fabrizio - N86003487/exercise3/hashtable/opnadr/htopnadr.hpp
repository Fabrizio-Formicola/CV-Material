
#ifndef HTOPNADR_HPP
#define HTOPNADR_HPP

/* ************************************************************************** */

#include "../hashtable.hpp"
#include <random>
#include <bitset>

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class HashTableOpnAdr : virtual public HashTable<Data> {

private:

protected:

  using DictionaryContainer<Data>::size;

  using HashTable<Data>::arraySize;
  using HashTable<Data>::NextPowOf2;
  using HashTable<Data>::HashKey;

  Data* Elements = nullptr;
  std::bitset<2>* flagsArray = nullptr; //Array of 2 bits: 00=Empty; 01=Impossible; 10=Deleted; 11=Accessible
  ulong deleted_elements = 0; 

  using typename MappableContainer<Data>::MapFunctor;
  void Map(MapFunctor func) const;

public:

  using DictionaryContainer<Data>::InsertAll;
  using DictionaryContainer<Data>::InsertSome;
  using DictionaryContainer<Data>::RemoveAll;
  using DictionaryContainer<Data>::RemoveSome;

  // Default constructor
  inline HashTableOpnAdr() {
    Elements = new Data[arraySize] {};
    flagsArray = new std::bitset<2>[arraySize] {};
  };

  /* ************************************************************************ */

  // Specific constructors
  HashTableOpnAdr(const ulong size); // A hash table of a given size
  HashTableOpnAdr(const MappableContainer<Data>& other); // A hash table obtained from a MappableContainer
  HashTableOpnAdr(const ulong size, const MappableContainer<Data>& other); // A hash table of a given size obtained from a MappableContainer
  HashTableOpnAdr(MutableMappableContainer<Data>&& other) noexcept; // A hash table obtained from a MutableMappableContainer
  HashTableOpnAdr(const ulong size, MutableMappableContainer<Data>&& other) noexcept; // A hash table of a given size obtained from a MutableMappableContainer

  /* ************************************************************************ */

  // Copy constructor
  HashTableOpnAdr(const HashTableOpnAdr<Data>& other);

  // Move constructor
  HashTableOpnAdr(HashTableOpnAdr<Data>&& other) noexcept;

  /* ************************************************************************ */

  // Destructor
  inline virtual ~HashTableOpnAdr() { delete [] flagsArray; delete [] Elements; };

  /* ************************************************************************ */

  // Copy assignment
  HashTableOpnAdr& operator=(const HashTableOpnAdr& other);

  // Move assignment
  HashTableOpnAdr& operator=(HashTableOpnAdr&& other) noexcept;

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const HashTableOpnAdr& other) const noexcept;
  inline bool operator!=(const HashTableOpnAdr& other) const noexcept { return !(operator==(other)); };

  /* ************************************************************************ */

  // Specific member functions (inherited from DictionaryContainer)
  virtual bool Insert(const Data& val) override; // Override DictionaryContainer member (Copy of the value)
  virtual bool Insert(Data&& val) override; // Override DictionaryContainer member (Move of the value)
  virtual bool Remove(const Data& val) override; // Override DictionaryContainer member

  /* ************************************************************************ */

  // Specific member functions (inherited from TestableContainer)
  virtual bool Exists(const Data& val) const noexcept override;  // Override TestableContainer member

  /* ************************************************************************ */

  // Specific member functions (inherited from ResizableContainer)
  virtual void Resize(const ulong new_size);  // Resize the hashtable to a given size

  /* ************************************************************************ */

  // Specific member functions (inherited from ClearableContainer)
  virtual void Clear() override; // Override Container member

  /* ************************************************************************ */

  // Testing functions (used for myTest() in multiple cases)
  void CheckIfAllElementsAreDeleted(){
    bool result = true;
    for(int i=0; i<arraySize; i++)
      result &= flagsArray[i][0] == 1;
    if(result)
      std::cout<<" (Tutti i bit hanno valore 10 )";
  }

  void PrintOpnAdrHT() {
    std::cout<<"\n";
    for(int i=0; i<arraySize; i++){
        std::cout<<"["<<i<<"][0]:"<<flagsArray[i][0]<<"\t["<<i<<"][1]:"<<flagsArray[i][1]<<"\tval: "<<Elements[i]<<std::endl;
    }
  }

  ulong ReadDeletedElements() {
    return deleted_elements;
  }


protected:

  // Auxiliary member functions
  ulong QuadraticProbing(ulong& probing_value, const Data &key) const noexcept;
  bool FindFromIndex(ulong& index, ulong& probing_value, const Data& key) const noexcept;
  ulong FindAvailableSlot(ulong& probing_value, const Data& key) noexcept;
  bool RemoveFromIndex(ulong& probing_value, const Data& key);

};

/* ************************************************************************** */

}

#include "htopnadr.cpp"

#endif
