#include "htopnadr.hpp"

namespace lasd {

/* ************************************************************************** */

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(const ulong new_size) : HashTable<Data>()
{
    arraySize = NextPowOf2(new_size);
    Elements = new Data[arraySize] {};
    flagsArray = new std::bitset<2>[arraySize] {};
}

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(const MappableContainer<Data>& other) : HashTableOpnAdr(other.Size()*2) {
    InsertAll(other);
}

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(const ulong new_size, const MappableContainer<Data>& other) : HashTableOpnAdr(new_size) {
    InsertAll(other);
}

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(MutableMappableContainer<Data>&& other) noexcept : HashTableOpnAdr(other.Size()*2) {
    InsertAll(std::move(other));
}

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(const ulong new_size, MutableMappableContainer<Data>&& other) noexcept : HashTableOpnAdr(new_size) {
    InsertAll(std::move(other));
}


template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(const HashTableOpnAdr<Data>& other) : HashTable<Data>(other) {
    Elements = new Data[arraySize] {};
    flagsArray = new std::bitset<2>[arraySize] {};
    for(ulong i=0; i<arraySize; i++){
        Elements[i] = other.Elements[i];
        flagsArray[i] = other.flagsArray[i];
    }
}

template <typename Data>
HashTableOpnAdr<Data>::HashTableOpnAdr(HashTableOpnAdr<Data>&& other) noexcept : HashTable<Data>(std::move(other)) {
    std::swap(Elements, other.Elements);
    std::swap(flagsArray, other.flagsArray);
}


template <typename Data>
HashTableOpnAdr<Data> &HashTableOpnAdr<Data>::operator=(const HashTableOpnAdr& other){
    HashTable<Data>::operator=(other);
    delete [] flagsArray;
    delete [] Elements;
    Elements = new Data[arraySize] {};
    flagsArray = new std::bitset<2>[arraySize] {};
    for(ulong i=0; i<arraySize; i++){
        Elements[i] = other.Elements[i];
        flagsArray[i] = other.flagsArray[i];
    }
    return *this;
}

template <typename Data>
HashTableOpnAdr<Data>& HashTableOpnAdr<Data>::operator=(HashTableOpnAdr&& other) noexcept {
    HashTable<Data>::operator=(std::move(other));
    std::swap(Elements, other.Elements);
    std::swap(flagsArray, other.flagsArray);
    return *this;
}


template <typename Data>
bool HashTableOpnAdr<Data>::operator==(const HashTableOpnAdr& other) const noexcept {
    if(size!=other.Size())
        return false;
    for(ulong i=0; i<arraySize; i++){
        if(flagsArray[i].all()){
            if(!other.Exists(Elements[i]))
                return false;
        }
    }
    return true;
}


template <typename Data>
bool HashTableOpnAdr<Data>::Insert(const Data& dat) {
    ulong probing_value = 0;
    if(size*2>=arraySize)
        Resize(arraySize*2);
    ulong index = FindAvailableSlot(probing_value, dat);
    if(flagsArray[index][1]==0){
        Elements[index] = dat;
        size++;
        if(flagsArray[index][0]==1)
            deleted_elements--;
        flagsArray[index].set();
        return !RemoveFromIndex(++probing_value, Elements[index]); 
    }
    probing_value = 0;
    return false;   
}

template <typename Data>
bool HashTableOpnAdr<Data>::Insert(Data&& dat) {
    ulong probing_value = 0;
    if(size*2>=arraySize)
        Resize(arraySize*2);
    ulong index = FindAvailableSlot(probing_value, dat);
    if(flagsArray[index][1]==0){
        std::swap(Elements[index], dat);
        size++;
        if(flagsArray[index][0]==1)
            deleted_elements--;
        flagsArray[index].set();
        return !RemoveFromIndex(++probing_value, Elements[index]); 
    }
    probing_value = 0;
    return false;     
}

template <typename Data>
bool HashTableOpnAdr<Data>::Remove(const Data& dat) {
    ulong probing_value = 0;
    return RemoveFromIndex(probing_value, dat);
}


template <typename Data>
bool HashTableOpnAdr<Data>::Exists(const Data &dat) const noexcept {
    ulong probing_value = 0;
    ulong index = HashKey(Hashable<Data>()(dat));
    return FindFromIndex(index, probing_value, dat);
}


template <typename Data>
void HashTableOpnAdr<Data>::Resize(const ulong new_size) {
    if(new_size == 0)
        Clear();
    ulong temp_arraySize;
    if(new_size<size)
        temp_arraySize = NextPowOf2(size*2);
    else
        temp_arraySize = NextPowOf2(new_size);
    Data* temp_Elements = new Data[temp_arraySize] {};
    std::bitset<2>* temp_flagsArray = new std::bitset<2>[temp_arraySize] {};

    std::swap(temp_arraySize, arraySize);
    std::swap(temp_Elements, Elements);
    std::swap(temp_flagsArray, flagsArray);

    size=0;
    deleted_elements=0;
    for(ulong i=0; i<temp_arraySize; i++){
        if(temp_flagsArray[i].all())
            Insert(temp_Elements[i]);
    }
    delete [] temp_Elements;
    delete [] temp_flagsArray;
}


template <typename Data>
void HashTableOpnAdr<Data>::Clear() {
    for(ulong i=0; i<arraySize; i++){
        if(flagsArray[i].all())
            deleted_elements++;
        flagsArray[i][1]=0;
    }
    size=0;
    if(deleted_elements>(arraySize/4))
        Resize(arraySize); 
}

/* ************************************************************************** */

template <typename Data>
ulong HashTableOpnAdr<Data>::QuadraticProbing(ulong& probing_value, const Data& key) const noexcept {
    ulong starting_index = HashKey(Hashable<Data>()(key));
    return (starting_index + (((probing_value*probing_value)+probing_value)/2) + arraySize) % arraySize;
}

template <typename Data>
bool HashTableOpnAdr<Data>::FindFromIndex(ulong& index, ulong& probing_value, const Data& key) const noexcept {
    ulong jumps = 0;
    ulong index_for_swap = 0;
    bool first_available = true;
    ulong temp_index = QuadraticProbing(probing_value, key);
    do{
        if(jumps == (arraySize-1))
            return false;
        if((Elements[temp_index]==key) && (flagsArray[temp_index].all())) {
            index = temp_index;
            if(!first_available){
                Elements[index_for_swap] = Elements[index];
                std::swap(flagsArray[index_for_swap], flagsArray[temp_index]);
                index = index_for_swap;
            }
            else
                index = temp_index;
            return true;
        }
        if(flagsArray[temp_index][1]==0 && first_available){
                index_for_swap = temp_index;
                first_available = false;
        }
        temp_index = QuadraticProbing(++probing_value, key);
        jumps++;
    } while(!flagsArray[temp_index].none());
    return false;
}

template <typename Data>
ulong HashTableOpnAdr<Data>::FindAvailableSlot(ulong& probing_value, const Data& key) noexcept {
    ulong temp_index = QuadraticProbing(probing_value, key);
    while(flagsArray[temp_index].all() && Elements[temp_index]!=key) {   
        temp_index = QuadraticProbing(++probing_value, key);
    }
    return temp_index;
}

template <typename Data>
bool HashTableOpnAdr<Data>::RemoveFromIndex(ulong& probing_value, const Data& key){
    ulong temp_index = 0;
    if(FindFromIndex(temp_index, probing_value, key)){
        flagsArray[temp_index][1]=0;
        size--;
        deleted_elements++;
        probing_value = 0;
        if(size<arraySize/5 && arraySize>16)
            Resize(arraySize/2);
        if(deleted_elements>(arraySize/4))
            Resize(arraySize);      //Too many deleted elements: resize to clear them.
        return true;
    }
    probing_value = 0;
    return false;
}

/* ************************************************************************** */

template <typename Data>
void HashTableOpnAdr<Data>::Map(MapFunctor func) const {
    for(int i=0; i<arraySize; i++){
        if(flagsArray[i].all())
            func(Elements[i]);
    }
}

}
