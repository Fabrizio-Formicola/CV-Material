
#ifndef HASHTABLE_HPP
#define HASHTABLE_HPP

/* ************************************************************************** */

#include <random>

/* ************************************************************************** */

#include "../container/dictionary.hpp"

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
class Hashable {

protected:

public:

  ulong operator()(const Data val) const noexcept = 0; // (concrete function should not throw exceptions)

};

/* ************************************************************************** */

template <typename Data>
class HashTable : virtual public ResizableContainer,
                  virtual public DictionaryContainer<Data>,
                  virtual protected MappableContainer<Data> {

private:

protected:

  using DictionaryContainer<Data>::size;

  ulong A = 1;
  ulong B = 0;
  static const ulong prime = 1610612741;

  std::default_random_engine seed = std::default_random_engine(std::random_device{}());
  std::uniform_int_distribution<ulong> genA = std::uniform_int_distribution<ulong>(1, prime-1);
  std::uniform_int_distribution<ulong> genB = std::uniform_int_distribution<ulong>(0, prime-1);

  ulong arraySize = 16;

  // Default constructor
  inline HashTable(){
    A = genA(seed)*2+1;
    B = NextPowOf2(genB(seed));
    //A = 1;  //Values widely used for testing
    //B = 0;  //Values widely used for testing
  }

  // Copy constructor
  HashTable(const HashTable& other);

  // Move constructor
  HashTable(HashTable&& other) noexcept;

  // Destructor
  virtual ~HashTable() = default;

  /* ************************************************************************ */

public:

  // Copy assignment
  HashTable& operator=(const HashTable& other); // Copy assignment of abstract types should not be possible.

  // Move assignment
  HashTable& operator=(HashTable&& other) noexcept; // Move assignment of abstract types should not be possible.

  /* ************************************************************************ */

  // Comparison operators
  bool operator==(const HashTable& other) const noexcept; // Comparison of abstract hashtable is possible but not required.
  inline bool operator!=(const HashTable& other) const noexcept { return !(operator==(other)); }; // Comparison of abstract hashtable is possible but not required.

  /* ************************************************************************ */

  // Testing functions (used for myTest() in multiple cases)
  ulong ReadArraySize() {
    return arraySize;
  }

  using DictionaryContainer<Data>::Exists;

protected:

  // Auxiliary member functions
  inline ulong HashKey(const ulong key) const noexcept { return (A*key + B) % arraySize; };
  ulong NextPowOf2(ulong new_size);


};

/* ************************************************************************** */

}

#include "hashtable.cpp"

#endif
