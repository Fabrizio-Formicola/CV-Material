
#include <stdexcept>

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */

template <typename Data>
void MappableContainer<Data>::Fold(const FoldFunctor func, void* acc) const { // Override di Fold con Map
    Map( // Vengono iterati tutti gli elementi (dat) del container attraverso Map
        [&func, &acc](const Data& dat) {
            func(dat, acc); // Ciascun elemento (dat) viene passato alla FoldFunctor func e il risultato ottenuto viene salvato in acc
        }
    );
}

template <typename Data>
void PreOrderMappableContainer<Data>::PreOrderFold(const FoldFunctor func, void* acc) const {
    PreOrderMap( 
        [&func, &acc](const Data& dat) {
            func(dat, acc); 
        }
    );
}

template <typename Data>
void PostOrderMappableContainer<Data>::PostOrderFold(const FoldFunctor func, void* acc) const { 
    PostOrderMap(
        [&func, &acc](const Data& dat) {
            func(dat, acc);
        }
    );
}

template <typename Data>
void InOrderMappableContainer<Data>::InOrderFold(const FoldFunctor func, void* acc) const { 
    InOrderMap(
        [&func, &acc](const Data& dat) {
            func(dat, acc);
        }
    );
}

template <typename Data>
void BreadthMappableContainer<Data>::BreadthFold(const FoldFunctor func, void* acc) const { 
    BreadthMap(
        [&func, &acc](const Data& dat) {
            func(dat, acc);
        }
    );
}

/* ************************************************************************** */

}
