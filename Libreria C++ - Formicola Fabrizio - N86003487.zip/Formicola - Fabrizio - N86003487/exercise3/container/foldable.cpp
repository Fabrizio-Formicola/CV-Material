
#include <stdexcept>

/* ************************************************************************** */

namespace lasd {

/* ************************************************************************** */


template<typename Data>
bool FoldableContainer<Data>::Exists(const Data& valore) const noexcept {
    bool result=false;
    Fold(
        [this, valore](const Data& dat, void* result){
            *((bool*)result) |= (dat==valore); // viene confrontato ciascun dat con valore ed eseguito l'OR logico con result
        }
    , &result // result viene passato come accumulatore alla funzione Fold
    );
    return result;
}

/* ************************************************************************** */

}
