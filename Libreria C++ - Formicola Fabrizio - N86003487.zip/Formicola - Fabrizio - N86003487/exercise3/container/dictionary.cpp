
#include <stdexcept>

/* ************************************************************************** */

namespace lasd { 

/* ************************************************************************** */

template<typename Data>
bool DictionaryContainer<Data>::InsertAll(const MappableContainer<Data>& cont){
    bool result = true;
    cont.Map(
        [this, &result] (const Data& dat) {
            result &= Insert(dat);
        }
    );
    return result;
}

template<typename Data>
bool DictionaryContainer<Data>::InsertAll(MutableMappableContainer<Data>&& cont){ 
    bool result = true;
    cont.Map(
        [this, &result] (Data& dat) {
            result &= Insert(std::move(dat)); 
        }
    );
    return result;
}

template<typename Data>
bool DictionaryContainer<Data>::RemoveAll(const MappableContainer<Data>& cont){ 
    bool result = true;
    cont.Map(
        [this, &result] (const Data& dat) {
            result &= Remove(dat); 
        }
    );
    return result;
}



template<typename Data>
bool DictionaryContainer<Data>::InsertSome(const MappableContainer<Data>& cont){ 
    bool result = false; 
    cont.Map(
        [this, &result] (const Data& dat) { 
            result |= Insert(dat);
        }
    );
    return result;
}

template<typename Data>
bool DictionaryContainer<Data>::InsertSome(MutableMappableContainer<Data>&& cont){
    bool result = false;
    cont.Map(
        [this, &result] (Data& dat) {
            result |= Insert(std::move(dat));
        }
    );
    return result;
}

template<typename Data>
bool DictionaryContainer<Data>::RemoveSome(const MappableContainer<Data>& cont){
    bool result = false;
    cont.Map(
        [this, &result] (const Data& dat) {
            result |= Remove(dat);
        }
    );
    return result;
}

/* ************************************************************************** */

}
