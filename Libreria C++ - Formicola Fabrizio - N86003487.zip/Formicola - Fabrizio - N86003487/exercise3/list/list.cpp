
namespace lasd {

/* ************************************************************************** */        // NODE

template <typename Data>
List<Data>::Node::Node(const Data& new_elem) {
    elem = new_elem;
    next = nullptr;
}

template <typename Data>
List<Data>::Node::Node(Data&& new_elem) noexcept {
    std::swap(elem , new_elem);
    next = nullptr;
}

/* ************************************************************************** */

template <typename Data>
List<Data>::Node::Node(const Node& new_node){
    elem = new_node.elem;
    next = new_node.next;
}

template <typename Data>
List<Data>::Node::Node(Node&& new_node) noexcept {
    std::swap(elem, new_node.elem);
    std::swap(next,new_node.next);
}

/* ************************************************************************** */        // LIST

template <typename Data>
List<Data>::List(const MappableContainer<Data>& cont) {
    cont.Map(
        [this](const Data& dat) {
            InsertAtBack(dat);
        }
    );
}

template <typename Data>
List<Data>::List(MutableMappableContainer<Data>&& cont) noexcept {
    cont.Map(
        [this](Data& dat) {
            InsertAtBack(std::move(dat));
        }
    );
}

/* ************************************************************************ */

template <typename Data>
List<Data>::List(const List<Data>& other){
    for(ulong i=0; i<other.size; i++)
        InsertAtBack(other[i]);
}

template <typename Data>
List<Data>::List(List<Data>&& other) noexcept {
    std::swap(head,other.head);
    std::swap(size,other.size);
}

/* ************************************************************************ */

template <typename Data>
List<Data>& List<Data>::operator=(const List& other) {
    Node* nodo = other.head;
    Clear();
    other.PostOrderMap(
        [this](const Data& dat) {
            InsertAtFront(dat);
        }
    );
    return *this;
}

template <typename Data>
List<Data>& List<Data>::operator=(List&& other) noexcept {
    std::swap(other.head, head);
    std::swap(other.size, size);
    return *this;
}

/* ************************************************************************ */

template <typename Data>
bool List<Data>::operator==(const List& other) const noexcept {
    if(size!=other.size) return false;
    Node* pointer1 = head;
    Node* pointer2 = other.head;
    for(ulong i=0; i<size; i++){
        if(pointer1->elem != pointer2->elem)
            return false;
        pointer1=pointer1->next;
        pointer2=pointer2->next;
    }
    return true;
}

/* ************************************************************************ */

template <typename Data>
void List<Data>::InsertAtFront(const Data& new_elem) {
    Node* new_node = new Node(new_elem);
    new_node->next=head;
    head=new_node;
    size++;
}

template <typename Data>
void List<Data>::InsertAtFront(Data&& new_elem) {
    Node* new_node = new Node(std::move(new_elem));
    new_node->next=head;
    head=new_node;
    size++;
}


template <typename Data>
void List<Data>::RemoveFromFront() {
    if(Empty())
        throw std::length_error("List: the list is empty in RemoveFromFront()");
    Node* old = head;
    head = head->next;
    delete old;
    size--;
}

template <typename Data>
Data List<Data>::FrontNRemove() {
    if(Empty())
        throw std::length_error("List: the list is empty in FrontNRemove()");
    Data elem = Front();
    RemoveFromFront();
    return elem;
}


template <typename Data>
void List<Data>::InsertAtBack(const Data& new_elem) {
    Node* current = head;
    Node* new_node = new Node(new_elem);
    if(!Empty()){ 
        while(current->next!=nullptr)
            current=current->next;
        current->next=new_node;
    }
    else
        head = new_node;
    size++;
}

template <typename Data>
void List<Data>::InsertAtBack(Data&& new_elem) {
    Node* current = head;
    Node* new_node = new Node(std::move(new_elem));
    if(!Empty()){ 
        while(current->next!=nullptr)
            current=current->next;
        current->next=new_node;
    }
    else
        head = new_node;
    size++;
}

/* ************************************************************************ */

template <typename Data>
bool List<Data>::Insert(const Data& elem) {
    if(FoldableContainer<Data>::Exists(elem))
        return false;
    InsertAtBack(elem);
    return true;
}

template <typename Data>
bool List<Data>::Insert(Data&& elem) {
    if(FoldableContainer<Data>::Exists(elem))
        return false;
    InsertAtBack(std::move(elem));
    return true;
}

template <typename Data>
bool List<Data>::Remove(const Data& chk_elem) {
    Node* current = head;
    Node* prev = nullptr;
    for(ulong i=0; i<size; i++){
        if((current->elem)==(chk_elem)) {
            if(prev != nullptr)
                prev->next=current->next;
            else
                head=current->next;
            delete current;
            size--;
            return true;
        }
        prev=current;
        current=current->next;
    }
    return false;
}

/* ************************************************************************ */

template <typename Data>
void List<Data>::Clear() {
    while(!Empty())
        RemoveFromFront();
}

/* ************************************************************************ */

template <typename Data>
const Data& List<Data>::operator[](const ulong index) const {
    if (!Empty() && index<size) {
        Node* ptr = head;
        for(ulong i=0; i<index; i++)
            ptr=ptr->next;
        return ptr->elem;
    }
    else
        throw std::out_of_range("List: out of range index of operator[]");
}

template <typename Data>
Data& List<Data>::operator[](const ulong index) {
    if (!Empty() && index<size) {
        Node* ptr = head;
        for(ulong i=0; i<index; i++)
            ptr=ptr->next;
        return ptr->elem;
    }
    else
        throw std::out_of_range("List: out of range index of operator[]");
}

/* ************************************************************************ */

template <typename Data>
const Data& List<Data>::Front() const {
    if(Empty())
        throw std::length_error("List: the list is empty in Front()");
    return head->elem; 
};

template <typename Data>
Data& List<Data>::Front() {
    if(Empty())
        throw std::length_error("List: the list is empty in Front()");
    return head->elem; 
};


template <typename Data>
const Data& List<Data>::Back() const {
    if(Empty())
        throw std::length_error("List: the list is empty in Back()");
    Node* current = head;
    while((current->next)!=nullptr)
        current=current->next;
    return current->elem; 
};

template <typename Data>
Data& List<Data>::Back() {
    if(Empty()) throw std::length_error("List: the list is empty in Back()");
    Node* current = head;
    while((current->next)!=nullptr)
        current=current->next;
    return current->elem; 
};

/* ************************************************************************ */

template <typename Data>
void List<Data>::PreOrderFold(const FoldFunctor func, void* acc) const {
    AuxPreOrderFold(head, func, acc);
}

template <typename Data>
void List<Data>::AuxPreOrderFold(const Node* nodo, FoldFunctor func, void* acc) const {
    const Node* current = nodo;
    while(current != nullptr){
        func(current->elem, acc);
        current=current->next;
    }
}


template <typename Data>
void List<Data>::PostOrderFold(const FoldFunctor func, void* acc) const {
    if(!Empty())
        AuxPostOrderFold(head, func, acc);
}

template <typename Data>
void List<Data>::AuxPostOrderFold(const Node* nodo, FoldFunctor func, void* acc) const {
    if(nodo!=nullptr){
        if(nodo->next!=nullptr)
            AuxPostOrderFold(nodo->next, func, acc);
        func(nodo->elem, acc);
    }
}



template <typename Data>
void List<Data>::PreOrderMap(const MapFunctor func) const {
    AuxPreOrderMap(head, func);
}

template <typename Data>
void List<Data>::AuxPreOrderMap(const Node* nodo, const MapFunctor func) const {
    const Node* current = nodo;
    while(current!=nullptr){
        func(current->elem);
        current=current->next;
    }
}


template <typename Data>
void List<Data>::PostOrderMap(const MapFunctor func) const {
    if(!Empty())
        AuxPostOrderMap(head, func);
}

template <typename Data>
void List<Data>::AuxPostOrderMap(const Node* nodo, const MapFunctor func) const {
    if(nodo!=nullptr){
        if(nodo->next!=nullptr)
            AuxPostOrderMap(nodo->next, func);
        func(nodo->elem);
    }
}



template <typename Data>
void List<Data>::PreOrderMap(MutableMapFunctor func) {
    AuxPreOrderMap(head, func);
}

template <typename Data>
void List<Data>::AuxPreOrderMap(Node* nodo, MutableMapFunctor func) {
    Node* current = nodo;
    while(current!=nullptr){
        func(current->elem);
        current=current->next;
    }
}


template <typename Data>
void List<Data>::PostOrderMap(MutableMapFunctor func) {
    if(!Empty())
        AuxPostOrderMap(head, func);
}

template <typename Data>
void List<Data>::AuxPostOrderMap(Node* nodo, MutableMapFunctor func) {
    if(nodo!=nullptr){
        if(nodo->next!=nullptr)
            AuxPostOrderMap(nodo->next, func);
        func((nodo->elem));
    }
}

/* ************************************************************************** */

}